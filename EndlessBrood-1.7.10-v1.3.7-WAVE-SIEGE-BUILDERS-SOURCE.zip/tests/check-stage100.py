#!/usr/bin/env python3
from pathlib import Path
c = Path('src/main/java/com/endlessbrood/common/BroodConfig.java').read_text()
d = Path('src/main/java/com/endlessbrood/common/EvolutionData.java').read_text()
assert 'return BigInteger.valueOf(evolutionCost);' in c
assert 'config.getInt("pointsPerStage", "evolution", 100,' in c
assert 'multiply(BigInteger.valueOf(evolutionSlowdownMultiplier))' not in c
assert 'points.divide(BroodConfig.effectiveEvolutionCost())' in d
assert 'points = stage.multiply(BroodConfig.effectiveEvolutionCost())' in d
assert [(p, p//100) for p in (0, 99, 100, 299, 300, 900)] == [(0,0),(99,0),(100,1),(299,2),(300,3),(900,9)]
print('PASS: stage 100, preserved points, existing config ignores legacy 3x multiplier')
