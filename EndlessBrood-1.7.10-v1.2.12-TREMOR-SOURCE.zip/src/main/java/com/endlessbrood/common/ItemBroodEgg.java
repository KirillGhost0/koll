package com.endlessbrood.common;

import java.util.List;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

/** Eight creative-only testing eggs. No vanilla/global entity IDs; works on Forge servers. */
public final class ItemBroodEgg extends Item {
    private static final String[] NAMES = { "stalker", "scuttler", "bulwark", "thornback", "colossus", "matriarch", "flier", "commander", "ravager", "sporecaller", "ironmaw", "skyreaper", "overmind" };

    public ItemBroodEgg() {
        setHasSubtypes(true);
        setMaxDamage(0);
        setMaxStackSize(64);
        setCreativeTab(CreativeTabs.tabMisc);
        setUnlocalizedName("endlessbrood.parasiteEgg");
        setTextureName("endlessbrood:parasite_egg");
    }

    @Override
    public String getUnlocalizedName(ItemStack stack) {
        int meta = stack.getItemDamage();
        if (meta < 0 || meta >= NAMES.length) meta = 0;
        return "item.endlessbrood.parasiteEgg." + NAMES[meta];
    }

    @Override
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public void getSubItems(Item item, CreativeTabs tab, List list) {
        for (int i = 0; i < NAMES.length; ++i) list.add(new ItemStack(item, 1, i));
    }

    @Override
    public boolean onItemUse(ItemStack stack, EntityPlayer player, World world,
                             int x, int y, int z, int side,
                             float hitX, float hitY, float hitZ) {
        if (stack == null || stack.stackSize <= 0 ||
            stack.getItemDamage() < 0 || stack.getItemDamage() >= NAMES.length ||
            !player.canPlayerEdit(x, y, z, side, stack)) return false;
        switch (side) {
            case 0: --y; break;
            case 1: ++y; break;
            case 2: --z; break;
            case 3: ++z; break;
            case 4: --x; break;
            case 5: ++x; break;
            default: return false;
        }
        if (y < 1 || y > 254) return false;
        if (world.isRemote) return true;
        net.minecraft.entity.Entity creature;
        int kind = stack.getItemDamage();
        if (kind == 6) creature = new EntityBroodFlier(world);
        else if (kind == 8) { EntityBroodElite.Ravager e = new EntityBroodElite.Ravager(world); e.prepareForWave(); creature = e; }
        else if (kind == 9) { EntityBroodElite.Sporecaller e = new EntityBroodElite.Sporecaller(world); e.prepareForWave(); creature = e; }
        else if (kind == 10) { EntityBroodElite.Ironmaw e = new EntityBroodElite.Ironmaw(world); e.prepareForWave(); creature = e; }
        else if (kind == 11) creature = new EntityBroodSkyreaper(world);
        else if (kind == 12) { EntityBroodElite.Overmind e = new EntityBroodElite.Overmind(world); e.prepareForWave(); creature = e; }
        else if (kind == 7) {
            EntityBroodCommander commander = new EntityBroodCommander(world);
            commander.setWaveLevel(1);
            creature = commander;
        } else {
            EntityParasite parasite = new EntityParasite(world);
            parasite.configureSpawnMorph(kind);
            creature = parasite;
        }
        creature.setLocationAndAngles(x + 0.5D, y + (kind == 6 || kind == 11 ? 2.0D : 0.0D),
            z + 0.5D, player.rotationYaw, 0F);
        if (!world.checkNoEntityCollision(creature.boundingBox) ||
            !world.getCollidingBoundingBoxes(creature, creature.boundingBox).isEmpty() ||
            !world.spawnEntityInWorld(creature)) return false;
        if (!player.capabilities.isCreativeMode) --stack.stackSize;
        return true;
    }
}
