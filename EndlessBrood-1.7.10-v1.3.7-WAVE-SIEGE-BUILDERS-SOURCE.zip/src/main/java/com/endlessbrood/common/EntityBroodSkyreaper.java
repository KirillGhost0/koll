package com.endlessbrood.common;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

/** Armored aerial dive predator; reuses cheap direct steering from the existing flier. */
public final class EntityBroodSkyreaper extends EntityBroodFlier {
    public EntityBroodSkyreaper(World world) { super(world); setSize(1.2F, 0.9F); experienceValue=22; }
    @Override public void onLivingUpdate() {
        float previousHealth = getHealth();
        double previousMax = getMaxHealth();
        super.onLivingUpdate();
        if (worldObj.isRemote || !isEntityAlive()) return;
        if (ticksExisted == 1 || ticksExisted % 200 == 0) {
            double base = Math.min(85D, 18D + 5D * EvolutionMath.logOnePlus(EvolutionData.get(worldObj).getStage()));
            double max = Math.min(160D, base * 1.85D);
            getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(max);
            if (previousHealth > 0.0F)
                setHealth((float)Math.min(max, previousHealth + Math.min(30D, Math.max(0D, max-previousMax))));
        }
        // Once per 3 seconds; only while diving and near an actual survival player.
        if (getDivePhase()!=2 || (ticksExisted + getEntityId()) % 60 != 0) return;
        for (Object obj: worldObj.playerEntities) {
            if (!(obj instanceof EntityPlayer)) continue;
            EntityPlayer victim=(EntityPlayer)obj;
            if (!victim.isEntityAlive() || victim.capabilities.isCreativeMode ||
                getDistanceSqToEntity(victim)>25D) continue;
            victim.addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, 50, 1));
            break;
        }
    }
}
