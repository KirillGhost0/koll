package com.endlessbrood.common;

import java.util.List;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ChatComponentText;
import net.minecraft.world.World;

/** No commands, permissions, GUI library or network synchronization required. */
public final class ItemSkillCodex extends Item {
    public ItemSkillCodex() {
        setUnlocalizedName("endlessbrood.skillCodex");
        setTextureName("endlessbrood:skill_codex");
        setCreativeTab(CreativeTabs.tabTools);
        setMaxStackSize(1);
    }
    @Override
    public ItemStack onItemRightClick(ItemStack stack, World world, EntityPlayer player) {
        if (world.isRemote) return stack;
        NBTTagCompound playerData = BroodSkills.get(player);
        NBTTagCompound itemData = stack.getTagCompound();
        if (itemData == null) { itemData = new NBTTagCompound(); stack.setTagCompound(itemData); }
        int choice = Math.max(0, Math.min(BroodSkills.KEYS.length - 1,
            itemData.getInteger("choice")));
        if (player.isSneaking()) {
            if (BroodSkills.upgrade(player, choice))
                player.addChatMessage(new ChatComponentText("[Skills] " + BroodSkills.KEYS[choice] +
                    " upgraded to " + BroodSkills.rank(playerData, choice) + "/10."));
            else player.addChatMessage(new ChatComponentText("[Skills] No points or max rank reached."));
        } else {
            choice = (choice + 1) % BroodSkills.KEYS.length;
            itemData.setInteger("choice", choice);
        }
        player.addChatMessage(new ChatComponentText("[Skills] Level " + BroodSkills.level(playerData) +
            " (" + playerData.getInteger("xp") + "/" +
            BroodSkills.xpForNext(BroodSkills.level(playerData)) + " XP), " +
            BroodSkills.points(playerData) + " points. Selected: " +
            BroodSkills.KEYS[choice] + " " + BroodSkills.rank(playerData, choice) +
            "/10. Right-click: next; Sneak+right-click: upgrade."));
        return stack;
    }
    @Override
    @SuppressWarnings({"unchecked", "rawtypes"})
    public void addInformation(ItemStack stack, EntityPlayer player, List lines, boolean advanced) {
        lines.add("Gain survivor XP by defeating parasites.");
        lines.add("Right-click: choose skill | Sneak + right-click: upgrade");
        lines.add("Skills persist through death; book is craftable again.");
    }
}
