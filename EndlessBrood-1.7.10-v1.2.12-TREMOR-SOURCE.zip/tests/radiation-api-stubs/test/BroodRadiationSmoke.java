package test;
import com.endlessbrood.common.*;
public class BroodRadiationSmoke {
 public static void main(String[] args){
  EntityParasite p=new EntityParasite();
  require(BroodRadiationBridge.getRadiation(p.worldObj,0,64,0)==10F, "HBM RAD bridge");
  require(BroodRadiationBridge.getRadiation(p.worldObj,24,64,0)==0F, "HBM sample across chunk");
  require(BroodRadiationBehavior.pulse(p), "parasite flees irradiated chunk");
  require(p.target==null, "parasite drops aggro to flee");
  require(p.damage >= 2F, "parasite takes radiation damage");
  require(!Double.isNaN(p.nav.x) && p.nav.x>=16, "parasite moves toward lower radiation");
  p.posX=24; p.damage=0F;
  require(!BroodRadiationBehavior.pulse(p) && p.damage==0F, "safe chunk no irradiation");
  System.out.println("OK: HBM actual chunk RAD reflection, damage and retreat");
 }
 private static void require(boolean b,String s){if(!b)throw new AssertionError(s);}
}
