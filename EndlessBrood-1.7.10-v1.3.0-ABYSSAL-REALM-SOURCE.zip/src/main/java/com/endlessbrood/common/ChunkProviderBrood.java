package com.endlessbrood.common;

import com.endlessbrood.EndlessBrood;
import java.util.Collections;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.init.Blocks;
import net.minecraft.util.IProgressUpdate;
import net.minecraft.world.ChunkPosition;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.IChunkProvider;

/** Deterministic void islands and a distant fortress; NO per-chunk cascading generation. */
public final class ChunkProviderBrood implements IChunkProvider {
    private final World world;
    private final long seed;
    public ChunkProviderBrood(World world, long seed) { this.world=world; this.seed=seed; }
    @Override public boolean chunkExists(int x,int z) { return true; }
    @Override public Chunk loadChunk(int x,int z) { return provideChunk(x,z); }
    @Override public Chunk provideChunk(int cx,int cz) {
        Block[] blocks=new Block[16*16*256];
        for(int lx=0;lx<16;lx++) for(int lz=0;lz<16;lz++) {
            int x=(cx<<4)+lx, z=(cz<<4)+lz;
            int top=BroodRealmRules.islandTop(seed,x,z);
            if(top<0) continue;
            boolean fort=Math.abs(x-BroodRealmRules.FORT_X)<70 &&
                         Math.abs(z-BroodRealmRules.FORT_Z)<70;
            double d=Math.hypot(x-BroodRealmRules.FORT_X,z-BroodRealmRules.FORT_Z);
            int thick = fort ? 10 : 5 + (int)(Math.abs(Math.sin(x*.13+z*.17))*9);
            for(int y=Math.max(1,top-thick);y<=top;y++) {
                Block b = y==top ? EndlessBrood.taintedSoil :
                    y < top-3 ? Blocks.stone : Blocks.netherrack;
                blocks[(lx*16+lz)*256+y]=b;
            }
            // Fortress is built directly in the current chunk, without touching neighbours.
            if (d < 54) {
                int y=141;
                for(int yy=132;yy<=y;yy++) blocks[(lx*16+lz)*256+yy]=yy==y?Blocks.stonebrick:Blocks.stone;
                int rx=Math.abs(x-BroodRealmRules.FORT_X), rz=Math.abs(z-BroodRealmRules.FORT_Z);
                // Open-roof blackstone fortress with an accessible southern gate.
                boolean perimeter=(rx>=35 && rx<=37 && rz<=37) ||
                                  (rz>=35 && rz<=37 && rx<=37);
                boolean gate=rz>=35 && x>=BroodRealmRules.FORT_X-3 && x<=BroodRealmRules.FORT_X+3;
                if(perimeter && !gate) for(int yy=142;yy<=151;yy++)
                    blocks[(lx*16+lz)*256+yy]=Blocks.nether_brick;
                // Four lookout towers, height 18; central battle area remains roofless.
                if(rx>=33 && rx<=39 && rz>=33 && rz<=39 && !gate) {
                    for(int yy=142;yy<=159;yy++)
                        blocks[(lx*16+lz)*256+yy]=yy==159?Blocks.obsidian:Blocks.nether_brick;
                }
                // Four raised pedestals to hold the four mini-bosses.
                boolean pedestal=(Math.abs(rx-23)<=3 && Math.abs(rz-23)<=3);
                if(pedestal) for(int yy=142;yy<=144;yy++)
                    blocks[(lx*16+lz)*256+yy]=Blocks.obsidian;
                if(rx<=8 && rz<=8) blocks[(lx*16+lz)*256+142]=Blocks.obsidian;
                if(rx<=4 && rz<=4) blocks[(lx*16+lz)*256+143]=Blocks.obsidian;
            }
        }
        Chunk chunk=new Chunk(world,blocks,cx,cz);
        byte[] biomes=chunk.getBiomeArray();
        for(int i=0;i<biomes.length;i++) biomes[i]=(byte)net.minecraft.world.biome.BiomeGenBase.sky.biomeID;
        chunk.generateSkylightMap();
        return chunk;
    }
    @Override public void populate(IChunkProvider provider,int x,int z) { /* Generated in the chunk itself. */ }
    @Override public boolean saveChunks(boolean all,IProgressUpdate progress) { return true; }
    @Override public boolean unloadQueuedChunks() { return false; }
    @Override public boolean canSave() { return true; }
    @Override public String makeString() { return "Endless Brood floating abyss"; }
    @Override @SuppressWarnings("rawtypes") public List getPossibleCreatures(EnumCreatureType type,int x,int y,int z) { return Collections.emptyList(); }
    @Override public ChunkPosition func_147416_a(World world,String name,int x,int y,int z) { return null; }
    @Override public int getLoadedChunkCount() { return 0; }
    @Override public void recreateStructures(int x,int z) { }
    @Override public void saveExtraData() { }
}
