package com.endlessbrood.client;

import com.endlessbrood.common.BroodConfig;
import com.endlessbrood.common.BroodFootstepRules;
import com.endlessbrood.common.EntityBroodCommander;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.world.World;
import net.minecraft.entity.player.EntityPlayer;

/** Client-only short cinematic camera pulses. Does not edit server-side view.
 * Applied in RenderTick START and precisely undone in END. Can be disabled.
 */
public final class BroodCameraShake {
    private EntityBroodCommander watched;
    private World lastWorld;
    private int nextScanTick;
    private EntityPlayer adjustedPlayer;
    private float appliedPitch, appliedYaw;

    @SubscribeEvent
    @SuppressWarnings("unchecked")
    public void onRenderTick(TickEvent.RenderTickEvent event) {
        Minecraft mc = Minecraft.getMinecraft();
        if (event.phase == TickEvent.Phase.END) {
            // Subtract our change, preserving any mouse movement in the frame.
            if (adjustedPlayer != null) {
                adjustedPlayer.rotationPitch -= appliedPitch;
                adjustedPlayer.rotationYaw -= appliedYaw;
            }
            adjustedPlayer = null;
            appliedPitch = appliedYaw = 0F;
            return;
        }
        if (!BroodConfig.sovereignCameraShake || mc.theWorld == null ||
            mc.thePlayer == null || mc.currentScreen != null) return;
        EntityPlayer player = mc.thePlayer;
        if (lastWorld != mc.theWorld) {
            lastWorld = mc.theWorld;
            watched = null;
            nextScanTick = 0;
        }
        if (player.ticksExisted >= nextScanTick ||
            (watched != null && (watched.isDead || watched.worldObj != mc.theWorld ||
            player.getDistanceSqToEntity(watched) > 24D*24D))) {
            watched = null;
            nextScanTick = player.ticksExisted + 8;
            double best = 24D * 24D;
            for (Object obj : mc.theWorld.loadedEntityList) {
                if (!(obj instanceof EntityBroodCommander)) continue;
                EntityBroodCommander candidate = (EntityBroodCommander)obj;
                if (candidate.isDead) continue;
                double sq = player.getDistanceSqToEntity(candidate);
                if (sq < best) { best = sq; watched = candidate; }
            }
        }
        if (watched == null || !watched.onGround) return;
        double motion = watched.motionX * watched.motionX + watched.motionZ * watched.motionZ;
        if (!BroodFootstepRules.isMovingOnGround(watched.onGround, motion)) return;
        float weight = BroodFootstepRules.volumeAt(player.getDistanceSqToEntity(watched), 24D);
        float pulse = BroodFootstepRules.pulse(watched.ticksExisted + event.renderTickTime);
        float amp = Math.min(0.75F, weight * pulse * BroodConfig.sovereignCameraShakeStrength);
        if (amp <= 0.003F) return;
        adjustedPlayer = player;
        appliedPitch = amp * 0.48F;
        appliedYaw = (float)Math.sin(watched.ticksExisted * 1.7F) * amp * 0.16F;
        player.rotationPitch += appliedPitch;
        player.rotationYaw += appliedYaw;
    }
}
