package com.endlessbrood.common;

import java.util.Random;

/** Forge-independent stochastic thinning of item drops. Each previously generated
 *  item has an independent 20% chance by default, preserving meaningful rare loot.
 */
public final class BroodLootRules {
    private BroodLootRules() { }

    public static int countKept(int originalCount, int percent, Random random) {
        if (originalCount <= 0 || percent <= 0) return 0;
        if (percent >= 100) return originalCount;
        int kept = 0;
        for (int i = 0; i < originalCount; ++i) {
            if (random.nextInt(100) < percent) kept++;
        }
        return kept;
    }
}
