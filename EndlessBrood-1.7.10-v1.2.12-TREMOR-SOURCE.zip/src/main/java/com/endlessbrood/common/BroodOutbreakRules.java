package com.endlessbrood.common;

/** Pure geometry and timing used by the distant-outbreak system. */
public final class BroodOutbreakRules {
    private BroodOutbreakRules() { }

    public static boolean graceExpired(long now, long installationTick, int days) {
        if (installationTick < 0L || now < installationTick) return false;
        return now - installationTick >= (long) Math.max(0, days) * 24000L;
    }

    public static boolean shouldGrow(long now, long installationTick, int days, int interval) {
        return interval > 0 && graceExpired(now, installationTick, days)
            && (now - installationTick) % interval == 0L;
    }

    public static boolean outsideRadius(double x, double z, double ax, double az, int radius) {
        if (Double.isNaN(x) || Double.isNaN(z) || Double.isInfinite(x) || Double.isInfinite(z)) return false;
        double dx = x - ax;
        double dz = z - az;
        return dx * dx + dz * dz >= (double) radius * radius;
    }
    /**
     * Invasion begins at the full safe distance; its front advances toward home
     * over actual server ticks, independently of /time set (daylight clock).
     */
    public static int effectiveHomeRadius(long now, long installed, int graceDays,
                                           int initialRadius, int approachDays) {
        if (installed < 0L || now < installed) return Math.max(0, initialRadius);
        long afterGrace = now - installed - 24000L * Math.max(0, graceDays);
        if (afterGrace <= 0L) return Math.max(0, initialRadius);
        if (approachDays <= 0) return 0;
        long full = 24000L * (long) approachDays;
        if (afterGrace >= full) return 0;
        return (int) ((long) Math.max(0, initialRadius) * (full - afterGrace) / full);
    }

}
