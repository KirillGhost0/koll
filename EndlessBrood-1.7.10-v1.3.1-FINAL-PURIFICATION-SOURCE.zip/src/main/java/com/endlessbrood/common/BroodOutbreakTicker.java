package com.endlessbrood.common;

import com.endlessbrood.EndlessBrood;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import java.util.Random;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

/**
 * Rare, limited attempts to seed old, ALREADY LOADED distant terrain.
 * No extra chunk loading, no scan across all saved chunks, no forced tickets.
 */
public final class BroodOutbreakTicker {
    @SubscribeEvent
    public void worldTick(TickEvent.WorldTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.world.isRemote ||
            event.world.provider.dimensionId != 0) return;
        World world = event.world;
        if (BroodVictoryData.isDefeated(world)) return;
        BroodOutbreakData data = BroodOutbreakData.get(world);
        data.rememberPlayers(world);
        if (!BroodConfig.nestsEnabled || !BroodConfig.retroactiveDistantNests ||
            !data.graceExpired(world.getTotalWorldTime()) ||
            (!data.canSeedEarlyNest(world.getTotalWorldTime()) &&
             data.retroSeedCount() >= BroodConfig.effectiveRetroSeedLimit()) ||
            world.getTotalWorldTime() % BroodConfig.effectiveRetroSeedInterval() != 0) return;
        // One potential nest per interval; look as far as loaded exploration range allows.
        for (Object entry : world.playerEntities) {
            if (!(entry instanceof EntityPlayer)) continue;
            EntityPlayer player = (EntityPlayer) entry;
            if (player.dimension != 0) continue;
            int px = MathHelper.floor_double(player.posX);
            int pz = MathHelper.floor_double(player.posZ);
            Random random = world.rand;
            for (int attempt = 0; attempt < 24; ++attempt) {
                boolean earlyNest = data.canSeedEarlyNest(world.getTotalWorldTime()) &&
                    attempt < 12;
                int x, z;
                if (earlyNest) {
                    double angle = random.nextDouble() * Math.PI * 2D;
                    int radius = 56 + random.nextInt(45);
                    x = px + (int)Math.round(Math.cos(angle) * radius);
                    z = pz + (int)Math.round(Math.sin(angle) * radius);
                } else {
                    if (data.retroSeedCount() >= BroodConfig.effectiveRetroSeedLimit()) continue;
                    x = px + random.nextInt(449) - 224;
                    z = pz + random.nextInt(449) - 224;
                }
                // Early nests are explicitly limited; old-world 768-block
                // protected home radius still applies to RANDOM distant nests.
                if (!(earlyNest ? data.farFromOnlinePlayersEarly(world, x, z) :
                    data.maySeedAt(world, x, z)) ||
                    !data.farFromExistingRetroSeeds(x, z) ||
                    !world.blockExists(x, 64, z)) continue;
                int y = world.getHeightValue(x, z);
                if (y <= 55 || y >= 190 || !world.blockExists(x, y + 1, z) ||
                    !world.isAirBlock(x, y, z) || !world.isAirBlock(x, y + 1, z)) continue;
                if (world.getBlock(x, y - 1, z) != Blocks.grass &&
                    world.getBlock(x, y - 1, z) != Blocks.dirt) continue;
                if (BroodWardRules.protects(world, x, y, z) ||
                    BroodConfig.radiationStopsNests && BroodRadiationBridge.getRadiation(world,x,y,z)
                        >= BroodConfig.radiationSoilCleanThreshold) continue;
                if (world.setBlock(x, y, z, EndlessBrood.nest, 0, 3)) {
                    if (earlyNest) data.recordEarlyNest(x, z);
                    else data.recordRetroSeed(x, z);
                    return;
                }
            }
        }
    }
}
