package com.endlessbrood.client;

import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.boss.BossStatus;
import net.minecraft.entity.boss.IBossDisplayData;
import net.minecraft.util.ResourceLocation;

/** Unique 3-block tall model; boss HP bar on clients for nearby visible boss. */
public final class RenderBroodCommander extends RenderLiving {
    private static final ResourceLocation TEXTURE = new ResourceLocation(
        "endlessbrood", "textures/entity/dread_sovereign.png");
    public RenderBroodCommander() { super(new ModelBroodDreadSovereign(), 1.3F); }
    @Override protected ResourceLocation getEntityTexture(Entity entity) { return TEXTURE; }
    @Override protected void preRenderCallback(EntityLivingBase entity, float time) {
        if (entity instanceof IBossDisplayData)
            BossStatus.setBossStatus((IBossDisplayData)entity, true);
        // Model and hitbox are both 3 blocks high; scaling would desync collisions.
    }
}
