package test;
import net.minecraft.world.World;
import com.endlessbrood.common.BroodAiBudget;
import com.endlessbrood.common.BroodConfig;
public final class BroodAiBudgetSmoke {
    private static void yes(boolean c) {if(!c)throw new AssertionError("path quota failed");}
    public static void main(String[] args) {
        World world = new World();
        BroodConfig.maxPathRequestsPerTick = 4;
        for(int n=0;n<4;n++) yes(BroodAiBudget.tryPath(world));
        yes(!BroodAiBudget.tryPath(world));
        world.setTotalWorldTime(1L);
        yes(BroodAiBudget.tryPath(world));
        World other = new World();
        for(int n=0;n<4;n++) yes(BroodAiBudget.tryPath(other));
        yes(!BroodAiBudget.tryPath(other));
        world.isRemote = true;
        yes(!BroodAiBudget.tryPath(world));
        System.out.println("PASS: per-world, per-tick path request limiter");
    }
}
