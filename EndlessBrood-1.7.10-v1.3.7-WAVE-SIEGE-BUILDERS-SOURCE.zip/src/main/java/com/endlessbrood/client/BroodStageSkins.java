package com.endlessbrood.client;

import com.endlessbrood.common.BroodVisualEvolution;
import com.endlessbrood.common.EntityParasite;
import com.endlessbrood.common.EntityBroodFlier;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;

/** Preloaded names. All stage-specific skins are bundled with the mod. */
public final class BroodStageSkins {
    private BroodStageSkins() { }
    public static ResourceLocation[] forName(String name) {
        ResourceLocation[] result = new ResourceLocation[6];
        for(int i=0;i<6;i++)
            result[i] = new ResourceLocation("endlessbrood", "textures/entity/" + name +
                (i == 0 ? "" : "_decay" + i) + ".png");
        return result;
    }
    public static int phase(Entity entity) {
        int tier = entity instanceof EntityParasite ? ((EntityParasite)entity).getVisualTier() :
            entity instanceof EntityBroodFlier ? ((EntityBroodFlier)entity).getVisualTier() : 0;
        return BroodVisualEvolution.skin(tier);
    }
    public static float growth(Entity entity) {
        int tier = entity instanceof EntityParasite ? ((EntityParasite)entity).getVisualTier() :
            entity instanceof EntityBroodFlier ? ((EntityBroodFlier)entity).getVisualTier() : 0;
        return BroodVisualEvolution.scale(tier);
    }
}
