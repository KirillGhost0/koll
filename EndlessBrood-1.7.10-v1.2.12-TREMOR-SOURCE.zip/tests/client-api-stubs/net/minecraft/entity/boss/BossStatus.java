package net.minecraft.entity.boss;
public final class BossStatus {
    public static void setBossStatus(IBossDisplayData entity, boolean colorModifier) {}
}
