package com.endlessbrood.common;

/** Cheap shared per-boss gait and falloff rules. No Forge classes required. */
public final class BroodFootstepRules {
    private BroodFootstepRules() { }
    public static final int STEP_TICKS = 12;
    public static boolean isMovingOnGround(boolean onGround, double horizontalSpeedSq) {
        return onGround && horizontalSpeedSq >= 0.0009D;
    }
    public static boolean shouldStomp(int ticks, boolean onGround, double horizontalSpeedSq) {
        return ticks > 0 && ticks % STEP_TICKS == 0 &&
            isMovingOnGround(onGround, horizontalSpeedSq);
    }
    public static float volumeAt(double distanceSq, double maxRange) {
        if (maxRange <= 0 || distanceSq >= maxRange * maxRange) return 0F;
        double normalized = Math.sqrt(Math.max(0, distanceSq)) / maxRange;
        return (float)Math.pow(1D - normalized, 2D);
    }
    /** Strong near impact, smooth decay in the next four ticks. */
    public static float pulse(float phaseInTicks) {
        if (phaseInTicks < 0) return 0F;
        float phase = phaseInTicks % STEP_TICKS;
        return phase < 4F ? (float)Math.pow(1F - phase / 4F, 2) : 0F;
    }
}
