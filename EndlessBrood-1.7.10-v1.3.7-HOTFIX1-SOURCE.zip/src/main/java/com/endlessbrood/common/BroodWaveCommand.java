package com.endlessbrood.common;

import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.ChatComponentText;
import net.minecraft.world.World;

/** Operator-only invasion test: /broodwave start 5 also works in creative. */
public final class BroodWaveCommand extends CommandBase {
    @Override public String getCommandName() { return "broodwave"; }
    @Override public String getCommandUsage(ICommandSender sender) {
        return "/broodwave status | start [wave 1..1000]";
    }
    @Override public int getRequiredPermissionLevel() { return 2; }
    @Override public void processCommand(ICommandSender sender, String[] args) {
        World world = sender.getEntityWorld();
        if (world.provider.dimensionId != 0) {
            sender.addChatMessage(new ChatComponentText("[Endless Brood] Only overworld."));
            return;
        }
        if (BroodVictoryData.isDefeated(world)) {
            sender.addChatMessage(new ChatComponentText("[Endless Brood] Рой уничтожен. Волны больше не появятся."));
            return;
        }
        BroodWaveData data = BroodWaveData.get(world);
        if (args.length > 0 && "start".equalsIgnoreCase(args[0])) {
            int index = data.waveIndex + 1;
            if (args.length > 1) {
                try { index = Integer.parseInt(args[1]); }
                catch (NumberFormatException ex) { sender.addChatMessage(new ChatComponentText("Invalid wave number.")); return; }
            }
            if (index < 1 || index > 1000) {
                sender.addChatMessage(new ChatComponentText("Wave must be 1..1000."));
                return;
            }
            BroodWaveTicker.beginWave(world, data, index, true);
            sender.addChatMessage(new ChatComponentText("[Endless Brood] Test wave " + index +
                " started (creative players are test targets; immune to damage)."));
        } else {
            long gameDay = BroodCalendarRules.day(world.getWorldTime());
            int remains = BroodCalendarRules.countdownDays(world.getWorldTime(),
                BroodConfig.waveIntervalDays);
            int goal = data.plannedTotal > 0 ? data.plannedTotal :
                BroodEliteWaveRules.plan(data.waveIndex,
                    EvolutionData.get(world).getStage().min(java.math.BigInteger.valueOf(Long.MAX_VALUE)).longValue(),
                    BroodConfig.effectiveWaveMobCount(BroodWaveRules.packSize(data.waveIndex, BroodConfig.waveMaxMobs)),
                    BroodConfig.eliteWaveHeadcountPercent).total;
            int elites = 0, plannedElites = 0;
            for (int n : data.eliteSpawned) elites += n;
            for (int n : data.eliteQuotas) plannedElites += n;
            sender.addChatMessage(new ChatComponentText("[Endless Brood] Wave " + data.waveIndex +
                "; active=" + (data.waveTicksLeft > 0) + "; spawned=" + data.spawned +
                "/" + goal + "; elites=" + elites + "/" + plannedElites + "; bossScheduled=" + (BroodConfig.waveBosses && BroodWaveRules.hasSovereign(data.waveIndex)) + "; bossSpawned=" + data.bossSpawned + "; remainingTicks=" + data.waveTicksLeft));
            sender.addChatMessage(new ChatComponentText("[Endless Brood] Placement failures=" +
                data.failedPlacement + "; population cap=" + data.blockedByCap +
                "; no valid player/peaceful/spawning disabled=" + data.noTargets +
                "; world day=" + gameDay + "; next calendar wave in " + remains + " days."));
        }
    }
}
