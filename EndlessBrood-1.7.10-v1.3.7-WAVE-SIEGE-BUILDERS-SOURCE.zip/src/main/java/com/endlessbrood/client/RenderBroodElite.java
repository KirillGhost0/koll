package com.endlessbrood.client;

import com.endlessbrood.common.EntityBroodElite;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

/** Shares optimized original meshes with recognizable caste-specific textures. */
public final class RenderBroodElite extends RenderLiving {
    private static final ResourceLocation[][] SKINS = {
        BroodStageSkins.forName("ravager"), BroodStageSkins.forName("sporecaller"),
        BroodStageSkins.forName("ironmaw"), BroodStageSkins.forName("overmind")
    };
    public RenderBroodElite() { super(new ModelBroodParasite(), 0.55F); }
    @Override protected ResourceLocation getEntityTexture(Entity entity) {
        int kind = entity instanceof EntityBroodElite.Ravager ? 0 :
            entity instanceof EntityBroodElite.Sporecaller ? 1 :
            entity instanceof EntityBroodElite.Ironmaw ? 2 : 3;
        return SKINS[kind][BroodStageSkins.phase(entity)];
    }
    @Override protected void preRenderCallback(EntityLivingBase entity, float partial) {
        float s=entity instanceof EntityBroodElite.Ironmaw ? 1.23F :
            entity instanceof EntityBroodElite.Overmind ? 1.17F : 1.08F;
        s *= BroodStageSkins.growth((Entity)entity);
        GL11.glScalef(s, s, s);
    }
}
