# 1.2.0 (source candidate, not verified JAR)
- Flying parasite entity and animated lightweight original mesh.
- Fliers from mature colonies once evolution reaches configurable stage 15.
- Server-tick-counted waves every configurable 15 gameplay days.
- Configurable sizes, per-wave miniboss, group handling, locality limits, ward/HBM radiation-safe spawning.
- Separate wave saved data, automatic chat warnings, test command.
- Two more creative spawning eggs, localization and adapted infection/skills.
- Retains all 1.1.1 features; does not include Minecraft runtime verification.
