package com.endlessbrood.client;

/** Small thread-safe state object. No Minecraft objects are touched on Netty thread. */
public final class BroodVictoryClientState {
    private static volatile boolean victory;
    private static volatile long startNanos;
    private static final long FADE_NS = 45_000_000_000L; // 45 seconds
    private BroodVictoryClientState() { }
    public static void accept(boolean defeated) {
        if(victory != defeated) {
            startNanos = System.nanoTime();
            victory = defeated;
        }
    }
    public static float daylightProgress() {
        if(!victory) return 0F;
        long since=System.nanoTime() - startNanos;
        if(since <= 0) return 0F;
        if(since >= FADE_NS) return 1F;
        return (float)((double)since/(double)FADE_NS);
    }
}
