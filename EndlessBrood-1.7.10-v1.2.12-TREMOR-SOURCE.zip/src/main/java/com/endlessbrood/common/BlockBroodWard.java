package com.endlessbrood.common;

import com.endlessbrood.EndlessBrood;
import java.util.List;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ChatComponentText;
import net.minecraft.world.World;
import net.minecraft.tileentity.TileEntity;

/** Slow, affordable early-game defensive tool that never loads nearby chunks. */
public final class BlockBroodWard extends Block {
    public BlockBroodWard() {
        super(Material.iron);
        setBlockName("endlessbrood.ward");
        setBlockTextureName("endlessbrood:ward");
        setHardness(3.0F);
        setResistance(12.0F);
        setHarvestLevel("pickaxe", 1);
        setCreativeTab(CreativeTabs.tabBlock);
        setLightLevel(0.35F);
    }

    /** Right-click with the NEXT upgrade tier. Metadata 0..3 is saved with the world. */
    @Override
    public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player,
                                    int side, float hitX, float hitY, float hitZ) {
        ItemStack held = player.getCurrentEquippedItem();
        if (held == null || held.getItem() != EndlessBrood.wardUpgrade) return false;
        if (world.isRemote) return true;
        int current = Math.min(3, world.getBlockMetadata(x, y, z));
        int target = held.getItemDamage();
        if (!BroodWardLevels.accepts(current, target)) {
            player.addChatMessage(new ChatComponentText("[Brood Ward] Need tier " +
                (current + 1) + " upgrade (current: " + current + ")."));
            return true;
        }
        world.setBlockMetadataWithNotify(x, y, z, target, 3);
        if (world.getTileEntity(x, y, z) == null)
            world.setTileEntity(x, y, z, new TileEntityBroodWard());
        if (!player.capabilities.isCreativeMode && --held.stackSize <= 0)
            player.inventory.setInventorySlotContents(player.inventory.currentItem, null);
        player.addChatMessage(new ChatComponentText("[Brood Ward] Tier " + target +
            " installed, radius " + BroodWardRules.radiusForTier(target) + "."));
        return true;
    }

    @Override
    public void onBlockAdded(World world, int x, int y, int z) {
        if (!world.isRemote) world.scheduleBlockUpdate(x, y, z, this, tickRate(world));
    }

    @Override
    public boolean hasTileEntity(int metadata) { return true; }

    @Override
    public TileEntity createTileEntity(World world, int metadata) {
        return new TileEntityBroodWard();
    }

    @Override
    public int tickRate(World world) {
        return BroodConfig.wardPulseTicks;
    }

    @Override
    @SuppressWarnings("unchecked")
    public void updateTick(World world, int x, int y, int z, Random random) {
        if (world.isRemote || world.getBlock(x, y, z) != this) return;
        world.scheduleBlockUpdate(x, y, z, this, tickRate(world));
        if (!BroodConfig.wardsEnabled) return;
        int tier = Math.min(3, world.getBlockMetadata(x, y, z));
        int radius = BroodWardRules.radiusForTier(tier);
        AxisAlignedBB area = AxisAlignedBB.getBoundingBox(x - radius, y - 4, z - radius,
            x + radius + 1, y + 5, z + radius + 1);
        List<EntityParasite> parasites = BroodLoadedEntities.find(world, EntityParasite.class, area);
        for (EntityParasite parasite : parasites) {
            if (!parasite.isDead) {
                // Slows enemies, but does not damage them or invalidate uncapped evolution.
                parasite.addPotionEffect(new PotionEffect(Potion.moveSlowdown.id,
                    Math.max(60, tickRate(world) + 20), Math.min(3, 1 + tier)));
                if (tier >= 1) parasite.addPotionEffect(new PotionEffect(Potion.weakness.id,
                    Math.max(60, tickRate(world) + 20), tier >= 3 ? 2 : 0));
                if (tier >= 3 && parasite.getDistanceSq(x + 0.5D, y + 0.5D, z + 0.5D)
                    <= 144.0D) {
                    parasite.attackEntityFrom(net.minecraft.util.DamageSource.magic, 2.0F);
                }
            }
        }
        // Reclamation is deliberately small and local (no huge chunk scans).
        for (int i = 0; i < 5 + tier * 2; ++i) {
            int nx = x + random.nextInt(radius * 2 + 1) - radius;
            int nz = z + random.nextInt(radius * 2 + 1) - radius;
            int ny = y + random.nextInt(5) - 2;
            if (ny > 0 && ny < 255 && world.blockExists(nx, ny, nz) &&
                world.getBlock(nx, ny, nz) == EndlessBrood.taintedSoil) {
                world.setBlock(nx, ny, nz, Blocks.dirt, 0, 3);
            }
        }
    }
}
