#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$root"
test -f src/main/java/com/endlessbrood/client/GuiBroodSkills.java
test -f src/main/java/com/endlessbrood/common/BroodSkillNetwork.java
test -f src/main/java/com/endlessbrood/common/BroodDigBudget.java
grep -q 'BroodSkillNetwork.register()' src/main/java/com/endlessbrood/EndlessBrood.java
grep -q 'BroodDigBudget.tryBreak' src/main/java/com/endlessbrood/common/EntityParasite.java
grep -q 'BroodBlockRules.canBreak' src/main/java/com/endlessbrood/common/EntityParasite.java
grep -q 'BroodAdaptiveMath.MELEE' src/main/java/com/endlessbrood/common/EvolutionData.java
grep -q 'category == BroodAdaptiveMath.RADIATION) return 0.0D' src/main/java/com/endlessbrood/common/EvolutionData.java
echo 'PASS: 1.3.4 GUI/network/terrain/adaptation wiring structural checks'
