package com.endlessbrood.common;

import java.math.BigInteger;

/** Cheap pure decisions shared by scouts and colony pulses. */
public final class BroodSpawnRules {
    private BroodSpawnRules() { }

    public static int patrolSize(BigInteger stage) {
        if (stage.compareTo(BigInteger.valueOf(3)) < 0) return 1;
        if (stage.compareTo(BigInteger.valueOf(12)) < 0) return 2;
        if (stage.compareTo(BigInteger.valueOf(40)) < 0) return 3;
        return 4;
    }

    public static int offspringCount(int tier) {
        return tier <= 0 ? 1 : (tier == 1 ? 2 : 3);
    }

    public static boolean mayConvert(boolean mobSpawning, boolean peaceful,
                                      boolean protectedByWard, boolean highlyRadioactive,
                                      int population, int cap) {
        return mobSpawning && !peaceful && !protectedByWard && !highlyRadioactive && population < cap;
    }

    public static boolean patrolDue(long ticks, int interval) {
        return interval > 0 && ticks % interval == 0L;
    }
}
