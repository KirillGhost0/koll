## v1.3.6 — Daily evolution 260 points

See CHANGELOG_1_3_6.md.

## 1.2.12 — Dread Tremor & Early Infection

Симметричные ноги босса, низкий звук шагов, мягкая качка камеры на клиенте, разведчики с 1 дня и первые гнёзда с 3 дня. Подробности — TREMOR_1_2_12_RU.md.

v1.2.9: ONE 3-block horror boss every five waves; balanced fewer normal mobs in boss waves. See CHANGELOG_1_2_9.md.
# 1.2.7 SWARM BALANCE — минус 20% существ в волнах, в 5 раз меньше лута

См. `BALANCE_1_2_7_RU.md`.

# 1.2.6 SWARM TACTICS

# Endless Brood 1.2.6 — SWARM TACTICS / Тактика роя

Версия объединяет всё из **1.2.5 DREAD** с согласованными атаками. Никаких отдельных аддонов устанавливать не нужно.

## Что изменено
- **Передача цели:** каждые 100 тиков (со смещением по ID) паразит с целью оповещает соседей в 24 блоках. За одно оповещение подключается до 6 союзников, включая Крыланов.
- **Окружение:** лёгкие наземные особи выбирают стабильные роли и подходят к жертве с флангов, когда видят её на расстоянии 8–25 блоков. Бастион, Колосс, Матка и Командир идут напролом.
- **Авиация:** Крыланы распределяются по разным секторам вокруг жертвы до пикирования. Существующие предупреждающие крики, атаки и отлёт после удара сохранены.
- **Командир:** во время усиления группы передаёт цель наземным и воздушным бойцам.
- **Два игрока:** у разных существ остаются собственные цели и роли; блокировка волн на определённого игрока имеет приоритет перед обычной охотой.
- **Безопасность для HBM:** никаких дополнительных спавнов, телепортации, взрывов, загрузки чанков и разрушения защищённых блоков.

Настройки `config/endlessbrood.cfg`, раздел `[swarmTactics]`: `enableSwarmTactics`, `signalRadius`, `signalIntervalTicks`, `maxFollowersPerSignal`, `flankRepathTicks`, `flankUnlockStage`, `groundFlankRadius`, `flierOrbitRadius`. Новые поля появятся в существующем конфиге после запуска. Стандартные значения: true, 24, 100, 6, 55, 12, 4.5, 6.5.

**Важное:** логика написана и проверяется локальными автономными тестами, но реальная сборка Forge 1.7.10, ИИ и совместимость с NTM должны пройти проверку в игре. Не устанавливайте не проверенный JAR в единственную копию сохранения. До испытания замените JAR только в тестовой сборке у всех игроков и на сервере.

---

## 1.1.1 (2026-10-25) — HBM radiation and long-world outbreak fix
- Optional reflection integration with HBM NTM chunk radiation: mob damage, retreat, radiation-suppressed colonies, and irradiated tainted soil restored to vanilla dirt.
- First outbreaks remain 768 blocks away, then home-zone natural-spawn/seed restriction approaches the base over 40 real Minecraft days after grace period.
- `/broodstage` shows REAL loaded server days (not `/time set`), grace and effective home radius, and seeded distant colony count.
- Never forces chunk loads or silently wipes existing saved evolution.
- Needs Forge 1.7.10 CI build and in-game integration verification.

## 1.1.0
- Combined RC3 infection fix, RC4 aggression fix, and HBM block protections into one mod.
- Loaded-chunk-only scanner search radius increased to 256 blocks, with ten-second cooldown.
- Ward upgrade tiers 1/2/3, effective horizontal radii 14/22/32 (base 8), weakness and stronger effects; tier three inflicts limited damage.
- Efficient loaded-chunk ward lookup via a passive tile entity marker; existing placed wards should be re-placed when upgrading.
- Four new drop items, two parasite-material weapons, a full armor set, recipes and generated pixel textures.
- Persistent server-side survivor leveling from parasite kills, five rankable skills, craftable codex, retained after death.
- Included new isolated pure Java smoke tests and GitHub Actions workflow for 1.1.0.
- Full Forge 1.7.10 compilation/runtime not verified for this release.

## 1.0.0-rc4 — Aggression fix
- Aggressive target acquisition unified across all living prey (except brood allies and creative players).
- Sensed within 8 blocks, line of sight out to 24 blocks, scans staggered every 20 ticks.
- Nearest victim prioritized rather than permanently preferring players over nearby animals.
- Server-side bounding-box scans only, never chunk loads.
- Preserves HBM block immunity and RC3 infection conversion.

## RC3 — дополнительный патч защиты HBM (исходники)

- Явная постоянная защита арматурного / сверхпрочного бетона и усиленного стекла/панелей HBM, включая регистрацию с префиксом `tile.`.
- Все блоки пространства имён `hbm:` категорически исключены из прогрызания вне зависимости от эволюции и конфигурации мира.
- Обновлены комментарии к списку защитных блоков; добавлены Java-регрессионные тесты для поздних стадий.
- Защита не влияет на разрушения от чужих взрывов, в том числе оружия NTM.

## 1.0.0-rc3 — fatal infection conversion (2026-10-25)

- Convert eligible hosts on lethal parasite hits (65% base chance or 100% if already infected, subject to population cap).
- Keep timed infections alive at population cap for retry.
- Infection system remains server-side and multiplayer-compatible by design.

# Changelog

## 1.0.0-rc2 — distant first infection (2026-10-25)

**Still source-only; not compiled with real Forge or tested in Minecraft.**

- Outbreaks start at least **768 blocks from the vanilla world spawn and all starting positions of co-op players** who join during the installation grace period. Starting positions are saved in world NBT.
- **Three Minecraft days of grace counted from first installation**, not from world age. Existing `config/endlessbrood.cfg` settings are not forcibly overwritten (if old `threatGraceDays=1`, edit it to `3`).
- New terrain seeds nests only after grace and beyond the safety radius, without generating them next to online players.
- **Existing explored world support:** up to two rare distant starter nests may be seeded in already generated, *currently loaded* chunks when someone explores beyond the safe radius. The algorithm never forces chunk loading, does not scan disk or modify near-base chunks.
- Random vanilla parasite spawning is suppressed inside remembered starting-base zones, but **external colonies and their offspring can still enter** and eventually attack the base. This is a spawning rule, not a protective force field; use brood wards/obsidian as before.
- New configurable options: `initialOutbreakDistance`, `outbreakPlayerBuffer`, `retroactiveDistantNests`, `retroSeedLimit`, `retroSeedIntervalTicks`, `blockNaturalSpawnInHomeZones`.
- Added pure Java regression tests for relative grace / extreme world coordinates / distance boundary, with Forge build and gameplay still pending.

## 1.0.0-rc1 — source release candidate (2026-10-25)

Not an installable mod JAR. ForgeGradle and in-game multiplayer have NOT been verified.

- **Colony patrols**: nest-born parasites remember their home, wander back when idle and too far away, and persist their home coordinates in NBT. The guard AI never scans for nests or loads an unloaded nest chunk.
- **Matriarch defensive alarm**: a hurt matriarch can call a limited number of already-present nearby defenders against its attacker. The action is time- and population-limited and excludes attacking creative-mode players.
- **Ward-safe natural spawning**: default wards now reject natural parasite spawning within their protected zone; they already blocked nest spawning, soil conversion, and tunnelling.
- **NTM-friendly starting grace**: newly created worlds have one default in-game day (20 minutes at 20 TPS) before passive evolution or natural/colony parasite spawning starts. The grace duration is configurable, is based on total world time, and does not affect creative test eggs. Pre-existing worlds beyond the threshold are unaffected.
- **Arbitrary-precision save format**: evolution progress is now persisted as a binary BigInteger byte array. Worlds saved by 0.1–0.9 using the original string `Points` key still load; 1.0.0-rc1 will write the new binary format. Back up worlds before downgrading.
- Added pure Java regression assertions for grace, ward gating, and nest patrol distance. Existing stage, protected block, mutation, adaptation, colony, client-renderer stub, and PNG checks retained.
- Updated mod metadata, build artifact labels, Russian release checklist and documentation.


## Previous versions

## 0.9.0 — village raids, colony alarms and AI load distribution (source candidate)

- Added bounded **night village navigation**: once global evolution reaches stage 20, idle parasites may periodically seek a nearby *inhabited* registered vanilla village (within 48 blocks). Existing target AI selects villagers when within reach. No extra mobs are spawned, no chunks loaded deliberately, and raid pathfinding ends at daytime, when targets appear or when navigation ends. This is a basic raiding mechanic, not a siege simulation.
- Added **colony defense alarms**: attacking/clicking or harvesting a nest draws at most 6 existing nearby guards (18-block default), ignoring creative-mode players. Does not clone parasites or blow up terrain.
- Added optional **matriarch support heal**: up to four injured allies regain just 1 health per existing rally pulse; no unlimited group regeneration.
- **Performance**: staggered target-sharing scans every 160 ticks per parasite instead of synchronized every 100 ticks, also staggered periodic attribute refresh. Search radius and timing of raids and guard limits are configurable.
- Added `BroodRaidRules` pure Java stage/night/range gates with smoke test assertions.
- Retained never-break obsidian/bedrock/portal-frame rule, modded-block protection, slow unlimited evolution and all six original models.
- **Important:** verified pure Java policy tests and resources only; NOT compiled with actual Minecraft Forge and NOT gameplay tested.

## 0.8.0 — evolving colonies + matriarch (source candidate)

- Added a full sixth 3D mesh/skin for the brood matriarch, with summon egg, multiple crown horns, rear egg sac, moving jaws and legs, synced in multiplayer via morph DataWatcher.
- Added model accessories for phenotype traits: extra armor plate (Brute/Plates), spore sac (Spores) and horn (Swift).
- Converted nest metadata into persistent colony tiers Seed (0), Mature (1), Citadel (2). Old nests stay at metadata 0. Added two 16×16 variant nest textures.
- New `BroodColonyRules`: pure deterministic stage thresholds, bounded upgrades, tier-specific spawning and gated rare leaders. Smoke tests cover 10^3000 stages.
- Seed -> Mature unlock at stage 12; Mature -> Citadel at stage 50. Both have a 1/16 chance per existing 2400-tick pulse, default config.
- Matriarchs become eligible at stage 60 and require a citadel; a 30-block local check prevents spamming. Every 200 ticks nearby parasites temporarily receive speed and up to six receive Strength I, with local target coordination.
- Daughter nests now grow only from citadels; new nests start at tier 0. World/ward checks guard all new colony logic.
- Kept slow NTM pacing, endless global stage, hard-block digging exclusions and conservative mob population caps unchanged.
- Validated pure Java rule tests, client mesh stub compile and PNG integrity. **Real Forge 1.7.10 compilation and gameplay remain unverified.**

# Changelog

## 0.7.0 — NTM co-op pacing, permanent safe zones and scouting (source candidate)
- Added a **persistent shared daily budget for kill/conversion progression** (`combatPointsPerDay`, default 90 per 24000 world ticks); passive evolution always advances. This keeps high-yield mob farms and two-player kill streaks from bypassing industrial tech progression. Budget rolls over with total world ticks (not `/time set`) and is stored in world-save NBT.
- Long-term colony expansion is **8× slower** by default: nest daughter attempt chance changed from 1/15 pulses to configurable 1/120 (the evolution stages themselves remain uncapped).
- **Brood Repelling Wards** now actually prevent our parasites from digging permitted blocks inside their radius; parasite AI checks protection only at final break to avoid per-tick 3D scans. Wards additionally block tainted-soil spread inside their zone.
- New craftable **Brood Signal Scanner** with a 16×16 icon: right-click shows nearby parasite count, distance and cardinal direction of nearest threat; a three-second cooldown prevents spam.
- The `/broodstage` command now shows how much event-based growth the shared world used today; extended pure-Java budget tests and texture smoke tests.
- Changed the tile-entity safety check on breakable blocks to the metadata-aware Forge signature. Vanilla obsidian, bedrock and end-portal frames remain always immune; all modded HBM/NTM blocks remain outside the dig allowlist.
- **Still source only**. Full Forge compilation, dedicated server simulation and HBM/NTM testing are intentionally deferred; this is NOT a verified playable JAR.


## 0.6.0 — combat roles, survival defenses, server performance pass (source candidate)
- Added craftable **Brood Repelling Ward** (chitin, iron and redstone), textured as a 32x32 block, with capped local pulses. It slows invading parasites and gradually reclaims adjacent corrupted soil. Colonies cannot spawn inside an active ward radius. Ward power and radius are configurable.
- Combat now differs by body plan: Scuttlers make short cooldown-bound lunges; Bulwarks mitigate 20% of blockable damage; Thornbacks hurt adjacent melee attackers; rare Colossi emit non-explosive slowness/weakness roars (all configurable).
- Serum now cleanses one tainted-soil block per use and is consumed on a player only if that player actually has poison or slowdown. Infectable mobs visibly show weakness particles when first infected.
- Tainted soil now respects `/gamerule mobGriefing false`, as advertised. Ward scans are avoided in the frequent random-soil tick path to keep NTM servers responsive.
- Protected obsidian/bedrock/end-portal-frame logic, modded-block allowlist policy, threefold slower evolution, unbounded stage arithmetic, original five 3D models, multiplayer DataWatcher genetics and rare colony expansion retained.
- Updated source version, creative block locale entries, texture inventory, README and GitHub Actions artifact label.
- **Unverified against real Forge / Minecraft** as requested: feature work first, build and live testing afterwards. Version 0.6.0 is not a playable JAR.

## 0.5.0 — broad gameplay systems, unverified Forge candidate
- Fifth original animated morph (Colossus) with separate 128×64 texture and egg; unusual late-game spawn near nests.
- Stackable genome traits (plates, swiftness, spores, regenerative), persistent and client-synchronized.
- Server-side collective resistance from accumulated fire, explosion, projectile and radiation-named damage; never complete immunity.
- Rare, small world-generated nests, throttled brood production and guarded nest expansion after stage 40.
- Original tainted soil with depth-limited spread and a mild movement hazard.
- Original chitin material and serum item with crafting, antidote use for player/pets/villagers, and parasite death drops.
- Coordinated parasite targeting at stage 12+, tamed-animal conversion protection.
- Added configuration switches for each expensive mechanic, updated locale entries and GitHub Actions artifact version.
- Expanded pure-Java and model/texture validation; these tests are *not* Forge compilation or game launch.

## 0.4.0 — creative eggs for four morphs
## 0.3.0 — original 3D models, textures and animations
## 0.2.0 — 3x slowdown, protected blocks and mutations
## 0.1.0 — infection, first parasite and BigInteger evolution

## 1.3.0 — ABYSSAL REALM (unverified Forge build)
- Four guaranteed distinct Dread Seals from four successive Sovereign defeats; the 20% ordinary drop chance does not affect the quest seals.
- Four unique craftable abyss corner anchors with 4x4 ground portal formation and reversible teleportation.
- New independent dimension provider and chunk generator: deterministic floating infected islands, reachable paths, distant fortress walls/towers.
- Dedicated realm spawns with bounded local population, persistent four Sovereign guardians and a 5-block, ~1280 HP, distinct-texture final boss.
- Configurable default dimension ID 74 with conflict detection; new items and blocks registered in Forge.
- Gameplay not validated in an actual Forge instance yet; please test in backup worlds first.

## 1.3.1 — FINAL PURIFICATION (Forge 1.7.10, source project)

- Defeating **Abyss Overlord / Сердце Бездны** permanently ends the outbreak in the current save.
- Immediately removes all currently loaded Brood mobs from all loaded dimensions without spawning drops.
- Cancels future Brood entity creation (including old entities loaded from disk), deactivates waves, nest growth, scouts, passive evolution and infections.
- Removes infected animal incubation tags.
- Converts mod-specific tainted soil back into vanilla dirt and removes parasite nests, limited to 4096 block inspections and 64 modifications per world tick. Unloaded terrain is **not** force-loaded; it cleans on the next chunk load.
- Generates future Abyss islands with normal dirt instead of infection soil after victory.
- Keeps player-built HBM machines and the portal structures untouched.
- Code smoke-tested with project tests and Java 8 API-shaped stubs. Full Forge build and in-game testing pending.

1.3.2 Victory Relics: Abyssal Heart drop, 12 essence conversion, full set of armor, reaver, trophy, 45-second clear sky synchronization.

## 1.3.2 QA2 — Realm & grounded-boss hotfix
- Исправлено отсутствие паразитов при исследовании Бездны в творческом режиме.
- Улучшено создание серверных групп и учёт только паразитов в локальном лимите.
- Исправлено визуальное парение Владыки ужаса: смещены корневые узлы модели на 24px, не затрагивая вложенные ноги и челюсти.
- Геометрия островов больше не использует высокочастотные колебания толщины, напоминающие вертикальные заборы.
- На безопасном пути к далёкой крепости (384,384) добавлены маяки, а команда `/broodtest fortress` выводит координаты.
- Добавлены регрессионные тесты положения ног, формы островов и указателей дороги.

## 1.3.3 — Calendar Infection

- Waves at absolute Overworld days 15, 30, 45..., even if added to a pre-existing world.
- In-world save migration and no backlog of past waves after /time jumps.
- Mycelium-like infected-soil spread with world-age acceleration and no age-3 dead-end.
- Day 20–29 passive-herd parasite infiltration, day 30+ natural passive-herd replacement.
- Late-world scouting cadence and size rise under existing hard performance caps.
- Infected-host conversion and tainted-ground contagion also scale mildly with world day (bounded).
- Added `calendarInfection` config and focused Java smoke tests.
