package com.endlessbrood.common;

import java.util.List;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.util.IIcon;

public final class ItemAbyssFragment extends Item {
    private IIcon[] icons=new IIcon[4];
    public ItemAbyssFragment() {
        setUnlocalizedName("endlessbrood.abyssFragment");
        setTextureName("endlessbrood:abyss_fragment");
        setHasSubtypes(true);
        setMaxDamage(0);
        setCreativeTab(CreativeTabs.tabMaterials);
    }
    @Override public void registerIcons(IIconRegister register) {
        for(int i=0;i<4;i++) icons[i]=register.registerIcon("endlessbrood:abyss_fragment_"+i);
        itemIcon=icons[0];
    }
    @Override public IIcon getIconFromDamage(int damage) { return icons[damage&3]; }
    @Override public String getUnlocalizedName(ItemStack stack) {
        return super.getUnlocalizedName() + "." + (stack.getItemDamage() & 3);
    }
    @Override @SuppressWarnings({"rawtypes", "unchecked"})
    public void getSubItems(Item item, CreativeTabs tab, List results) {
        for (int i=0; i<4; i++) results.add(new ItemStack(item, 1, i));
    }
    @Override @SuppressWarnings({"rawtypes", "unchecked"})
    public void addInformation(ItemStack stack, EntityPlayer player, List lines, boolean advanced) {
        lines.add("§5Печать Владыки ужаса: " + ((stack.getItemDamage() & 3) + 1) + "/4");
        lines.add("§7Создаёт угловой якорь портала Бездны");
    }
}
