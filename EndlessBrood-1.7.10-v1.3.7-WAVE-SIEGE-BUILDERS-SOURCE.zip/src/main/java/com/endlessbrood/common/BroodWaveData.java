package com.endlessbrood.common;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraft.world.WorldSavedData;

/** World-owned invasion clock: absolute Overworld calendar, independent of mod installation. */
public final class BroodWaveData extends WorldSavedData {
    private static final String ID = "endlessbrood_invasion_waves";
    /** Legacy counter from pre-1.3.3 saves; retained only for save compatibility. */
    public long playedTicks;
    public int lastCalendarCycle;
    public boolean calendarInitialized;
    public int waveIndex;
    public int waveTicksLeft;
    public int spawned;
    public boolean bossSpawned;
    public boolean warned;
    public boolean debugWave;
    public int failedPlacement, blockedByCap, noTargets;
    public int plannedTotal, spawnedRegular;
    public int waveBuildersSpawned;
    // Fixed staircase entrances for invasion mobs, persisted across a save/reload.
    public int[] builderX = new int[BroodSiegeBuilderRules.BUILDERS_PER_WAVE];
    public int[] builderY = new int[BroodSiegeBuilderRules.BUILDERS_PER_WAVE];
    public int[] builderZ = new int[BroodSiegeBuilderRules.BUILDERS_PER_WAVE];
    public int[] eliteQuotas = new int[BroodEliteWaveRules.CASTES];
    public int[] eliteSpawned = new int[BroodEliteWaveRules.CASTES];

    public BroodWaveData() { super(ID); }
    public BroodWaveData(String name) { super(name); }
    public static BroodWaveData get(World world) {
        BroodWaveData data = (BroodWaveData) world.loadItemData(BroodWaveData.class, ID);
        if (data == null) {
            data = new BroodWaveData(ID);
            world.setItemData(ID, data);
        }
        return data;
    }
    @Override
    public void readFromNBT(NBTTagCompound tag) {
        playedTicks = Math.max(0L, tag.getLong("PlayedTicks"));
        lastCalendarCycle = Math.max(0, tag.getInteger("LastCalendarCycle"));
        calendarInitialized = tag.getBoolean("CalendarInitialized");
        waveIndex = Math.max(0, tag.getInteger("WaveIndex"));
        waveTicksLeft = Math.max(0, tag.getInteger("WaveTicksLeft"));
        spawned = Math.max(0, tag.getInteger("Spawned"));
        bossSpawned = tag.getBoolean("BossSpawned");
        warned = tag.getBoolean("Warned");
        debugWave = tag.getBoolean("DebugWave");
        failedPlacement = Math.max(0, tag.getInteger("FailedPlacement"));
        blockedByCap = Math.max(0, tag.getInteger("BlockedByCap"));
        noTargets = Math.max(0, tag.getInteger("NoTargets"));
        plannedTotal = Math.max(0, tag.getInteger("PlannedTotal"));
        spawnedRegular = Math.max(0, tag.getInteger("SpawnedRegular"));
        waveBuildersSpawned = Math.max(0, Math.min(BroodSiegeBuilderRules.BUILDERS_PER_WAVE, tag.getInteger("WaveBuildersSpawned")));
        int[] bx = tag.getIntArray("BuilderX"), by = tag.getIntArray("BuilderY"), bz = tag.getIntArray("BuilderZ");
        if (bx.length == builderX.length && by.length == builderY.length && bz.length == builderZ.length) {
            builderX = bx; builderY = by; builderZ = bz;
        } else waveBuildersSpawned = 0;
        int[] q = tag.getIntArray("EliteQuotas");
        int[] n = tag.getIntArray("EliteSpawned");
        if (q.length == BroodEliteWaveRules.CASTES) eliteQuotas = q;
        if (n.length == BroodEliteWaveRules.CASTES) eliteSpawned = n;
    }
    @Override
    public void writeToNBT(NBTTagCompound tag) {
        tag.setLong("PlayedTicks", playedTicks);
        tag.setInteger("LastCalendarCycle", lastCalendarCycle);
        tag.setBoolean("CalendarInitialized", calendarInitialized);
        tag.setInteger("WaveIndex", waveIndex);
        tag.setInteger("WaveTicksLeft", waveTicksLeft);
        tag.setInteger("Spawned", spawned);
        tag.setBoolean("BossSpawned", bossSpawned);
        tag.setBoolean("Warned", warned);
        tag.setBoolean("DebugWave", debugWave);
        tag.setInteger("FailedPlacement", failedPlacement);
        tag.setInteger("BlockedByCap", blockedByCap);
        tag.setInteger("NoTargets", noTargets);
        tag.setInteger("PlannedTotal", plannedTotal);
        tag.setInteger("SpawnedRegular", spawnedRegular);
        tag.setInteger("WaveBuildersSpawned", waveBuildersSpawned);
        tag.setIntArray("BuilderX",builderX);
        tag.setIntArray("BuilderY",builderY);
        tag.setIntArray("BuilderZ",builderZ);
        tag.setIntArray("EliteQuotas", eliteQuotas);
        tag.setIntArray("EliteSpawned", eliteSpawned);
    }
}
