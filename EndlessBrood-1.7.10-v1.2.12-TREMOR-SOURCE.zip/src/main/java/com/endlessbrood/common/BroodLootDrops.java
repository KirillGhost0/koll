package com.endlessbrood.common;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.Item;

/** All mod-material drops pass through one central fivefold loot reduction.
 *  Server-only; don't modify vanilla/NTM drops or experience rewards.
 */
public final class BroodLootDrops {
    private BroodLootDrops() { }

    public static void roll(EntityLivingBase source, Item material, int originalCount) {
        if (source == null || source.worldObj.isRemote || material == null) return;
        int count = BroodLootRules.countKept(originalCount,
            BroodConfig.parasiteLootPercent, source.getRNG());
        if (count > 0) source.dropItem(material, count);
    }
}
