package com.endlessbrood.common;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.world.World;

/** Illuminated trophy with client particles; no tile entity or tick handler. */
public final class BlockAbyssTrophy extends Block {
    public BlockAbyssTrophy() {
        super(Material.rock);
        setBlockName("endlessbrood.abyssTrophy");
        setBlockTextureName("endlessbrood:abyss_trophy");
        setHardness(6.0F);
        setResistance(250.0F);
        setLightLevel(0.7F);
        setCreativeTab(CreativeTabs.tabDecorations);
    }
    @Override public void randomDisplayTick(World world, int x, int y, int z, Random rand) {
        if(rand.nextInt(3) != 0) return;
        double dx=(rand.nextDouble()-.5D)*0.8D;
        double dz=(rand.nextDouble()-.5D)*0.8D;
        world.spawnParticle("portal", x+.5D+dx, y+.8D+rand.nextDouble()*.45D,
            z+.5D+dz, dx*.12D, 0.02D, dz*.12D);
    }
}
