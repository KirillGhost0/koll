package com.endlessbrood.client;

import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public final class RenderBroodSkyreaper extends RenderLiving {
    private static final ResourceLocation[] TEXTURES = BroodStageSkins.forName("skyreaper");
    public RenderBroodSkyreaper() { super(new ModelBroodFlier(), 0.55F); }
    @Override protected ResourceLocation getEntityTexture(Entity entity) { return TEXTURES[BroodStageSkins.phase(entity)]; }
    @Override protected void preRenderCallback(EntityLivingBase e, float tick) {
        float growth = BroodStageSkins.growth((Entity)e);
        GL11.glScalef(1.36F*growth,1.2F*growth,1.36F*growth);
    }
}
