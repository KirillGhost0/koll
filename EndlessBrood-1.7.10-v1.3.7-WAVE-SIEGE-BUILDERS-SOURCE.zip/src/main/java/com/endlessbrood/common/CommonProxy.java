package com.endlessbrood.common;

public class CommonProxy {
    public void openSkillGui() { }
    public void acceptSkillSnapshot(int level, int xp, int next, int points, int[] ranks) { }
    public void registerRenderers() {
        // Nothing to render on a dedicated server.
    }
}
