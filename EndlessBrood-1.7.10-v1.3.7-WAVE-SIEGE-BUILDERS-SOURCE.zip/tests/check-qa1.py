from pathlib import Path

root = Path(__file__).resolve().parents[1]
common = root / 'src/main/java/com/endlessbrood/common'

def source(name):
    return (common / name).read_text(encoding='utf-8')

wave = source('BroodWaveTicker.java')
assert 'data.waveTicksLeft = WAVE_TICKS - 20;' in wave, 'no double first wave pulse'
assert 'spawnPulse(world, data);' in wave

realm = source('BroodRealmTicker.java')
assert 'if (!w.spawnEntityInWorld(finalBoss)) return;' in realm
assert 'for (Entity prior : spawned) prior.setDead();' in realm
assert 'if (!BroodLoadedEntities.find(w, EntityBroodAbyssOverlord.class' in realm
assert realm.index('w.spawnEntityInWorld(finalBoss)') < realm.index('w.spawnEntityInWorld(guardian)')
assert 'w.getBlock(x,144,z)' not in realm, 'fortress must not explicitly force chunk access'

skills = source('BroodSkills.java')
assert 'selected < 0 || selected >= KEYS.length' in skills
assert skills.index('selected < 0 || selected >= KEYS.length') < skills.index('data.setInteger(KEYS[selected]')

rad = source('BroodRadiationBehavior.java')
assert 'BroodAiBudget.tryPath(world)' in rad
assert 'Math.min(12.0D, length)' in rad

chunk = source('ChunkProviderBrood.java')
assert chunk.count('BroodVictoryData.isDefeated(world)') == 1
assert 'purified ? Blocks.dirt : EndlessBrood.taintedSoil' in chunk

workflow = (root / '.github/workflows/build.yml').read_text(encoding='utf-8')
assert '1.3.2-QA1' in workflow
print('PASS: QA1 regression guards (first-wave burst, boss duplication, loaded-only checks, skill bounds, radiation A*, chunk generation cache)')
