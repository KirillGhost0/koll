package com.endlessbrood.common;

import java.math.BigInteger;

/** Pure numeric policy shared by production tickers and smoke tests. */
public final class BroodSiegeRules {
    private BroodSiegeRules() { }

    public static boolean allowed(BigInteger stage, int unlockStage,
                                  boolean graceExpired, boolean homeAreaOpen) {
        return graceExpired && homeAreaOpen &&
            stage.compareTo(BigInteger.valueOf(unlockStage)) >= 0;
    }

    public static int packSize(int requested, BigInteger stage, int localCount, int cap) {
        int safe = Math.min(16, Math.max(0, requested));
        if (stage.compareTo(BigInteger.valueOf(100L)) >= 0)
            safe = Math.min(16, safe + 4);
        return Math.min(safe, Math.max(0, cap - localCount));
    }
}
