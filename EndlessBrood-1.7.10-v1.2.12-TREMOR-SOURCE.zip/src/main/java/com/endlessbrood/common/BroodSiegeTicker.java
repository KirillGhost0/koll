package com.endlessbrood.common;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;

/** Short-range recurring assaults after the initial safe-zone has receded.
 * Never loads chunks; co-op players in one base share a local entity limit.
 * A stable interval is independent of /time set, but /broodtest days/stage
 * can be used to simulate readiness on an isolated test world.
 */
public final class BroodSiegeTicker {
    @SubscribeEvent
    public void tick(TickEvent.WorldTickEvent event) {
        World world = event.world;
        if (event.phase != TickEvent.Phase.END || world.isRemote ||
            world.provider.dimensionId != 0 || !BroodConfig.siegeEnabled ||
            world.difficultySetting == EnumDifficulty.PEACEFUL ||
            !world.getGameRules().getGameRuleBooleanValue("doMobSpawning") ||
            world.playerEntities.isEmpty() ||
            world.getTotalWorldTime() % BroodConfig.siegeIntervalTicks != 0L) return;
        BroodOutbreakData outbreak = BroodOutbreakData.get(world);
        if (!outbreak.graceExpired(world.getTotalWorldTime()) ||
            EvolutionData.get(world).getStage().compareTo(
                BigInteger.valueOf(BroodConfig.siegeUnlockStage)) < 0) return;
        List<EntityPlayer> groups = new ArrayList<EntityPlayer>();
        for (Object o : world.playerEntities) {
            if (!(o instanceof EntityPlayer)) continue;
            EntityPlayer p = (EntityPlayer) o;
            if (p.isDead || p.capabilities.isCreativeMode ||
                !BroodSiegeRules.allowed(EvolutionData.get(world).getStage(),
                    BroodConfig.siegeUnlockStage, true,
                    outbreak.naturalSpawnsAllowed(world, p.posX, p.posZ))) continue;
            boolean nearby = false;
            for (EntityPlayer g : groups) if (p.getDistanceSqToEntity(g) < 128D * 128D) {
                nearby = true;
                break;
            }
            if (!nearby && groups.size() < 2) groups.add(p);
        }
        for (EntityPlayer player : groups) siege(world, player);
    }

    private void siege(World world, EntityPlayer player) {
        AxisAlignedBB box = player.boundingBox.expand(64D, 25D, 64D);
        int existing = BroodLoadedEntities.find(world, EntityParasite.class, box).size()
            + BroodLoadedEntities.find(world, EntityBroodFlier.class, box).size();
        BigInteger stage = EvolutionData.get(world).getStage();
        int allowance = BroodSiegeRules.packSize(
            Math.min(16, BroodConfig.siegePackSize + BroodConfig.siegeExtraPackSize),
            stage, existing, BroodConfig.effectiveSiegeCap());
        for (int i = 0; i < allowance; i++) {
            if (!spawnOne(world, player, stage)) break;
        }
    }

    private boolean spawnOne(World world, EntityPlayer target, BigInteger stage) {
        for (int attempt = 0; attempt < 24; attempt++) {
            double angle = world.rand.nextDouble() * Math.PI * 2D;
            int distance = 18 + world.rand.nextInt(18);
            int x = MathHelper.floor_double(target.posX + Math.cos(angle) * distance);
            int z = MathHelper.floor_double(target.posZ + Math.sin(angle) * distance);
            if (!world.blockExists(x, 64, z)) continue;
            int y = world.getHeightValue(x, z);
            if (y < 45 || y >= 234 || !world.blockExists(x, y + 5, z) ||
                !world.isAirBlock(x, y, z) || !world.isAirBlock(x, y + 1, z) ||
                !world.getBlock(x, y - 1, z).getMaterial().isSolid() ||
                BroodWardRules.protects(world, x, y, z) ||
                BroodRadiationBridge.getRadiation(world, x, y, z) >=
                    BroodConfig.radiationFearThreshold) continue;
            boolean flier = stage.compareTo(BigInteger.valueOf(
                BroodConfig.flyerUnlockStage)) >= 0 && world.rand.nextInt(4) == 0;
            Entity entity;
            if (flier) {
                EntityBroodFlier flying = new EntityBroodFlier(world);
                flying.setPosition(x + 0.5D, y + 3.0D, z + 0.5D);
                flying.setSiegeTarget(target);
                entity = flying;
            } else {
                EntityParasite ground = new EntityParasite(world);
                ground.setPosition(x + 0.5D, y, z + 0.5D);
                ground.setAttackTarget(target);
                if (stage.compareTo(BigInteger.valueOf(50)) >= 0 && world.rand.nextInt(5) == 0)
                    ground.configureSpawnMorph(2);
                entity = ground;
            }
            if (!world.checkNoEntityCollision(entity.boundingBox) ||
                !world.getCollidingBoundingBoxes(entity, entity.boundingBox).isEmpty()) continue;
            if (world.spawnEntityInWorld(entity)) return true;
        }
        return false;
    }
}
