# Endless Brood 1.3.6 — Double Growth

- Combat budget 90 → 180 per 24,000 total-world ticks.
- Passive growth 40 → 80 points per standard Minecraft day, using new `evolution.passiveGrowthMultiplier=2`.
- Combined *theoretical* daily maximum 130 → 260 (1.3 + 1.3 stages/day at stage cost 100).
- First-load migration for saved `combatPointsPerDay=90` to 180; other custom values preserved; marker prevents repeated migration.
- Existing world evolution points are untouched.
- `/broodstage` displays combat budget and projected total per day.
- Not runtime-tested in Forge 1.7.10 / HBM NTM.
