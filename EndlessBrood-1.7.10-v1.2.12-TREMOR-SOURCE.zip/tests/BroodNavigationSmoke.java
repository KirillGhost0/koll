package test;
import com.endlessbrood.common.BroodNavigationRules;
public final class BroodNavigationSmoke {
    public static void main(String[] args) {
        if (BroodNavigationRules.requiresWayPoint(20D*20D)) throw new AssertionError("20 blocks close");
        if (!BroodNavigationRules.requiresWayPoint(150D*150D)) throw new AssertionError("150 blocks still detected");
        double[] hop = BroodNavigationRules.shortWaypoint(0D,0D,150D,0D,12D);
        if (Math.abs(hop[0]-12D)>0.00001D || Math.abs(hop[1])>0.00001D) throw new AssertionError("bounded 12 block route");
        double[] shortHop = BroodNavigationRules.shortWaypoint(0D,0D,6D,8D,12D);
        if (Math.abs(shortHop[0]-6D)>0.00001D || Math.abs(shortHop[1]-8D)>0.00001D) throw new AssertionError("short range");
        double[] clamp = BroodNavigationRules.shortWaypoint(0D,0D,150D,0D,999D);
        if (clamp[0] > 14.001D) throw new AssertionError("safe bound");
        System.out.println("OK: bounded pathfinding targets and unchanged long-range sensing");
    }
}
