package com.endlessbrood.common;

import com.endlessbrood.EndlessBrood;
import java.util.Collection;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.tileentity.TileEntity;

/** Search loaded chunk TE maps, not 60,000 block positions per check. */
public final class BroodWardRules {
    private BroodWardRules() { }
    public static int radiusForTier(int tier) {
        int base = BroodConfig.wardRadius;
        return BroodWardLevels.radius(base, tier);
    }
    public static boolean protects(World world, int x, int y, int z) {
        if (!BroodConfig.wardsEnabled) return false;
        int max = radiusForTier(3);
        int minCx = (x - max) >> 4, maxCx = (x + max) >> 4;
        int minCz = (z - max) >> 4, maxCz = (z + max) >> 4;
        for (int cx = minCx; cx <= maxCx; ++cx) {
            for (int cz = minCz; cz <= maxCz; ++cz) {
                if (!world.getChunkProvider().chunkExists(cx, cz)) continue;
                Chunk chunk = world.getChunkFromChunkCoords(cx, cz);
                for (Object entry : chunk.chunkTileEntityMap.values()) {
                    if (!(entry instanceof TileEntityBroodWard)) continue;
                    TileEntity ward = (TileEntity) entry;
                    if (ward.isInvalid() || ward.yCoord < 1 || ward.yCoord > 254 ||
                        Math.abs(ward.yCoord - y) > 4 ||
                        world.getBlock(ward.xCoord, ward.yCoord, ward.zCoord) != EndlessBrood.ward)
                        continue;
                    int radius = radiusForTier(Math.min(3, world.getBlockMetadata(
                        ward.xCoord, ward.yCoord, ward.zCoord)));
                    long dx = (long) ward.xCoord - x, dz = (long) ward.zCoord - z;
                    if (dx * dx + dz * dz <= radius * radius) return true;
                }
            }
        }
        return false;
    }
}
