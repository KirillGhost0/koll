package com.endlessbrood.client;

import com.endlessbrood.common.EntityBroodFlier;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;

public final class RenderBroodFlier extends RenderLiving {
    private static final ResourceLocation[] TEXTURES = BroodStageSkins.forName("flier");
    public RenderBroodFlier() { super(new ModelBroodFlier(), 0.45F); }
    @Override protected ResourceLocation getEntityTexture(Entity entity) { return TEXTURES[BroodStageSkins.phase(entity)]; }
    @Override protected void preRenderCallback(net.minecraft.entity.EntityLivingBase e, float partial) {
        float scale = BroodStageSkins.growth((Entity)e);
        org.lwjgl.opengl.GL11.glScalef(scale, scale, scale);
    }
}
