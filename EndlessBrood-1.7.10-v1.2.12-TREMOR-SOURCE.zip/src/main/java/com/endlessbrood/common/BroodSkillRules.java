package com.endlessbrood.common;

/** Pure progression formulas, bounded to avoid integer overflow. */
public final class BroodSkillRules {
    private BroodSkillRules() { }
    public static int nextLevelXp(int level) {
        long value = 20L + 12L * Math.max(0L, (long)level);
        return (int) Math.min(2020L, value);
    }
    public static int capRank(int rank) { return Math.max(0, Math.min(10, rank)); }
    public static int killReward(int morph) { return 6 + Math.max(0, Math.min(5, morph)) * 3; }
}
