from pathlib import Path

root = Path(__file__).resolve().parents[1] / 'src/main/java/com/endlessbrood'
def check(file, *parts):
    text = (root / file).read_text(encoding='utf-8')
    for part in parts:
        assert part in text, f'{file}: missing {part}'

check('common/EntityBroodAbyssOverlord.java', 'onDeath(DamageSource source)', 'BroodVictoryHandler.complete(worldObj)')
check('common/BroodVictoryData.java', 'markDirty()', 'nbt.setBoolean("Defeated", defeated)')
check('common/BroodVictoryHandler.java', 'DimensionManager.getWorlds()',
      'EntityJoinWorldEvent', 'ChunkEvent.Load', 'theChunkProviderServer.loadedChunks',
      'MAX_SCANNED_PER_TICK = 4096', 'MAX_CHANGES_PER_TICK = 64',
      'getBlockStorageArray()', 'chunkExists(work.x,work.z)', 'Blocks.dirt', 'Blocks.air')
check('common/BlockTaintedSoil.java', 'BroodVictoryData.isDefeated(world)')
check('common/BlockBroodNest.java', 'BroodVictoryData.isDefeated(world)')
check('common/InfectionEvents.java', 'BroodVictoryData.isDefeated(victim.worldObj)')
check('common/ChunkProviderBrood.java', 'final boolean purified = BroodVictoryData.isDefeated(world)', 'purified ? Blocks.dirt')
for file in ['BroodRealmTicker', 'BroodOutbreakTicker', 'BroodPatrolTicker', 'BroodSiegeTicker',
             'BroodWaveTicker', 'EvolutionTicker', 'BroodWorldGenerator']:
    text=(root/'common'/f'{file}.java').read_text(encoding='utf-8')
    assert 'BroodVictoryData.isDefeated(' in text, file
print('PASS: victory persistence, spawn shutdown, infection cure, delayed loaded-only chunk cleanse')
