package com.endlessbrood.common;

import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

/** Five-block end-boss, HP ~= four sovereign minibosses, battle has several phases. */
public final class EntityBroodAbyssOverlord extends EntityBroodCommander {
    private static final double HEALTH = 1280D; // 4 x a 320-HP wave-five miniboss
    public EntityBroodAbyssOverlord(World world) {
        super(world);
        setSize(4.15F,5.0F);
        experienceValue=350;
        applyOverlordStats(true);
    }
    @Override public String getCommandSenderName() { return "Сердце Бездны"; }
    private void applyOverlordStats(boolean fullHeal) {
        getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(HEALTH);
        getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(34D);
        getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(1D);
        if(fullHeal) setHealth((float)HEALTH);
    }
    @Override protected void updateAttributesFromEvolution() {
        float before=getHealth();
        super.updateAttributesFromEvolution();
        applyOverlordStats(false);
        if(before>0) setHealth(Math.min(before,getMaxHealth()));
    }
    @Override public void onLivingUpdate() {
        super.onLivingUpdate();
        if(width<4.1F || height<4.9F) setSize(4.15F,5.0F);
        if(!worldObj.isRemote && ticksExisted%200==0) applyOverlordStats(false);
    }
    @Override public void onDeath(DamageSource source) {
        // Victory is stored before all other death side effects; repeating it
        // is harmless and never triggers a second world-wide cleanup.
        if (!worldObj.isRemote && com.endlessbrood.EndlessBrood.abyssHeart != null)
            entityDropItem(new net.minecraft.item.ItemStack(com.endlessbrood.EndlessBrood.abyssHeart),0F);
        super.onDeath(source);
        if (!worldObj.isRemote) BroodVictoryHandler.complete(worldObj);
    }
    @Override protected void dropFewItems(boolean recent,int looting) {
        super.dropFewItems(recent,looting);
        if(!worldObj.isRemote && com.endlessbrood.EndlessBrood.broodCore!=null)
            entityDropItem(new net.minecraft.item.ItemStack(com.endlessbrood.EndlessBrood.broodCore,4),0F);
    }
    @Override public void readEntityFromNBT(NBTTagCompound data) {
        super.readEntityFromNBT(data);
        applyOverlordStats(false);
        setSize(4.15F,5.0F);
    }
}
