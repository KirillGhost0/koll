package com.endlessbrood.common;

import java.util.Random;

/** Independent Bernoulli gate for ALL ambient births, not raid waves or manual eggs. */
public final class BroodAmbientSpawnRules {
    private BroodAmbientSpawnRules() { }
    public static boolean allow(Random random, int percent) {
        return percent >= 100 || percent > 0 && random.nextInt(100) < percent;
    }
}
