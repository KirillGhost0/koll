package com.endlessbrood.common;

import cpw.mods.fml.common.eventhandler.Event;
import cpw.mods.fml.common.eventhandler.EventPriority;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.event.entity.living.LivingSpawnEvent;

/** Forge natural spawn hook; world.spawnEntityInWorld is NOT affected. */
public final class BroodNaturalSpawnGate {
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void check(LivingSpawnEvent.CheckSpawn event) {
        if (event.world.isRemote || event.getResult() == Event.Result.DENY ||
            !(event.entityLiving instanceof EntityParasite)) return;
        if (!BroodAmbientSpawnRules.allow(event.world.rand, BroodConfig.ambientSpawnPercent))
            event.setResult(Event.Result.DENY);
    }
}
