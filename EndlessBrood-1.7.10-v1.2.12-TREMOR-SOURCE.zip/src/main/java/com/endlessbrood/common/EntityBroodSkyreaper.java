package com.endlessbrood.common;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

/** Armored aerial dive predator; reuses cheap direct steering from the existing flier. */
public final class EntityBroodSkyreaper extends EntityBroodFlier {
    public EntityBroodSkyreaper(World world) { super(world); setSize(1.2F, 0.9F); experienceValue=22; }
    @Override public void onLivingUpdate() {
        super.onLivingUpdate();
        if (worldObj.isRemote || !isEntityAlive()) return;
        if (ticksExisted == 1 || (ticksExisted - 1) % 200 == 0) {
            double old=getMaxHealth();
            double max=Math.min(160D, getEntityAttribute(SharedMonsterAttributes.maxHealth).getBaseValue()*1.85D);
            getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(max);
            if (max>old && getHealth()>0) heal((float)Math.min(30D, max-old));
        }
        // Once per 3 seconds; only while diving and near an actual survival player.
        if (getDivePhase()!=2 || (ticksExisted + getEntityId()) % 60 != 0) return;
        for (Object obj: worldObj.playerEntities) {
            if (!(obj instanceof EntityPlayer)) continue;
            EntityPlayer victim=(EntityPlayer)obj;
            if (!victim.isEntityAlive() || victim.capabilities.isCreativeMode ||
                getDistanceSqToEntity(victim)>25D) continue;
            victim.addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, 50, 1));
            break;
        }
    }
}
