from pathlib import Path
import json, struct
root=Path(__file__).resolve().parent.parent
manifest=json.loads((root/'tests/horror-uv-map.json').read_text(encoding='utf-8'))
for name,parts in manifest.items():
    path=root/'src/main/resources/assets/endlessbrood/textures/entity'/(name+'.png')
    b=path.read_bytes()
    assert b[:8] == bytes((137,80,78,71,13,10,26,10))
    width,height=struct.unpack('>II',b[16:24])
    assert (width,height)==(512,128),name
    used=set()
    for p in parts:
        x,y,w,h=(p[a] for a in ('x','y','w','h'))
        assert x>=0 and y>=0 and w>0 and h>0 and x+w<=width and y+h<=height,name
        for yy in range(y,y+h):
            for xx in range(x,x+w):
                assert (xx,yy) not in used,f'overlap in {name}: {(xx,yy)}'
                used.add((xx,yy))
    print('UV PASS',name,len(parts),'islands',len(used),'pixels')
