package com.endlessbrood.client;

import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public final class RenderBroodSkyreaper extends RenderLiving {
    private static final ResourceLocation TEXTURE = new ResourceLocation(
        "endlessbrood", "textures/entity/skyreaper.png");
    public RenderBroodSkyreaper() { super(new ModelBroodFlier(), 0.55F); }
    @Override protected ResourceLocation getEntityTexture(Entity entity) { return TEXTURE; }
    @Override protected void preRenderCallback(EntityLivingBase e, float tick) {
        GL11.glScalef(1.36F,1.2F,1.36F);
    }
}
