package test;

import com.endlessbrood.common.BroodSpawnRules;
import java.math.BigInteger;

public final class BroodSpawnSmoke {
    public static void main(String[] args) {
        check(BroodSpawnRules.patrolSize(BigInteger.ZERO) == 1, "first scouts");
        check(BroodSpawnRules.patrolSize(BigInteger.valueOf(3)) == 2, "first mutations");
        check(BroodSpawnRules.patrolSize(BigInteger.valueOf(12)) == 3, "mid progression");
        check(BroodSpawnRules.patrolSize(new BigInteger("99999999999999999999")) == 4,
            "bound long-term population");
        check(BroodSpawnRules.offspringCount(0) == 1, "seed nest");
        check(BroodSpawnRules.offspringCount(1) == 2, "mature nest");
        check(BroodSpawnRules.offspringCount(2) == 3, "citadel");
        check(BroodSpawnRules.patrolDue(3600L, 3600), "patrol due");
        check(!BroodSpawnRules.patrolDue(3599L, 3600), "no premature patrol");
        check(!BroodSpawnRules.mayConvert(true, false, false, false, 8, 8), "population cap");
        check(!BroodSpawnRules.mayConvert(true, false, true, false, 0, 8), "ward cure");
        check(!BroodSpawnRules.mayConvert(false, false, false, false, 0, 8), "gamerule");
        check(!BroodSpawnRules.mayConvert(true, true, false, false, 0, 8), "peaceful");
        check(BroodSpawnRules.mayConvert(true, false, false, false, 7, 8), "conversion allowed");
        System.out.println("PASS: bounded scout spawning, colony pulses and conversion guards");
    }
    private static void check(boolean b, String message) {
        if (!b) throw new AssertionError(message);
    }
}
