package com.endlessbrood.common;

/** Pure ward strength rules. Saves use block metadata levels 0..3. */
public final class BroodWardLevels {
    private BroodWardLevels() { }
    public static int radius(int base, int tier) {
        return tier <= 0 ? base : tier == 1 ? Math.max(14, base + 6) :
            tier == 2 ? Math.max(22, base + 14) : Math.max(32, base + 24);
    }
    public static boolean accepts(int current, int itemTier) {
        return current >= 0 && current < 3 && itemTier == current + 1;
    }
}
