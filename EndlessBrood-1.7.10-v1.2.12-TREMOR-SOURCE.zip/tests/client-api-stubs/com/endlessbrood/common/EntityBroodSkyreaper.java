package com.endlessbrood.common;
public final class EntityBroodSkyreaper extends EntityBroodFlier {}
