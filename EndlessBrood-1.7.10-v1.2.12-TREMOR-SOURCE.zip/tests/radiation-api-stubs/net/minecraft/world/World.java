package net.minecraft.world;
import java.util.Random;
public class World {
 public boolean isRemote=false; public Random rand=new Random(1);
 public boolean blockExists(int x,int y,int z){return x>=-64 && x<=64 && z>=-64 && z<=64;}
}
