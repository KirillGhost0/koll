package test;
import com.endlessbrood.common.BroodSiegeBuilderRules;
public final class BroodSiegeBuilderSmoke {
    private static void check(boolean pass,String reason){if(!pass) throw new AssertionError(reason);}
    public static void main(String[] args){
        check(BroodSiegeBuilderRules.BUILDERS_PER_WAVE == 2,"2 wave workers");
        for(int i=1;i<256;i++) {
            int dx = BroodSiegeBuilderRules.stairX(i) - BroodSiegeBuilderRules.stairX(i-1);
            int dz = BroodSiegeBuilderRules.stairZ(i) - BroodSiegeBuilderRules.stairZ(i-1);
            check(Math.abs(dx)+Math.abs(dz)==1,"adjacent cardinal stair tread #"+i);
            check(BroodSiegeBuilderRules.stairX(i)==BroodSiegeBuilderRules.stairX(i+16),"cyclic x");
            check(BroodSiegeBuilderRules.stairZ(i)==BroodSiegeBuilderRules.stairZ(i+16),"cyclic z");
        }
        check(BroodSiegeBuilderRules.stepsToTarget(64,125)==61,"skybase elevation");
        check(BroodSiegeBuilderRules.canStart(64,125),"skybase can be reached");
        check(!BroodSiegeBuilderRules.canStart(64,225),"too tall is bounded");
        check(!BroodSiegeBuilderRules.canStart(64,64),"flat terrain needs barricades");
        check(!BroodSiegeBuilderRules.canAdd(false,true,false,true,true,true,0),"mobGriefing respected");
        check(!BroodSiegeBuilderRules.canAdd(true,false,false,true,true,true,0),"config respected");
        check(!BroodSiegeBuilderRules.canAdd(true,true,true,true,true,true,0),"ward respected");
        check(!BroodSiegeBuilderRules.canAdd(true,true,false,false,true,true,0),"unloaded denied");
        check(!BroodSiegeBuilderRules.canAdd(true,true,false,true,false,true,0),"base preserved");
        check(!BroodSiegeBuilderRules.canAdd(true,true,false,true,true,false,0),"entities preserved");
        check(!BroodSiegeBuilderRules.canAdd(true,true,false,true,true,true,
            BroodSiegeBuilderRules.MAX_BLOCKS),"budget");
        System.out.println("PASS: two siege builders, 5x5 ascending loop, sky base plan and safety caps");
    }
}
