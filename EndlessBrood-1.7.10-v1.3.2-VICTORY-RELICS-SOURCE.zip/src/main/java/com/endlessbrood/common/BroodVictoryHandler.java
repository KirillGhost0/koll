package com.endlessbrood.common;

import com.endlessbrood.EndlessBrood;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.ChatComponentText;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.chunk.Chunk;
import net.minecraftforge.common.DimensionManager;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.world.ChunkEvent;

/**
 * Final-boss victory: permanent spawn shutoff and incremental cleansing.
 * Never loads new chunks. Unloaded land is cleaned when it is next loaded.
 * All block edits are spread over many ticks to protect TPS with HBM installed.
 */
public final class BroodVictoryHandler {
    private static final int MAX_SCANNED_PER_TICK = 4096;
    private static final int MAX_CHANGES_PER_TICK = 64;
    private static final Map<World, WorkQueue> QUEUES = new WeakHashMap<World, WorkQueue>();

    private static final class ChunkWork {
        final int x, z;
        int index;
        ChunkWork(int chunkX, int chunkZ) { x=chunkX; z=chunkZ; }
    }
    private static final class WorkQueue {
        final ArrayDeque<ChunkWork> pending = new ArrayDeque<ChunkWork>();
        final Set<Long> queued = new HashSet<Long>();
        boolean initialChunksEnqueued;
    }

    private static WorkQueue queue(World world) {
        WorkQueue q = QUEUES.get(world);
        if(q == null) { q = new WorkQueue(); QUEUES.put(world, q); }
        return q;
    }
    private static long key(int cx, int cz) {
        return ((long)cx << 32) ^ ((long)cz & 0xffffffffL);
    }
    private static void enqueue(World world, int cx, int cz) {
        WorkQueue q = queue(world);
        if(q.queued.add(key(cx,cz))) q.pending.addLast(new ChunkWork(cx,cz));
    }

    /** Triggered by the *real* 5-block Abyss overlord only. */
    public static void complete(World source) {
        if(source.isRemote || !BroodVictoryData.get(source).defeat()) return;
        BroodVictoryNetwork.announceVictory();
        World overworld=DimensionManager.getWorld(0);
        if(overworld!=null) {
            BroodWaveData waves=BroodWaveData.get(overworld);
            waves.waveTicksLeft=0;
            waves.markDirty();
        }
        for(WorldServer world : DimensionManager.getWorlds()) {
            if(world == null) continue;
            // Existing, currently loaded parasites disappear immediately, with
            // no loot or extra evolution points. Ordinary animals are untouched.
            for(Object obj : new ArrayList<Object>(world.loadedEntityList)) {
                if(isBrood(obj)) ((Entity)obj).setDead();
                else if(obj instanceof EntityLivingBase)
                    ((EntityLivingBase)obj).getEntityData().removeTag(InfectionEvents.INFECTION);
            }
            enqueueInitial(world);
            for(Object obj : world.playerEntities) if(obj instanceof EntityPlayer) {
                EntityPlayer player=(EntityPlayer)obj;
                player.addChatMessage(new ChatComponentText(
                    "§a[Endless Brood] Сердце Бездны уничтожено! Рой погибает, земля очищается."));
                world.playSoundAtEntity(player, "random.levelup", 0.9F, 0.55F);
            }
        }
    }

    private static boolean isBrood(Object entity) {
        return entity instanceof EntityParasite || entity instanceof EntityBroodFlier;
    }

    @SubscribeEvent public void entityJoining(EntityJoinWorldEvent event) {
        if(event.world.isRemote || !BroodVictoryData.isDefeated(event.world)) return;
        if(isBrood(event.entity)) event.setCanceled(true);
        else if(event.entity instanceof EntityLivingBase)
            ((EntityLivingBase)event.entity).getEntityData().removeTag(InfectionEvents.INFECTION);
    }

    @SubscribeEvent public void onChunkLoad(ChunkEvent.Load event) {
        if(event.world.isRemote || !BroodVictoryData.isDefeated(event.world)) return;
        // No block scanning or chunk access inside the load callback.
        enqueue(event.world, event.getChunk().xPosition, event.getChunk().zPosition);
    }

    private static void enqueueInitial(World world) {
        if(!(world instanceof WorldServer)) return;
        WorkQueue q=queue(world);
        if(q.initialChunksEnqueued) return;
        q.initialChunksEnqueued=true;
        // Snapshot prevents ConcurrentModificationException if other mods load chunks.
        for(Object o : new ArrayList<Object>(((WorldServer)world).theChunkProviderServer.loadedChunks)) {
            if(o instanceof Chunk) {
                Chunk c=(Chunk)o;
                enqueue(world,c.xPosition,c.zPosition);
            }
        }
    }

    @SubscribeEvent public void worldTick(TickEvent.WorldTickEvent event) {
        World world=event.world;
        if(event.phase!=TickEvent.Phase.END || world.isRemote ||
            !BroodVictoryData.isDefeated(world)) return;
        enqueueInitial(world);
        WorkQueue q=queue(world);
        int scanned=0, changed=0;
        while(!q.pending.isEmpty() && scanned<MAX_SCANNED_PER_TICK && changed<MAX_CHANGES_PER_TICK) {
            ChunkWork work=q.pending.peekFirst();
            // Do not force-load chunks that have disappeared from memory.
            if(!world.getChunkProvider().chunkExists(work.x,work.z)) {
                finish(q,work); continue;
            }
            Chunk chunk=world.getChunkFromChunkCoords(work.x,work.z);
            while(work.index<65536 && scanned<MAX_SCANNED_PER_TICK && changed<MAX_CHANGES_PER_TICK) {
                // Empty vertical sections are overwhelmingly common in the Abyss.
                // Skip them without scanning 4096 air blocks each.
                int section=work.index>>12;
                if(chunk.getBlockStorageArray()[section]==null) {
                    work.index=(section+1)<<12;
                    continue;
                }
                final int i=work.index++;
                final int lx=i & 15, lz=(i>>4) & 15, y=(i>>8) & 255;
                scanned++;
                net.minecraft.block.Block block=chunk.getBlock(lx,y,lz);
                if(block==EndlessBrood.taintedSoil) {
                    if(world.setBlock((work.x<<4)+lx,y,(work.z<<4)+lz,Blocks.dirt,0,2)) changed++;
                } else if(block==EndlessBrood.nest) {
                    if(world.setBlock((work.x<<4)+lx,y,(work.z<<4)+lz,Blocks.air,0,2)) changed++;
                }
            }
            if(work.index==65536) finish(q,work);
        }
    }

    private static void finish(WorkQueue q,ChunkWork work) {
        q.pending.removeFirst();
        q.queued.remove(key(work.x,work.z));
    }
}
