package com.endlessbrood.common;
public final class BroodConfig {
    public static int maxPathRequestsPerTick = 4;
}
