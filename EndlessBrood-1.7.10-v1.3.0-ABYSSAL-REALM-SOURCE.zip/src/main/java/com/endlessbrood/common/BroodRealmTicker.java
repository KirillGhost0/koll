package com.endlessbrood.common;

import com.endlessbrood.EndlessBrood;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.world.World;

/** A bounded server-owned population and one permanent fortress encounter. */
public final class BroodRealmTicker {
    @SubscribeEvent public void tick(TickEvent.WorldTickEvent evt) {
        World w=evt.world;
        if(evt.phase!=TickEvent.Phase.END || w.isRemote || !BroodRealmTravel.realmAvailable ||
            w.provider.dimensionId!=BroodRealmTravel.dimensionId || w.playerEntities.isEmpty() ||
            w.getTotalWorldTime()%100L!=0L ||
            !w.getGameRules().getGameRuleBooleanValue("doMobSpawning")) return;
        awakenFortress(w);
        for(Object obj:w.playerEntities) {
            if(!(obj instanceof EntityPlayer)) continue;
            EntityPlayer p=(EntityPlayer)obj;
            if(p.capabilities.isCreativeMode || !p.isEntityAlive()) continue;
            // Count only loaded entities; never force-load neighbouring chunks.
            List nearby=w.getEntitiesWithinAABB(net.minecraft.entity.EntityLiving.class,p.boundingBox.expand(64D,32D,64D));
            if(nearby.size()>=48) continue;
            int budget=Math.min(3,48-nearby.size());
            for(int i=0;i<budget;i++) {
                int x=(int)Math.floor(p.posX)+w.rand.nextInt(111)-55;
                int z=(int)Math.floor(p.posZ)+w.rand.nextInt(111)-55;
                if(p.getDistanceSq(x+.5D,p.posY,z+.5D)<18D*18D) continue;
                if(!w.blockExists(x,120,z)) continue;
                int y=w.getHeightValue(x,z);
                if(y<90 || y>200 || !w.isAirBlock(x,y,z) || !w.isAirBlock(x,y+1,z)) continue;
                net.minecraft.entity.Entity e;
                int choice=w.rand.nextInt(8);
                if(choice==0) e=new EntityBroodSkyreaper(w);
                else if(choice==1) { EntityBroodElite.Ravager elite=new EntityBroodElite.Ravager(w); elite.prepareForWave(); e=elite; }
                else if(choice==2) { EntityBroodElite.Ironmaw elite=new EntityBroodElite.Ironmaw(w); elite.prepareForWave(); e=elite; }
                else e=new EntityParasite(w);
                e.setPosition(x+.5D,y,z+.5D);
                if(!w.getCollidingBoundingBoxes(e,e.boundingBox).isEmpty()) continue;
                w.spawnEntityInWorld(e);
            }
        }
    }
    private void awakenFortress(World w) {
        BroodRealmData state=BroodRealmData.get(w);
        if(state.fortressAwakened) return;
        for(Object obj:w.playerEntities) {
            EntityPlayer p=(EntityPlayer)obj;
            if(p.getDistanceSq(BroodRealmRules.FORT_X+.5D,142D,BroodRealmRules.FORT_Z+.5D)>115D*115D) continue;
            int[][] positions={{-23,-23},{23,-23},{-23,23},{23,23}};
            // Spawn the four 3-block sovereigns and central 5-block overlord exactly once.
            // Fortress floor is generated deterministically by the chunk provider.
            for(int[] pos:positions) {
                int x=BroodRealmRules.FORT_X+pos[0], z=BroodRealmRules.FORT_Z+pos[1];
                w.getBlock(x,144,z); // intentional small finite set of fortress chunks
                EntityBroodCommander guardian=new EntityBroodCommander(w);
                guardian.setWaveLevel(5);
                guardian.setPosition(x+.5D,145D,z+.5D);
                w.spawnEntityInWorld(guardian);
            }
            EntityBroodAbyssOverlord finalBoss=new EntityBroodAbyssOverlord(w);
            finalBoss.setPosition(BroodRealmRules.FORT_X+.5D,144D,BroodRealmRules.FORT_Z+.5D);
            if(w.spawnEntityInWorld(finalBoss)) {
                state.fortressAwakened=true;
                state.markDirty();
            }
            return;
        }
    }
}
