package com.endlessbrood.common;

import com.endlessbrood.client.BroodVictoryClientState;
import cpw.mods.fml.common.network.simpleimpl.IMessage;
import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
import cpw.mods.fml.common.network.simpleimpl.MessageContext;
import io.netty.buffer.ByteBuf;

/** Server->client transition flag; no mutable world operations on Netty thread. */
public final class BroodVictoryPacket implements IMessage {
    private boolean defeated;
    public BroodVictoryPacket() { }
    public BroodVictoryPacket(boolean defeated) { this.defeated=defeated; }
    @Override public void fromBytes(ByteBuf buf) { defeated=buf.readBoolean(); }
    @Override public void toBytes(ByteBuf buf) { buf.writeBoolean(defeated); }

    public static final class Handler implements IMessageHandler<BroodVictoryPacket, IMessage> {
        @Override public IMessage onMessage(BroodVictoryPacket message, MessageContext ctx) {
            BroodVictoryClientState.accept(message.defeated);
            return null;
        }
    }
}
