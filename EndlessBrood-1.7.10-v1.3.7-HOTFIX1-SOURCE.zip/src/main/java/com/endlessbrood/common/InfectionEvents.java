package com.endlessbrood.common;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;

/** Incubation, on-death conversion and low-frequency host-to-host spores.
 * All effects and spawns happen on the server, without chunk tickets. */
public final class InfectionEvents {
    public static final String INFECTION = "endlessbroodIncubation";

    private static boolean infectable(EntityLivingBase entity) {
        if (entity instanceof EntityParasite || entity instanceof EntityBroodFlier ||
            entity instanceof EntityPlayer || entity.isDead) return false;
        if (BroodConfig.preserveTamedAnimals && entity instanceof EntityTameable &&
            ((EntityTameable) entity).isTamed()) return false;
        return entity instanceof EntityLiving && entity.getMaxHealth() <= 100.0F &&
            (entity instanceof EntityAnimal || entity instanceof EntityVillager ||
             entity instanceof EntityMob);
    }

    private static boolean parasite(Entity source) {
        return source instanceof EntityParasite || source instanceof EntityBroodFlier;
    }

    @SubscribeEvent
    public void onHurt(LivingHurtEvent event) {
        EntityLivingBase victim = event.entityLiving;
        if (victim.worldObj.isRemote || BroodVictoryData.isDefeated(victim.worldObj) || event.ammount <= 0 || !parasite(event.source.getEntity())) return;
        if (victim instanceof EntityPlayer) {
            if (victim.getRNG().nextFloat() < 0.15F)
                victim.addPotionEffect(new PotionEffect(Potion.poison.id, 80, 0));
        } else if (infectable(victim) && !victim.getEntityData().hasKey(INFECTION) &&
                   victim.getRNG().nextDouble() < BroodCalendarRules.infectionChance(
                       BroodConfig.effectiveInfectionChance(),
                       BroodCalendarRules.day(victim.worldObj.getWorldTime())) &&
                   !protectedArea(victim)) {
            infect(victim);
        }
    }

    private static void infect(EntityLivingBase victim) {
        victim.getEntityData().setInteger(INFECTION, BroodConfig.effectiveIncubationTicks());
        victim.addPotionEffect(new PotionEffect(Potion.weakness.id, 200, 0));
    }

    private static boolean protectedArea(EntityLivingBase victim) {
        int x = (int) Math.floor(victim.posX), y = (int) Math.floor(victim.posY),
            z = (int) Math.floor(victim.posZ);
        World world = victim.worldObj;
        return BroodWardRules.protects(world, x, y, z) ||
            BroodConfig.infectionRadiationCure &&
            BroodRadiationBridge.getRadiation(world, x, y, z) >=
                BroodConfig.radiationSoilCleanThreshold;
    }

    /** Infected soil transmits spores to non-player hosts without extra timers. */
    public static void infectFromSoil(EntityLivingBase victim) {
        if (victim.worldObj.isRemote || BroodVictoryData.isDefeated(victim.worldObj) || !infectable(victim) ||
            victim.getEntityData().hasKey(INFECTION) || protectedArea(victim)) return;
        infect(victim);
    }

    @SubscribeEvent
    public void onDeath(LivingDeathEvent event) {
        EntityLivingBase victim = event.entityLiving;
        if (victim.worldObj.isRemote || BroodVictoryData.isDefeated(victim.worldObj) || event.isCanceled() || victim instanceof EntityParasite ||
            victim instanceof EntityBroodFlier) return;
        boolean killedByBrood = parasite(event.source.getEntity());
        if (killedByBrood)
            EvolutionData.get(victim.worldObj).addCombatPoints(BroodConfig.killPoints,
                victim.worldObj.getTotalWorldTime());
        if (!infectableForDeath(victim)) return;
        boolean alreadyInfected = victim.getEntityData().hasKey(INFECTION);
        if ((killedByBrood && (alreadyInfected || victim.getRNG().nextDouble() <
             BroodCalendarRules.infectionChance(BroodConfig.effectiveKillConversionChance(),
                 BroodCalendarRules.day(victim.worldObj.getWorldTime())))) ||
            (!killedByBrood && alreadyInfected && victim.getRNG().nextInt(3) == 0))
            transform(victim);
    }

    // LivingDeathEvent fires while the dying mob is not yet flagged isDead.
    private static boolean infectableForDeath(EntityLivingBase entity) {
        if (entity instanceof EntityParasite || entity instanceof EntityBroodFlier ||
            entity instanceof EntityPlayer || !(entity instanceof EntityLiving)) return false;
        if (BroodConfig.preserveTamedAnimals && entity instanceof EntityTameable &&
            ((EntityTameable) entity).isTamed()) return false;
        return entity.getMaxHealth() <= 100.0F && (entity instanceof EntityAnimal ||
            entity instanceof EntityVillager || entity instanceof EntityMob);
    }

    private boolean transform(EntityLivingBase victim) {
        World world = victim.worldObj;
        if (world.isRemote || !infectableForDeath(victim)) return false;
        int total = BroodLoadedEntities.find(world, EntityParasite.class,
            victim.boundingBox.expand(24.0D, 12.0D, 24.0D)).size() +
            BroodLoadedEntities.find(world, EntityBroodFlier.class,
                victim.boundingBox.expand(24.0D, 12.0D, 24.0D)).size();
        if (!BroodSpawnRules.mayConvert(world.getGameRules().getGameRuleBooleanValue("doMobSpawning"),
            world.difficultySetting == EnumDifficulty.PEACEFUL, protectedArea(victim), false,
            total, BroodConfig.effectiveLocalPopulationLimit())) return false;
        EntityParasite replacement = new EntityParasite(world);
        replacement.setLocationAndAngles(victim.posX, victim.posY, victim.posZ,
            victim.rotationYaw, victim.rotationPitch);
        // The dying/incubating host still occupies the same entity box here.
        // Entity-to-entity collision would reject every legitimate conversion.
        if (!world.getCollidingBoundingBoxes(replacement, replacement.boundingBox).isEmpty()) return false;
        if (!world.spawnEntityInWorld(replacement)) return false;
        EvolutionData.get(world).addCombatPoints(BroodConfig.infectionPoints,
            world.getTotalWorldTime());
        return true;
    }

    @SubscribeEvent
    public void onUpdate(LivingEvent.LivingUpdateEvent event) {
        EntityLivingBase victim = event.entityLiving;
        if (victim.worldObj.isRemote) return;
        if (BroodVictoryData.isDefeated(victim.worldObj)) {
            victim.getEntityData().removeTag(INFECTION);
            return;
        }
        if (victim.ticksExisted % 20 != 0 || !infectable(victim)) return;
        NBTTagCompound data = victim.getEntityData();
        if (!data.hasKey(INFECTION)) return;
        // Cure only every five seconds instead of scanning wards per tick.
        if (victim.ticksExisted % 100 == 0 && protectedArea(victim)) {
            data.removeTag(INFECTION);
            return;
        }
        int remaining = data.getInteger(INFECTION) - 20;
        if (remaining > 0) {
            data.setInteger(INFECTION, remaining);
            if (remaining % 200 == 0)
                victim.addPotionEffect(new PotionEffect(Potion.weakness.id, 240, 0));
            if (BroodConfig.contagiousInfection && victim.ticksExisted %
                BroodConfig.effectiveInfectionContagionTicks() == 0)
                trySpread(victim);
            return;
        }
        // If cap is full, retain infection and retry later; don't make unlimited mobs.
        if (transform(victim)) {
            data.removeTag(INFECTION);
            victim.setDead();
        } else data.setInteger(INFECTION, 0);
    }

    @SuppressWarnings("unchecked")
    private void trySpread(EntityLivingBase host) {
        if (host.getRNG().nextFloat() >= BroodCalendarRules.infectionChance(
                BroodConfig.effectiveContagionChance(),
                BroodCalendarRules.day(host.worldObj.getWorldTime())) ||
            protectedArea(host)) return;
        List<EntityLivingBase> close = BroodLoadedEntities.find(host.worldObj, 
            EntityLivingBase.class, host.boundingBox.expand(4.0D, 2.0D, 4.0D));
        int infected = 0;
        for (EntityLivingBase other : close)
            if (other.getEntityData().hasKey(INFECTION)) infected++;
        if (infected >= BroodConfig.effectiveInfectedLocalLimit()) return;
        for (EntityLivingBase other : close) {
            if (other != host && infectable(other) && !other.getEntityData().hasKey(INFECTION)
                && !protectedArea(other)) {
                infect(other);
                break; // ONE newly infected neighbour per pulse, at most.
            }
        }
    }
}
