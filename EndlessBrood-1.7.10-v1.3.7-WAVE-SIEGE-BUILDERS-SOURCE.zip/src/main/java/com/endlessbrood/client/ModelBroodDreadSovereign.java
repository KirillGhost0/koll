package com.endlessbrood.client;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

/** 3-block-tall, 2.65-block-wide organic siege monster. 256x256 dedicated UV. */
public final class ModelBroodDreadSovereign extends ModelBase {
    private final ModelRenderer torso, head, jaw;
    private final ModelRenderer leftArm, rightArm, leftLeg, rightLeg;
    private final ModelRenderer tail, ridge;
    public ModelBroodDreadSovereign() {
        textureWidth = 256; textureHeight = 256;
        torso = box(0, 0, -12,-40,-9, 24,22,18, 0,0,0);
        head = box(0, 52, -8,-10,-13, 16,13,13, 0,-38,-5);
        jaw = box(66,52, -7,0,-12, 14,5,12, 0,1,-12);
        head.addChild(jaw);
        // Crown horns frame the skull. Face remains visible beneath the ridges.
        head.addChild(box(80,100, -8,-10,-10, 4,9,4, 0,0,0));
        head.addChild(box(80,100, 4,-10,-10, 4,9,4, 0,0,0));
        head.addChild(box(105,100, -2,-10,-13, 4,9,4, 0,0,0));
        ridge = box(86,0, -9,-7,1, 18,12,16, 0,-37,2);
        // Spinal spikes: uneven, like a crown of splintered bones.
        for (int i=0;i<4;i++) {
            ModelRenderer spike = box(105,100, i%2==0 ? -6 : 3, -9-(i%2)*2, -2+i*5, 4,9+(i%2)*2,4, 0,0,0);
            ridge.addChild(spike);
        }
        leftArm = box(160,52, -8,0,-5, 8,27,10, -12,-35,0);
        rightArm = box(160,52, 0,0,-5, 8,27,10, 12,-35,0);
        leftArm.addChild(box(55,100,-7,22,-7,3,8,5,0,0,0));
        rightArm.addChild(box(55,100,4,22,-7,3,8,5,0,0,0));
        // Both hip pivots sit directly below the torso. Local coordinates are
        // symmetric, and attached feet always rotate WITH the shins.
        // Old model had off-centre leg boxes that swung visibly through the body.
        leftLeg = box(0,100, -5,0,-5, 10,15,10, -7,-19,1);
        rightLeg = box(0,100, -5,0,-5, 10,15,10, 7,-19,1);
        // Feet end at local Y=0, then root-offset +24 -> ground plane Y=24.
        leftLeg.addChild(box(0,145, -6,14,-10, 12,5,16, 0,0,0));
        rightLeg.addChild(box(0,145, -6,14,-10, 12,5,16, 0,0,0));
        leftLeg.addChild(box(75,145, -5,7,-7, 10,5,3, 0,0,0));
        rightLeg.addChild(box(75,145, -5,7,-7, 10,5,3, 0,0,0));
        tail = box(132,100, -3,-2,0, 7,10,8, 0,-23,9);
        // Protective plated sternum and jagged asymmetrical ribs.
        torso.addChild(box(170,100,-10,4,-11,20,6,4,0,0,0));
        torso.addChild(box(125,52,-14,2,-8,7,15,8,0,0,0));
        torso.addChild(box(125,52,7,0,-8,7,15,8,0,0,0));
        // Minecraft 1.7.10 RenderLiving renders model-space Y=24 at the floor.
        // Our previous model ended at Y=0, leaving BOTH feet 1.5 blocks above
        // the actual entity hitbox (the 'standing on a fence' visual bug).
        // Offset ONLY the top-level pivots: shifting children twice would break
        // the ankles, jaws, horns and plated ribs.
        ModelRenderer[] roots = {torso, head, ridge, leftArm, rightArm,
                                 leftLeg, rightLeg, tail};
        for (ModelRenderer root : roots) root.rotationPointY += 24.0F;
    }
    private ModelRenderer box(int u, int v,float x,float y,float z,int w,int h,int d,
                              float px,float py,float pz) {
        ModelRenderer r = new ModelRenderer(this,u,v);
        r.setRotationPoint(px,py,pz);
        r.addBox(x,y,z,w,h,d);
        return r;
    }
    @Override public void render(Entity entity, float limb, float amount, float time,
                                 float yaw, float pitch, float scale) {
        setRotationAngles(limb,amount,time,yaw,pitch,scale,entity);
        torso.render(scale); head.render(scale); ridge.render(scale);
        leftArm.render(scale); rightArm.render(scale);
        leftLeg.render(scale); rightLeg.render(scale); tail.render(scale);
    }
    @Override public void setRotationAngles(float limb, float amount, float time,
                                            float yaw, float pitch, float scale, Entity entity) {
        head.rotateAngleY = yaw/(180F/(float)Math.PI) * .65F;
        head.rotateAngleX = pitch/(180F/(float)Math.PI) * .40F;
        // Weighty gait: small, opposed hip movement; no twisted ankle or
        // oversized swing on high movement speed/low server TPS.
        float stride = MathHelper.cos(limb*0.45F)*Math.min(0.7F,Math.max(0F,amount))*.31F;
        leftLeg.rotateAngleX = stride;
        rightLeg.rotateAngleX = -stride;
        leftLeg.rotateAngleZ = -0.045F;
        rightLeg.rotateAngleZ = 0.045F;
        leftArm.rotateAngleX = -stride*.42F + .10F;
        rightArm.rotateAngleX = stride*.42F + .10F;
        ridge.rotateAngleX = MathHelper.sin(time*0.09F)*.022F;
        tail.rotateAngleX = MathHelper.sin(time*0.16F)*.12F;
        jaw.rotateAngleX = .13F + .2F*(.5F+.5F*MathHelper.sin(time*.25F));
    }
}
