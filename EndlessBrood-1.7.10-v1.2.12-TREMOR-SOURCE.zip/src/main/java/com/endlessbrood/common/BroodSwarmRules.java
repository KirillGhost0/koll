package com.endlessbrood.common;

/** Server-side battle geometry, deliberately free of Forge/Minecraft dependencies.
 * Positions are relative to a victim, not teleport destinations.
 */
public final class BroodSwarmRules {
    private BroodSwarmRules() { }

    /** Every entity keeps a stable role so that groups do not constantly reshuffle. */
    public static int role(int entityId) {
        return (entityId & Integer.MAX_VALUE) % 6;
    }

    public static boolean isFlanker(int entityId) {
        return role(entityId) < 4;
    }

    /** Ground units approach from the sides and rear; heavy units go straight in. */
    public static double[] flankPoint(double x, double z, float victimYaw,
                                      int entityId, double radius) {
        // Vanilla Minecraft yaw 0 points toward +Z.
        int slot = role(entityId);
        double offset = slot == 0 ? -1.19D : slot == 1 ? 1.19D :
                        slot == 2 ? -2.15D : slot == 3 ? 2.15D : 0D;
        double angle = Math.toRadians(victimYaw) + offset;
        return new double[] {x + Math.sin(angle) * radius,
                             z + Math.cos(angle) * radius};
    }

    /** Flying wings patrol offset sectors instead of piling into one point. */
    public static double[] airOrbit(double x, double z, int entityId,
                                    long worldTicks, double radius) {
        int slot = role(entityId);
        double angle = slot * Math.PI / 3D + (worldTicks % 7200L) * 0.005D;
        return new double[] {x + Math.cos(angle) * radius,
                             z + Math.sin(angle) * radius};
    }

    public static boolean shouldFlank(double distanceSq, int entityId, boolean visible) {
        return visible && isFlanker(entityId) && distanceSq > 64D && distanceSq <= 625D;
    }

    public static boolean shouldAcceptSharedTarget(double candidateDistanceSq,
                                                    double currentDistanceSq) {
        return candidateDistanceSq < currentDistanceSq * 0.7D;
    }
}
