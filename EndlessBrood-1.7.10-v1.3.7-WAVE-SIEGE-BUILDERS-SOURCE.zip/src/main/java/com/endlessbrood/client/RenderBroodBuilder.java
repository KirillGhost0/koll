package com.endlessbrood.client;

import com.endlessbrood.common.EntityBroodBuilder;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

/** Separately textured organic builder, using the proven Stalker geometry. */
public final class RenderBroodBuilder extends RenderLiving {
    private static final ResourceLocation[] SKINS = BroodStageSkins.forName("builder");
    public RenderBroodBuilder() { super(new ModelBroodParasite(), 0.42F); }
    @Override protected ResourceLocation getEntityTexture(Entity entity) {
        int tier = entity instanceof EntityBroodBuilder ?
            ((EntityBroodBuilder) entity).getVisualTier() : 0;
        return SKINS[com.endlessbrood.common.BroodVisualEvolution.skin(tier)];
    }
    @Override protected void preRenderCallback(EntityLivingBase entity, float partialTick) {
        int tier = entity instanceof EntityBroodBuilder ?
            ((EntityBroodBuilder) entity).getVisualTier() : 0;
        float growth = com.endlessbrood.common.BroodVisualEvolution.scale(tier);
        GL11.glScalef(0.92F * growth, 0.88F * growth, 0.92F * growth);
    }
}
