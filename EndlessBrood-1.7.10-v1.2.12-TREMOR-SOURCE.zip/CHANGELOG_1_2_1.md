# Endless Brood 1.2.1 (spawn and infection overhaul)

- Periodic, tightly capped active scout patrols in loaded chunks beyond the advancing home exclusion radius.
- More reliable retroactive outbreak nests where an explorer can load suitable distant terrain.
- Bounded 1/2/3 offspring per nest pulse (seed/mature/citadel), with remote-spawn suspension.
- Higher-tier infected soil spreads slightly farther while remaining terrain-limited and ward/radiation-safe.
- Infection now spreads gently between incubating hosts and can be acquired by staying on infected soil.
- Infected hosts can be cured by wards or strong HBM chunk radiation; conversions obey a combined ground + flier cap, gamerule and Peaceful difficulty.
- Fixed overlap check preventing conversions inside still-present original host entity boxes.
- /broodstage reports whether patrols are permitted near the player.
- No forced chunk loads, no extra external dependencies. Existing save-data schema unchanged.
