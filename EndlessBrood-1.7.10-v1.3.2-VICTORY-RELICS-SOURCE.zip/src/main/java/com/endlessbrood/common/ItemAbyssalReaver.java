package com.endlessbrood.common;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

/** Unique reward sword: applies a short Wither I effect to living targets. */
public final class ItemAbyssalReaver extends ItemSword {
    public ItemAbyssalReaver(Item.ToolMaterial material) {
        super(material);
        setUnlocalizedName("endlessbrood.abyssalReaver");
        setTextureName("endlessbrood:abyssalReaver");
        setCreativeTab(CreativeTabs.tabCombat);
    }
    @Override public boolean hitEntity(ItemStack stack, EntityLivingBase target, EntityLivingBase attacker) {
        if (!target.worldObj.isRemote && target.isEntityAlive()) {
            target.addPotionEffect(new PotionEffect(Potion.wither.id, 80, 0));
        }
        return super.hitEntity(stack, target, attacker);
    }
}
