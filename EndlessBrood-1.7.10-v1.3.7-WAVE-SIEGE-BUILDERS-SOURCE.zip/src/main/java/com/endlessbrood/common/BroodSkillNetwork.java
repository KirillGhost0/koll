package com.endlessbrood.common;

import com.endlessbrood.EndlessBrood;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import cpw.mods.fml.common.network.NetworkRegistry;
import cpw.mods.fml.common.network.simpleimpl.IMessage;
import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
import cpw.mods.fml.common.network.simpleimpl.MessageContext;
import cpw.mods.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import cpw.mods.fml.relauncher.Side;
import io.netty.buffer.ByteBuf;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;

/** Forge 1.7.10: network callbacks enqueue mutations for the main server thread. */
public final class BroodSkillNetwork {
    public static final SimpleNetworkWrapper CHANNEL = NetworkRegistry.INSTANCE.newSimpleChannel("eb_skills");
    private static final ConcurrentLinkedQueue<Action> QUEUE = new ConcurrentLinkedQueue<Action>();
    private BroodSkillNetwork() { }

    public static void register() {
        CHANNEL.registerMessage(Request.Handler.class, Request.class, 30, Side.SERVER);
        CHANNEL.registerMessage(Snapshot.Handler.class, Snapshot.class, 31, Side.CLIENT);
        FMLCommonHandler.instance().bus().register(new BroodSkillNetwork());
    }

    public static void request(int skill) { CHANNEL.sendToServer(new Request(skill)); }

    private static void sync(EntityPlayerMP player) {
        NBTTagCompound data = BroodSkills.get(player);
        int[] ranks = new int[BroodSkills.KEYS.length];
        for (int i = 0; i < ranks.length; ++i) ranks[i] = BroodSkills.rank(data, i);
        CHANNEL.sendTo(new Snapshot(BroodSkills.level(data),
            data.getInteger("xp"), BroodSkills.xpForNext(BroodSkills.level(data)),
            BroodSkills.points(data), ranks), player);
    }

    @SubscribeEvent
    public void tick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Action next;
        int handled = 0;
        // Malicious clients cannot flood a full tick with repeated skill requests.
        while (++handled <= 64 && (next = QUEUE.poll()) != null) {
            EntityPlayerMP player = next.player;
            if (player == null || player.isDead || player.playerNetServerHandler == null) continue;
            ItemStack held = player.getCurrentEquippedItem();
            if (held == null || !(held.getItem() instanceof ItemSkillCodex)) continue;
            if (next.skill >= 0 && next.skill < BroodSkills.KEYS.length)
                BroodSkills.upgrade(player, next.skill);
            sync(player);
        }
    }

    private static final class Action {
        private final EntityPlayerMP player;
        private final int skill;
        private Action(EntityPlayerMP player, int skill) { this.player = player; this.skill = skill; }
    }

    public static final class Request implements IMessage {
        private int skill;
        public Request() { }
        public Request(int skill) { this.skill = skill; }
        @Override public void fromBytes(ByteBuf bytes) { skill = bytes.readByte(); }
        @Override public void toBytes(ByteBuf bytes) { bytes.writeByte(skill); }
        public static final class Handler implements IMessageHandler<Request, IMessage> {
            @Override public IMessage onMessage(Request request, MessageContext ctx) {
                EntityPlayerMP player = ctx.getServerHandler().playerEntity;
                if (request.skill >= -1 && request.skill < BroodSkills.KEYS.length)
                    QUEUE.offer(new Action(player, request.skill));
                return null;
            }
        }
    }

    public static final class Snapshot implements IMessage {
        private int level, xp, toNext, points;
        private final int[] ranks = new int[BroodSkills.KEYS.length];
        public Snapshot() { }
        private Snapshot(int level, int xp, int toNext, int points, int[] ranks) {
            this.level = level; this.xp = xp; this.toNext = toNext; this.points = points;
            System.arraycopy(ranks, 0, this.ranks, 0, this.ranks.length);
        }
        @Override public void fromBytes(ByteBuf bytes) {
            level = bytes.readInt(); xp = bytes.readInt(); toNext = bytes.readInt(); points = bytes.readInt();
            for (int i = 0; i < ranks.length; ++i) ranks[i] = bytes.readUnsignedByte();
        }
        @Override public void toBytes(ByteBuf bytes) {
            bytes.writeInt(level); bytes.writeInt(xp); bytes.writeInt(toNext); bytes.writeInt(points);
            for (int rank : ranks) bytes.writeByte(rank);
        }
        public static final class Handler implements IMessageHandler<Snapshot, IMessage> {
            @Override public IMessage onMessage(Snapshot message, MessageContext ctx) {
                // Forward to client proxy queue; never change GUI from Netty thread.
                EndlessBrood.proxy.acceptSkillSnapshot(message.level, message.xp,
                    message.toNext, message.points, message.ranks);
                return null;
            }
        }
    }
}
