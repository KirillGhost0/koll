package com.endlessbrood.common;

import java.math.BigInteger;

/** Cosmetic evolution: a visible milestone at every ten GLOBAL stages.
 * Pure math, safe for arbitrarily large BigInteger evolution values.
 * Render details are capped to protect clients, while mature skins alternate
 * after tier 9 so every later milestone is still visually distinguishable.
 */
public final class BroodVisualEvolution {
    private static final BigInteger TEN = BigInteger.TEN;
    private static final BigInteger MAX_INT = BigInteger.valueOf(Integer.MAX_VALUE);
    private BroodVisualEvolution() { }

    public static int tier(BigInteger stage) {
        if (stage == null || stage.signum() < 1) return 0;
        BigInteger t = stage.divide(TEN);
        // A signed int is enough for sensible hitbox sizes, but the underlying
        // BigInteger stage is never capped. Preserve modulo-128 phenotype steps
        // even after the integer limit, so each further 10 stages still changes
        // the mature creature's skin (without expanding its collision geometry).
        return t.compareTo(MAX_INT) > 0 ?
            2000000000 + t.and(BigInteger.valueOf(127L)).intValue() : t.intValue();
    }

    /** Base skin, infected, rotten, skeletal and two alternating ancient skins. */
    public static int skin(int tier) {
        if (tier < 1) return 0;
        if (tier < 3) return 1;
        if (tier < 6) return 2;
        if (tier < 9) return 3;
        return (tier & 1) == 0 ? 4 : 5;
    }

    /** A finite set of extra polygons; no per-stage GPU texture allocations. */
    public static int spines(int tier) {
        return Math.max(0, Math.min(9, tier));
    }

    /** Diminishing size growth, strictly bounded, avoids huge pathing hitboxes. */
    public static float scale(int tier) {
        if (tier <= 0) return 1.0F;
        double t = Math.min(10000D, tier);
        return (float) (1.0D + 0.12D * t / (12.0D + t));
    }
}
