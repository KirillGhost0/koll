package net.minecraft.util;
public class DamageSource { public static DamageSource magic = new DamageSource(); }
