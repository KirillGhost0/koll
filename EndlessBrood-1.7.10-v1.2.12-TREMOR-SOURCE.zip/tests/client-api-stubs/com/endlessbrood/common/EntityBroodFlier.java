package com.endlessbrood.common; public class EntityBroodFlier extends net.minecraft.entity.Entity { public int getDivePhase(){return 0;} }
