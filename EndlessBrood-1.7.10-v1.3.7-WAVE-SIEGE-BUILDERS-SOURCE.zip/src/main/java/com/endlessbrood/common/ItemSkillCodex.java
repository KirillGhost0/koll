package com.endlessbrood.common;

import java.util.List;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ChatComponentText;
import net.minecraft.world.World;

/** No commands, permissions, GUI library or network synchronization required. */
public final class ItemSkillCodex extends Item {
    public ItemSkillCodex() {
        setUnlocalizedName("endlessbrood.skillCodex");
        setTextureName("endlessbrood:skill_codex");
        setCreativeTab(CreativeTabs.tabTools);
        setMaxStackSize(1);
    }
    @Override
    public ItemStack onItemRightClick(ItemStack stack, World world, EntityPlayer player) {
        if (world.isRemote) com.endlessbrood.EndlessBrood.proxy.openSkillGui();
        return stack;
    }
    @Override
    @SuppressWarnings({"unchecked", "rawtypes"})
    public void addInformation(ItemStack stack, EntityPlayer player, List lines, boolean advanced) {
        lines.add("Gain survivor XP by defeating parasites.");
        lines.add("Right-click: open your survivor skill book");
        lines.add("Skills persist through death; book is craftable again.");
    }
}
