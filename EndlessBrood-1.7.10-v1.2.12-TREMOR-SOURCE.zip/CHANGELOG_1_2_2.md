# 1.2.2 – Swarm Pressure
- Added configurable spawnPressure, swarmPressure and infectionPressure (default 2, min 1 max 4).
- Higher natural spawn weight and scouting frequency in previously generated worlds.
- Bigger but bounded scout packs, faster nest cycles and 50% larger wave targets.
- Faster bite infections, fatal conversions, incubation and contagious spores.
- Faster tainted-soil expansion; radiation and ward protection preserved.
- Kept 15-day wave spacing and 3x slower evolutionary progress.
- Added isolated arithmetic tests. Full Forge build and multiplayer still unverified.
