package test;
import com.endlessbrood.common.BroodEliteWaveRules;
public final class BroodEliteWaveSmoke {
    static void ok(boolean b, String msg) { if (!b) throw new AssertionError(msg); }
    public static void main(String[] args) {
        int[] original = {38,48,58,67,77,86,96,102};
        int[] expected = {36,40,42,44,32,50,48,50};
        int[][] mix = {
            {0,0,0,0,0}, {2,0,0,0,0}, {3,2,0,2,0},
            {4,3,2,2,0}, {3,3,2,2,1}, {5,4,3,4,2},
            {5,5,4,4,3}, {5,5,4,5,4}
        };
        for(int i=0;i<8;i++) {
            BroodEliteWaveRules.Plan plan=BroodEliteWaveRules.plan(i+1, 100L, original[i], 58);
            ok(plan.total==expected[i], "wave "+(i+1)+" count "+plan.total);
            int sum=plan.regular;
            for(int k=0;k<5;k++) { ok(plan.elite[k]==mix[i][k], "quota "+i+":"+k); sum+=plan.elite[k]; }
            ok(sum==plan.total, "plan sum");
            ok(plan.regular>=plan.total/2, "regular share");
            System.out.printf("Wave %d: heads=%d regular=%d elite=[%d,%d,%d,%d,%d] equivalent=%.1f%n",
                i+1, plan.total,plan.regular,plan.elite[0],plan.elite[1],plan.elite[2],plan.elite[3],plan.elite[4],plan.threatEquivalent);
        }
        BroodEliteWaveRules.Plan premature=BroodEliteWaveRules.plan(5, 0L,77,58);
        ok(premature.regular==premature.total && premature.total==32, "stage locks compensated");
        BroodEliteWaveRules.Plan below=BroodEliteWaveRules.plan(5, 40L,77,58);
        ok(below.elite[2]==0 && below.elite[4]==0, "stage gate iron/overmind");
        BroodEliteWaveRules.Plan intense=BroodEliteWaveRules.plan(100000,Long.MAX_VALUE,102,58);
        ok(intense.total<=60 && intense.regular>=intense.total/2,"late cap");
        BroodEliteWaveRules.Plan reduced=BroodEliteWaveRules.plan(5,100L,77,35);
        ok(reduced.total<45 && reduced.regular>=reduced.total/2,"config low cap");
        ok(BroodEliteWaveRules.plan(5,100L,77,58).threatEquivalent +
            com.endlessbrood.common.BroodWaveRules.bossThreatWeight(5) >= 78D,
            "boss offsets wave-5 ordinary headcount reduction");
        ok(com.endlessbrood.common.BroodWaveRules.hasSovereign(5) &&
            com.endlessbrood.common.BroodWaveRules.hasSovereign(10) &&
            !com.endlessbrood.common.BroodWaveRules.hasSovereign(4) &&
            !com.endlessbrood.common.BroodWaveRules.hasSovereign(6), "once every 5 waves");
        for (int wave : new int[]{10,15,20,25,1000}) {
            BroodEliteWaveRules.Plan boss = BroodEliteWaveRules.plan(wave,100L,102,58);
            ok(boss.total<=com.endlessbrood.common.BroodWaveRules.siegeHeadcountCeiling(wave),
               "late boss wave headcount cap");
            ok(boss.regular + boss.elite[0]+boss.elite[1]+boss.elite[2]+boss.elite[3]+boss.elite[4]==boss.total,
               "boss wave quotas add up");
            System.out.printf("Boss wave %d: ordinary+elite=%d bossHP=%d attack=%d totalThreat=%.1f%n",
               wave,boss.total,com.endlessbrood.common.BroodWaveRules.bossHealth(wave),
               com.endlessbrood.common.BroodWaveRules.bossAttack(wave),
               boss.threatEquivalent+com.endlessbrood.common.BroodWaveRules.bossThreatWeight(wave));
        }
        System.out.println("PASS: five elite classes, progression and budget/optimization math");
    }
}
