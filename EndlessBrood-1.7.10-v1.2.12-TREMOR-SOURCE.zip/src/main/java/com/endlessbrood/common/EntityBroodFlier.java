package com.endlessbrood.common;

import com.endlessbrood.EndlessBrood;
import java.math.BigInteger;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityFlying;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

/** Airborne, fully separate brood caste. No ground pathfinder or chunk loading. */
public class EntityBroodFlier extends EntityFlying {
    private EntityLivingBase target;
    private EntityPlayer waveTarget;
    private long waveTargetExpiry;
    private boolean waveDebugCreative;

    private double hoverX, hoverY, hoverZ;
    private int nextBite;
    private float biteDamage = 3.0F;
    // 0 ordinary flight, 1 screamed warning, 2 dive, 3 climb / recover.
    private int divePhase;
    private int diveTicks;
    private int diveCooldown = 40;
    private boolean fleeingRad;
    private int radiationAvoidTicks;

    /** An alerted flyer keeps its own target unless the new one is substantially closer. */
    public boolean acceptSwarmTarget(EntityLivingBase prey) {
        if (worldObj.isRemote || !BroodConfig.swarmTacticsEnabled || fleeingRad ||
            radiationAvoidTicks > 0 || waveTarget != null ||
            prey == null || !prey.isEntityAlive() || prey.worldObj != worldObj ||
            prey instanceof EntityBroodFlier || prey instanceof EntityParasite ||
            prey instanceof EntityPlayer && ((EntityPlayer)prey).capabilities.isCreativeMode) return false;
        double max = prey instanceof EntityPlayer ?
            (double)BroodConfig.distantPlayerDetectionRange : 36D;
        double distance = getDistanceSqToEntity(prey);
        if (distance > max * max) return false;
        if (target != null && target.isEntityAlive() &&
            !BroodSwarmRules.shouldAcceptSharedTarget(distance, getDistanceSqToEntity(target))) return false;
        target = prey;
        return true;
    }

    public EntityLivingBase getBroodTarget() { return target; }



    public EntityBroodFlier(World world) {
        super(world);
        setSize(0.9F, 0.65F);
        experienceValue = 6;
    }
    @Override
    protected void entityInit() {
        super.entityInit();
        dataWatcher.addObject(20, Byte.valueOf((byte)0));
    }
    public int getDivePhase() { return dataWatcher.getWatchableObjectByte(20); }
    private void changeDivePhase(int next) {
        divePhase = next;
        if (getDivePhase() != next) dataWatcher.updateObject(20, Byte.valueOf((byte)next));
    }
    @Override protected boolean canDespawn() {
        return !BroodConfig.parasitesPersistent && super.canDespawn();
    }
    @Override protected boolean isAIEnabled() { return true; }
    @Override protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(18.0D);
        getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.27D);
        getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(BroodConfig.distantPlayerDetectionRange);
    }
    @Override protected String getLivingSound() {
        return BroodConfig.horrorSoundsEnabled ? "endlessbrood:chitter" : "mob.bat.idle";
    }
    @Override protected String getHurtSound() {
        return BroodConfig.horrorSoundsEnabled ? "endlessbrood:hiss" : "mob.bat.hurt";
    }
    @Override protected String getDeathSound() {
        return BroodConfig.horrorSoundsEnabled ? "endlessbrood:death" : "mob.bat.death";
    }
    @Override public int getTalkInterval() { return 340; }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (worldObj.isRemote || !isEntityAlive()) return;
        // Air caste continues improving with infinite stage progression,
        // but its individual damage/HP stay capped for playable NTM combat.
        if (ticksExisted == 1 || ticksExisted % 200 == 0) {
            double logStage = EvolutionMath.logOnePlus(EvolutionData.get(worldObj).getStage());
            double newMax = Math.min(85.0D, 18.0D + 5.0D * logStage);
            double oldMax = getMaxHealth();
            getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(newMax);
            if (getHealth() > 0.0F && newMax > oldMax) heal((float)(newMax - oldMax));
            biteDamage = (float)Math.min(15.0D, 3.0D + 0.75D * logStage);
        }
        if (waveTarget != null && (!waveTarget.isEntityAlive() || waveTarget.worldObj != worldObj ||
            worldObj.getTotalWorldTime() >= waveTargetExpiry ||
            (!waveDebugCreative && waveTarget.capabilities.isCreativeMode) ||
            getDistanceSqToEntity(waveTarget) >= 192D * 192D)) waveTarget = null;
        if ((ticksExisted + getEntityId()) % 35 == 0 && radiationAvoidTicks <= 0) acquirePrey();
        if (waveTarget != null) target = waveTarget;
        if (radiationAvoidTicks > 0) --radiationAvoidTicks;
        fleeingRad = radiationAvoidTicks > 0;
        // Flying enemies are vulnerable to HBM chunk radiation, just like land parasites.
        if (BroodConfig.radiationFear && (ticksExisted + getEntityId()) %
                BroodConfig.radiationPulseTicks == 0) {
            float rad = BroodRadiationBridge.getRadiation(worldObj,
                MathHelper.floor_double(posX), MathHelper.floor_double(posY), MathHelper.floor_double(posZ));
            if (rad >= BroodConfig.radiationFearThreshold) {
                fleeingRad = true;
                radiationAvoidTicks = BroodConfig.radiationPulseTicks;
                changeDivePhase(0);
                diveCooldown = BroodConfig.horrorDiveCooldownTicks;
                target = null;
                hoverX = posX + (rand.nextBoolean() ? 16 : -16);
                hoverZ = posZ + (rand.nextBoolean() ? 16 : -16);
                hoverY = Math.min(240, posY + 5);
                if (rad >= BroodConfig.radiationDamageThreshold) {
                    attackEntityFrom(DamageSource.magic, BroodConfig.radiationDamageAmount);
                }
            }
        }
        if (fleeingRad) target = null;
        if (target != null && (!target.isEntityAlive() || target.dimension != dimension ||
                getDistanceSqToEntity(target) > (waveTarget == target ? 36864D :
                    (double) BroodConfig.distantPlayerDetectionRange * BroodConfig.distantPlayerDetectionRange))) target = null;
        // Telegraph dives to give players a brief chance to react. Finite state
        // machine: no per-tick pathfinder, no extra entities or chunk loading.
        if (target == null || !BroodConfig.horrorDiveEnabled || fleeingRad) {
            changeDivePhase(0);
            diveTicks = 0;
        } else if (diveCooldown > 0) {
            --diveCooldown;
        }
        if (target != null) {
            double distance = getDistanceSqToEntity(target);
            if (BroodConfig.horrorDiveEnabled && divePhase == 0 &&
                diveCooldown <= 0 && distance > 64D && distance < 784D &&
                canEntityBeSeen(target)) {
                changeDivePhase(1);
                diveTicks = 18;
                if (BroodConfig.horrorSoundsEnabled)
                    worldObj.playSoundAtEntity(this, "endlessbrood:screech", 1.25F, 0.88F);
            }
            if (divePhase == 1) {
                // Hover high enough to be visible before plunging, but stay in range.
                hoverX = target.posX;
                hoverY = Math.min(246D, target.posY + target.height + 4D);
                hoverZ = target.posZ;
                if (--diveTicks <= 0) {
                    changeDivePhase(2);
                    diveTicks = 35;
                }
            } else if (divePhase == 2) {
                hoverX = target.posX;
                hoverY = target.posY + target.height * 0.55D;
                hoverZ = target.posZ;
                if (--diveTicks <= 0) {
                    changeDivePhase(3);
                    diveTicks = 25;
                }
            } else if (divePhase == 3) {
                hoverX = posX + (posX - target.posX) * 0.12D;
                hoverY = Math.min(246D, Math.max(posY + 2.5D, target.posY + 5D));
                hoverZ = posZ + (posZ - target.posZ) * 0.12D;
                if (--diveTicks <= 0) {
                    changeDivePhase(0);
                    diveCooldown = BroodConfig.horrorDiveCooldownTicks;
                }
            } else if (BroodConfig.swarmTacticsEnabled && distance < 900D &&
                       distance > 16D) {
                // Circle the victim in separate sectors until a scheduled dive.
                // Orbiting is steering only: no expensive air pathfinding.
                double[] sector = BroodSwarmRules.airOrbit(target.posX, target.posZ,
                    getEntityId(), worldObj.getTotalWorldTime(), BroodConfig.swarmAirOrbitRadius);
                hoverX = sector[0];
                hoverY = Math.min(250D, target.posY + target.height + 3.0D);
                hoverZ = sector[1];
            } else {
                hoverX = target.posX;
                hoverY = Math.min(250D, target.posY + target.height + 0.5D);
                hoverZ = target.posZ;
            }
            if (distance < 3.2D && nextBite-- <= 0) {
                target.attackEntityFrom(DamageSource.causeMobDamage(this), biteDamage);
                nextBite = 30;
                if (divePhase == 2) {
                    changeDivePhase(3);
                    diveTicks = 25;
                }
            }
        } else if (ticksExisted % 90 == 0 || (hoverX == 0 && hoverZ == 0)) {
            hoverX = posX + rand.nextInt(15) - 7;
            hoverY = MathHelper.clamp_double(posY + rand.nextInt(9) - 4, 64, 238);
            hoverZ = posZ + rand.nextInt(15) - 7;
        }
        // Direct steering: only three bounded velocities, no expensive A* on air blocks.
        double dx = hoverX - posX, dy = hoverY - posY, dz = hoverZ - posZ;
        double dist = Math.sqrt(dx*dx + dy*dy + dz*dz);
        if (dist > 0.75D) {
            double accel = divePhase == 2 ? 0.125D : target == null ? 0.045D : 0.070D;
            double limit = divePhase == 2 ? 0.65D : 0.42D;
            motionX = MathHelper.clamp_double(motionX * 0.84D + dx/dist * accel, -limit, limit);
            motionY = MathHelper.clamp_double(motionY * 0.84D + dy/dist * accel, -0.45D, 0.45D);
            motionZ = MathHelper.clamp_double(motionZ * 0.84D + dz/dist * accel, -limit, limit);
        } else {
            motionX *= 0.75D; motionY *= 0.75D; motionZ *= 0.75D;
        }
        if (isCollidedHorizontally) motionY = 0.17D;
        if (motionX * motionX + motionZ * motionZ > 0.001D) {
            rotationYaw = (float) (-Math.atan2(motionX, motionZ) * 180D / Math.PI);
            renderYawOffset = rotationYaw;
        }
    }

    /** Siege formations initially focus the threatened player instead of drifting away. */
    public void setSiegeTarget(EntityLivingBase player) {
        if (!worldObj.isRemote && player != null && player.isEntityAlive()) target = player;
    }
    public void setSiegeTarget(EntityPlayer player, boolean debugCreative) {
        if (worldObj.isRemote || player == null) return;
        waveTarget = player;
        waveDebugCreative = debugCreative;
        waveTargetExpiry = worldObj.getTotalWorldTime() + 7200L;
        target = player;
    }

    @SuppressWarnings("unchecked")
    private void acquirePrey() {
        if (waveTarget != null) { target = waveTarget; return; }
        if (target instanceof EntityPlayer && target.isEntityAlive() &&
            getDistanceSqToEntity(target) <= 48D * 48D) return;
        EntityLivingBase nearest = null;
        double best = 24D * 24D;
        List<EntityLivingBase> nearby = worldObj.getEntitiesWithinAABB(EntityLivingBase.class,
            boundingBox.expand(24D, 12D, 24D));
        for (EntityLivingBase candidate : nearby) {
            if (candidate == this || candidate instanceof EntityBroodFlier ||
                candidate instanceof EntityParasite || !candidate.isEntityAlive() ||
                candidate instanceof EntityPlayer && ((EntityPlayer)candidate).capabilities.isCreativeMode)
                continue;
            double dist = getDistanceSqToEntity(candidate);
            if (dist < best && (dist < 64D || canEntityBeSeen(candidate))) {
                best = dist;
                nearest = candidate;
            }
        }
        // A direct list lookup of active players stays cheap at 150 blocks.
        // Other creatures continue to use a bounded 24-block scan.
        double longRangeSq = (double) BroodConfig.distantPlayerDetectionRange *
            BroodConfig.distantPlayerDetectionRange;
        if (nearest == null) best = longRangeSq;
        for (Object obj : worldObj.playerEntities) {
            if (!(obj instanceof EntityPlayer)) continue;
            EntityPlayer player = (EntityPlayer) obj;
            if (!player.isEntityAlive() || player.capabilities.isCreativeMode) continue;
            double dist = getDistanceSqToEntity(player);
            if (dist < longRangeSq && (nearest == null || dist < best)) {
                nearest = player;
                best = dist;
            }
        }
        target = nearest;
    }
    @Override
    protected void dropFewItems(boolean recent, int looting) {
        if (recent && EndlessBrood.chitin != null) BroodLootDrops.roll(this, EndlessBrood.chitin, 1 + rand.nextInt(2));
        if (recent && EndlessBrood.sporeSac != null && rand.nextInt(3) == 0)
            BroodLootDrops.roll(this, EndlessBrood.sporeSac, 1);
    }
}
