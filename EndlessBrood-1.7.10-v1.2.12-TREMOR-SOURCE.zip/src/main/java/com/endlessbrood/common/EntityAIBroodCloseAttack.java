package com.endlessbrood.common;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;

/**
 * Protects server TPS from vanilla A* to targets detected up to 150 blocks out.
 * Vanilla melee pathfinding begins only when the prey is already near enough.
 * Long-range detection is unaffected; EntityParasite pursues with small hops.
 */
public final class EntityAIBroodCloseAttack extends EntityAIAttackOnCollide {
    private final EntityParasite mob;

    public EntityAIBroodCloseAttack(EntityParasite mob, double speed, boolean longMemory) {
        super(mob, speed, longMemory);
        this.mob = mob;
    }

    @Override public boolean shouldExecute() {
        EntityLivingBase victim = mob.getAttackTarget();
        return victim != null && victim.isEntityAlive() &&
            mob.getDistanceSqToEntity(victim) <=
                BroodNavigationRules.CLOSE_CHASE_DISTANCE * BroodNavigationRules.CLOSE_CHASE_DISTANCE &&
            BroodAiBudget.tryPath(mob.worldObj) && super.shouldExecute();
    }

    @Override public boolean continueExecuting() {
        EntityLivingBase victim = mob.getAttackTarget();
        return victim != null && victim.isEntityAlive() &&
            mob.getDistanceSqToEntity(victim) <=
                BroodNavigationRules.CLOSE_CHASE_DISTANCE * BroodNavigationRules.CLOSE_CHASE_DISTANCE * 1.5D &&
            super.continueExecuting();
    }
}
