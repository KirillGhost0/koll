# Endless Brood 1.2.4 — Horror Visual Update

- Six parasite castes remade with new asymmetric silhouettes, skeletal protrusions, articulated jaws and attached legs/plates.
- Winged brood has a new organic body, ribs, hook claws, bone fingers, jagged membrane panels and a stinger.
- Eight entity skins reauthored into pixelated 512×128 UV atlases: stalker, scuttler, bulwark, thornback, colossus, matriarch, commander and flier.
- Fixes the common issue of detached visual pieces: all additional components are connected to parent bones.
- UV islands are allocated per model primitive and never overlap; no UV island extends outside a texture.
- No world-data migration. Wave system, player skills, NTM protection and existing entities unchanged.

**Build status:** source generated and static structural/atlas checks completed. Does NOT claim a successful Forge compile or in-game test.
