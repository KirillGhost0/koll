package test;

import com.endlessbrood.common.BroodDailyBudget;

/** Pure-Java boundary checks; Forge runtime must still be verified. */
public final class BroodEvolution136Smoke {
    public static void main(String[] args) {
        final int passivePerDay = (24000 / 600) * (1 * 2);
        if (passivePerDay != 80 || passivePerDay + 180 != 260) {
            throw new AssertionError("Expected 80 passive + 180 combat = 260");
        }
        BroodDailyBudget budget = new BroodDailyBudget();
        if (budget.consume(25, 0L, 180) != 25) throw new AssertionError("1st kill");
        if (budget.consume(200, 1L, 180) != 155) throw new AssertionError("180 cap");
        if (budget.consume(10, 10L, 180) != 0) throw new AssertionError("cap exceeded");
        if (budget.getUsed(10L) != 180) throw new AssertionError("used");
        if (budget.consume(10, 24000L, 180) != 10) throw new AssertionError("day rollover");
        BroodDailyBudget restored = new BroodDailyBudget();
        restored.restore(1L, 175);
        if (restored.consume(25, 24010L, 180) != 5) throw new AssertionError("NBT restore cap");
        if (restored.consume(25, 48000L, 180) != 25) throw new AssertionError("restore rollover");
        System.out.println("PASS: v1.3.6 combat 180, passive 80, combined 260; NBT + reset");
    }
}
