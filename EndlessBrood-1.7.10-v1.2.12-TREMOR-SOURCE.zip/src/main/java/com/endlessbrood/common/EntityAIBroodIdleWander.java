package com.endlessbrood.common;

import net.minecraft.entity.ai.EntityAIWander;

/** Vanilla roaming must not overwrite a target's short waypoint route. */
public final class EntityAIBroodIdleWander extends EntityAIWander {
    private final EntityParasite mob;

    public EntityAIBroodIdleWander(EntityParasite mob, double speed) {
        super(mob, speed);
        this.mob = mob;
    }

    @Override public boolean shouldExecute() {
        return mob.getAttackTarget() == null && super.shouldExecute();
    }

    @Override public boolean continueExecuting() {
        return mob.getAttackTarget() == null && super.continueExecuting();
    }
}
