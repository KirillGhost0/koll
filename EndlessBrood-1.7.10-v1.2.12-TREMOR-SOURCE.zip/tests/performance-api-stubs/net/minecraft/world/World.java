package net.minecraft.world;
public class World {
    public boolean isRemote;
    private long ticks;
    public long getTotalWorldTime(){return ticks;}
    public void setTotalWorldTime(long t){ticks=t;}
}
