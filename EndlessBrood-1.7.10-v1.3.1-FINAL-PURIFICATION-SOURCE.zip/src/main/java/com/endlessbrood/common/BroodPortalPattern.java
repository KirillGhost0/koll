package com.endlessbrood.common;

import com.endlessbrood.EndlessBrood;
import net.minecraft.block.Block;
import net.minecraft.world.World;

/** Validation is local (4x4, no chunk-forcing); protects other mods' blocks. */
public final class BroodPortalPattern {
    private BroodPortalPattern() { }
    public static void tryActivate(World w, int x, int y, int z) {
        if (!BroodRealmTravel.realmAvailable || w.isRemote) return;
        for (int dx=-3; dx<=0; ++dx) for (int dz=-3; dz<=0; ++dz) {
            int sx=x+dx, sz=z+dz;
            if (!corners(w,sx,y,sz)) continue;
            boolean clear = true;
            for (int ix=1;ix<=2;ix++) for (int iz=1;iz<=2;iz++) {
                Block inside = w.getBlock(sx+ix, y, sz+iz);
                if (!w.isAirBlock(sx+ix,y,sz+iz) && inside != EndlessBrood.abyssPortal)
                    clear=false;
            }
            if (!clear) continue;
            for (int ix=1;ix<=2;ix++) for (int iz=1;iz<=2;iz++)
                w.setBlock(sx+ix, y, sz+iz, EndlessBrood.abyssPortal, 0, 3);
            return;
        }
    }
    private static boolean corners(World w,int sx,int y,int sz) {
        for (int dx=0;dx<=3;dx+=3) for (int dz=0;dz<=3;dz+=3) {
            int x=sx+dx,z=sz+dz;
            if (!w.blockExists(x,y,z) || w.getBlock(x,y,z)!=EndlessBrood.abyssAnchor ||
                !BroodRealmRules.isCorrectCorner(dx,dz,w.getBlockMetadata(x,y,z))) return false;
        }
        return true;
    }
    public static void removeNearbyPortal(World w, int x,int y,int z) {
        for (int dx=-3;dx<=3;dx++) for(int dz=-3;dz<=3;dz++) {
            int ax=x+dx, az=z+dz;
            if (w.blockExists(ax,y,az) && w.getBlock(ax,y,az)==EndlessBrood.abyssPortal)
                w.setBlockToAir(ax,y,az);
        }
    }
}
