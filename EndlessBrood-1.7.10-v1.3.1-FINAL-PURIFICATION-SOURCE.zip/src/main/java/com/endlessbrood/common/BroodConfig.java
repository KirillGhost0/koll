package com.endlessbrood.common;

import java.io.File;
import java.math.BigInteger;
import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import net.minecraftforge.common.config.Configuration;

public final class BroodConfig {
    /** Base value remains 100 for compatibility with configuration files from 0.1.0. */
    public static int evolutionCost;
    /** A 3x multiplier is applied uniformly to passive, kill and conversion progress. */
    public static int evolutionSlowdownMultiplier;
    public static int growthInterval;
    public static int growthPoints;
    public static int killPoints;
    public static int combatPointsPerDay;
    public static int infectionPoints;
    public static int infectionTicks;
    public static int incubationSlowdownMultiplier;
    public static int spawnWeight;
    public static double infectionChance;
    public static double killConversionChance;
    public static int localPopulationLimit;
    /** New 1.2.2 knobs work in worlds that already have endlessbrood.cfg. */
    public static int spawnPressure;
    public static int swarmPressure;
    public static int infectionPressure;
    public static int patrolIntervalTicks;
    public static int patrolLocalCap;
    /** Difficult survival: local assaults even while players stay at a base. */
    public static boolean siegeEnabled;
    public static int siegeUnlockStage;
    public static int siegeIntervalTicks;
    public static int siegePackSize;
    public static int siegeLocalCap;
    public static boolean parasitesPersistent;
    public static boolean contagiousInfection;
    public static int infectionContagionTicks;
    public static float infectionContagionChance;
    public static boolean infectionRadiationCure;
    public static int infectedLocalLimit;
    public static double adaptationMaxResistance;
    public static boolean adaptiveDefense;
    public static boolean preserveTamedAnimals;
    public static boolean nestsEnabled;
    public static int nestChancePer10000Chunks;
    public static int nestPulseTicks;
    public static int nestSpawnUnlockStage;
    public static int nestPopulationLimit;
    public static boolean taintedSoilSpread;
    public static boolean nestExpansion;
    public static int nestExpansionChance;
    public static boolean wardsEnabled;
    public static int wardRadius;
    public static int wardPulseTicks;
    public static int aggressionRange;
    /** Distant player tracking uses the short world.playerEntities list, not huge chunk AABB scans. */
    public static int distantPlayerDetectionRange;
    public static float broodMovementSpeedMultiplier;
    public static int waveSizeMultiplier;
    public static int eliteWaveHeadcountPercent;
    /** 80 = 20% fewer ordinary wave parasites than in 1.2.6 (boss is separate). */
    public static int waveMobPercent;
    /** 20 = one fifth of the prior expected item drops from all brood creatures. */
    public static int parasiteLootPercent;
    public static int waveExtraLocalCap;
    public static int patrolExtraLocalCap;
    public static int naturalExtraLocalCap;
    public static int siegeExtraPackSize;
    public static int aggressionCloseRadius;
    public static int aggressionScanTicks;
    /** Server-safe long-range approach without giant vanilla A* searches. */
    /** Shared A* budget across ground parasites per server world tick. */
    public static int maxPathRequestsPerTick;
    /** Burst limit during every four-second wave pulse. */
    public static int maxWaveSpawnsPerPulse;
    public static int farPursuitCooldownTicks;
    public static int farPursuitStepBlocks;
    public static boolean scuttlerPounce;
    public static boolean thornbackRetaliation;
    public static boolean colossusRoar;
    // Dread update (1.2.5): all effects are bounded and configurable for NTM packs.
    public static boolean horrorSoundsEnabled;
    public static boolean horrorAmbushEnabled;
    public static boolean horrorDiveEnabled;
    public static int horrorAmbushCooldownTicks;
    public static int horrorDiveCooldownTicks;

    /** Local co-op attack coordination: bounded scans, no chunk loading. */
    public static boolean swarmTacticsEnabled;
    public static int swarmSignalRadius;
    public static int swarmSignalTicks;
    public static int swarmMaxFollowers;
    public static int swarmFlankTicks;
    public static int swarmFlankUnlockStage;
    public static float swarmGroundFlankRadius;
    public static float swarmAirOrbitRadius;


    public static boolean colonyTiers;
    public static int matureNestStage;
    public static int citadelNestStage;
    public static int nestUpgradeChance;
    public static int queenUnlockStage;
    public static int queenSpawnChance;
    public static int leaderRallyRadius;
    public static int leaderRallyTicks;
    public static boolean villageRaids;
    public static int raidUnlockStage;
    public static int raidSearchRadius;
    public static int raidSearchInterval;
    public static boolean nestDefense;
    public static int nestGuardRadius;
    public static int nestGuardLimit;
    public static boolean queenHeals;
    public static boolean sovereignFootsteps;
    public static boolean sovereignCameraShake;
    public static float sovereignCameraShakeStrength;
    public static int earlyScoutStartDay;
    public static int earlyScoutIntervalTicks;
    public static int earlyScoutLocalCap;
    public static boolean earlyNestEnabled;
    public static int earlyNestStartDay;
    public static int earlyNestMaxCount;
    public static int threatGraceDays;
    public static int initialOutbreakDistance;
    public static int invasionApproachDays;
    public static int outbreakPlayerBuffer;
    public static boolean retroactiveDistantNests;
    public static int retroSeedLimit;
    public static int retroSeedIntervalTicks;
    public static boolean blockNaturalSpawnInHomeZones;
    public static boolean wardsBlockNaturalSpawns;
    public static boolean colonyGuardAI;
    public static int colonyGuardReturnRadius;
    public static boolean leaderDefenseAlarm;
    public static int leaderDefenseRadius;
    public static int leaderDefenseLimit;

    public static boolean radiationFear;
    public static float radiationFearThreshold;
    public static float radiationDamageThreshold;
    public static float radiationSoilCleanThreshold;
    public static float radiationDamageAmount;
    public static int radiationPulseTicks;
    public static boolean radiationStopsNests;

    public static boolean allowTerrainDamage;
    public static boolean dropDestroyedBlocks;
    public static int blockDigTicks;
    public static int softDigStage;
    public static int woodenDigStage;
    public static int stoneDigStage;
    public static Set<String> protectedBlocks = Collections.emptySet();

    /** Server waves run against actual ticks in the overworld, not /time set. */
    public static int abyssDimensionId;
    public static boolean wavesEnabled;
    public static int waveIntervalDays;
    public static int waveMaxMobs;
    public static int waveLocalCap;
    public static int waveMaxGroups;
    public static int waveMinSpawnDistance;
    public static int waveMaxSpawnDistance;
    public static boolean waveBosses;
    public static int flyerUnlockStage;

    private BroodConfig() { }

    public static BigInteger effectiveEvolutionCost() {
        return BigInteger.valueOf(evolutionCost).multiply(BigInteger.valueOf(evolutionSlowdownMultiplier));
    }

    public static int effectiveIncubationTicks() {
        return BroodPressureRules.quickerInterval(
            infectionTicks * incubationSlowdownMultiplier, infectionPressure, 100);
    }

    public static int effectiveNaturalSpawnWeight() {
        return BroodPressureRules.more(spawnWeight, spawnPressure, 100);
    }
    public static int effectivePatrolTicks() {
        return BroodPressureRules.quickerInterval(patrolIntervalTicks, spawnPressure, 200);
    }
    public static int effectivePatrolCap() {
        return BroodThreatTuning.expandedLocalCap(patrolLocalCap, swarmPressure, 24,
            patrolExtraLocalCap, 36);
    }
    public static int effectiveLocalPopulationLimit() {
        return BroodThreatTuning.expandedLocalCap(localPopulationLimit, spawnPressure, 36,
            naturalExtraLocalCap, 56);
    }
    public static int effectiveNestPulseTicks() {
        return BroodPressureRules.quickerInterval(nestPulseTicks, swarmPressure, 200);
    }
    public static int effectiveNestPopulationLimit() {
        return BroodPressureRules.populationCap(nestPopulationLimit, swarmPressure, 24);
    }
    public static int effectiveRetroSeedInterval() {
        return BroodPressureRules.quickerInterval(retroSeedIntervalTicks, spawnPressure, 200);
    }
    public static int effectiveRetroSeedLimit() {
        return BroodPressureRules.more(retroSeedLimit, spawnPressure, 16);
    }
    public static int effectiveNestChance() {
        return BroodPressureRules.more(nestChancePer10000Chunks, spawnPressure, 10000);
    }
    public static int effectiveInfectionContagionTicks() {
        return BroodPressureRules.quickerInterval(infectionContagionTicks, infectionPressure, 40);
    }
    public static float effectiveInfectionChance() {
        return BroodPressureRules.chance((float) infectionChance, infectionPressure, 0.85F);
    }
    public static float effectiveKillConversionChance() {
        return BroodPressureRules.chance((float) killConversionChance, infectionPressure, 0.95F);
    }
    public static float effectiveContagionChance() {
        return BroodPressureRules.chance(infectionContagionChance, infectionPressure, 0.75F);
    }
    public static int effectiveInfectedLocalLimit() {
        return BroodPressureRules.populationCap(infectedLocalLimit, infectionPressure, 24);
    }
    public static int effectiveSoilSpreadDivisor() {
        return BroodPressureRules.quickerInterval(7, infectionPressure, 2);
    }
    public static int effectiveSoilInfectionDivisor() {
        return BroodPressureRules.quickerInterval(160, infectionPressure, 40);
    }
    public static int effectiveWaveMobCount(int baseline) {
        // A new multiplier applies in existing worlds even with an old mobsPerWave value.
        return BroodThreatTuning.waveGoal(baseline, swarmPressure, waveSizeMultiplier, waveMobPercent);
    }
    public static int effectiveWaveCap() {
        return BroodThreatTuning.expandedLocalCap(waveLocalCap, swarmPressure, 70,
            waveExtraLocalCap, 96);
    }
    public static int effectiveSiegeCap() {
        return Math.min(80, siegeLocalCap);
    }

    public static void load(File file) {
        Configuration config = new Configuration(file);
        config.load();
        evolutionCost = config.getInt("pointsPerStage", "evolution", 100, 1, 1000000,
            "BASE points per stage (0.1.0-compatible). Effective cost = this value * evolutionSlowdownMultiplier.");
        evolutionSlowdownMultiplier = config.getInt("evolutionSlowdownMultiplier", "evolution", 3, 1, 100,
            "3 = THREE TIMES slower stage progression from ALL point sources. For slower NTM packs try 5 or 10.");
        growthInterval = config.getInt("ticksPerGrowth", "evolution", 600, 20, 24000,
            "Base passive progress interval in ticks. One second is 20 ticks at 20 TPS.");
        growthPoints = config.getInt("passiveGrowthPoints", "evolution", 1, 1, 10000,
            "Base passive point gain.");
        killPoints = config.getInt("pointsPerKill", "evolution", 25, 0, 10000,
            "Points gained when a parasite kills another mob.");
        combatPointsPerDay = config.getInt("combatPointsPerDay", "evolution", 90, 0, 100000,
            "Shared 24000-tick budget for kill+transformation points, per world. 0 disables combat progression (passive growth still continues). Prevents mob farms from skipping NTM's slow tech progression.");
        infectionPoints = config.getInt("pointsPerTransformation", "evolution", 10, 0, 10000,
            "Points gained when an infected creature transforms.");
        infectionTicks = config.getInt("incubationTicks", "infection", 600, 40, 12000,
            "BASE infection incubation, in ticks. Effective duration is multiplied by incubationSlowdownMultiplier.");
        incubationSlowdownMultiplier = config.getInt("incubationSlowdownMultiplier", "infection", 3, 1, 20,
            "3 = incubation takes 90 seconds instead of 30 seconds (at 20 TPS).");
        infectionChance = config.getFloat("infectionChance", "infection", 0.35F, 0F, 1F,
            "Chance to infect a supported creature per successful attack.");
        killConversionChance = config.getFloat("killConversionChance", "infection", 0.65F, 0F, 1F,
            "Chance to create a parasite immediately when it kills an eligible animal, villager, or zombie. Already-infected victims always attempt conversion. Local population limits still apply.");
        // Added in v1.2.2: old saved 1.2.1 configuration receives these defaults
        // without overwriting any user's existing tuning or the 3x evolution pacing.
        spawnPressure = config.getInt("spawnPressure", "threatIntensity", 3, 1, 4,
            "2 = twice the natural spawn weight and scouting frequency, with bounded local caps. 1 = previous behavior.");
        swarmPressure = config.getInt("swarmPressure", "threatIntensity", 3, 1, 4,
            "2 = twice the scouting group/colony offspring pressure plus 50 percent wave size. Wave schedule stays 15 days.");
        infectionPressure = config.getInt("infectionPressure", "threatIntensity", 3, 1, 4,
            "2 = roughly half incubation time, faster contagious spores and more infection/transformation attempts.");
        spawnWeight = config.getInt("naturalSpawnWeight", "spawning", 5, 0, 100,
            "Relative spawning weight against other monsters. Set to 0 to disable natural spawns.");
        localPopulationLimit = config.getInt("localParasiteLimit", "spawning", 12, 1, 80,
            "Maximum nearby parasites for natural spawning and infection transformations.");
        // Brand-new keys are picked up by already existing endlessbrood.cfg files.
        naturalExtraLocalCap = config.getInt("naturalExtraLocalCap", "wavefix2", 10, 0, 30,
            "Extra ordinary parasites permitted by the per-area cap (hard limit 56).");
        patrolExtraLocalCap = config.getInt("patrolExtraLocalCap", "wavefix2", 8, 0, 24,
            "Extra patrol parasites near a player (hard limit 36).");
        eliteWaveHeadcountPercent = config.getInt("eliteWaveHeadcountPercent", "eliteSieges", 58, 35, 100,
            "Percentage of 1.2.7 wave headcount (58 default). Strong elite castes REPLACE normal mobs, preserving the older 80% balancing and 20% loot.");
        waveSizeMultiplier = config.getInt("waveSizeMultiplier", "wavefix2", 2, 1, 4,
            "Increase wave size even if the old mobsPerWave remains unchanged. 2 means double.");
        // New keys in 1.2.7: existing endlessbrood.cfg files receive balanced defaults
        // without overwriting earlier player choices or retuning ordinary spawns.
        waveMobPercent = config.getInt("waveMobPercent", "balance127", 80, 10, 100,
            "Ordinary mobs per 15-day wave, percentage of the previous 1.2.6 amount. 80 = -20%. The single miniboss is unchanged.");
        parasiteLootPercent = config.getInt("parasiteLootPercent", "balance127", 20, 0, 100,
            "Item drop probability per generated item for all Brood creatures including miniboss, flyers and Scavenger bonus. 20 = five times less loot on average; XP and skills unchanged.");
        waveExtraLocalCap = config.getInt("waveExtraLocalCap", "wavefix2", 24, 0, 50,
            "Additional creatures permitted in an active siege wave, hard limit 96.");
        siegeExtraPackSize = config.getInt("siegeExtraPackSize", "wavefix2", 4, 0, 8,
            "Adds to regular assault packs without changing the existing siegePackSize config key.");
        distantPlayerDetectionRange = config.getInt("distantPlayerDetectionRange", "wavefix2", 150, 32, 192,
            "Long-range PLAYER detection in loaded areas, cheap scan of player list; other mobs are hunted locally.");
        broodMovementSpeedMultiplier = config.getFloat("broodMovementSpeedMultiplier", "wavefix2", 1.18F, 1F, 1.5F,
            "Multiply land parasite movement speed. 1.18 roughly approaches a sprinting player for hunters.");

        // 1.2.3 values apply to already played worlds: brand-new keys, not overrides.
        siegeEnabled = config.getBoolean("enableBaseSieges", "brutal", true,
            "Periodic assault packs around survival players after their outbreak grace; only loaded chunks and no forced chunk loading.");
        siegeUnlockStage = config.getInt("baseSiegeUnlockStage", "brutal", 10, 0, 1000000,
            "At this global stage, local hunter packs begin targeting defended bases.");
        siegeIntervalTicks = config.getInt("baseSiegeIntervalTicks", "brutal", 1200, 200, 24000,
            "One 30-second siege attempt per area. This is NOT the 15-day major boss invasion.");
        siegePackSize = config.getInt("baseSiegePackSize", "brutal", 7, 1, 16,
            "Target number of creatures per raid. Each pulse respects loaded-chunk and local-entity limits.");
        siegeLocalCap = config.getInt("baseSiegeLocalCap", "brutal", 36, 6, 80,
            "Upper bound around each co-op group, shared across ground and flying parasites and commanders.");
        parasitesPersistent = config.getBoolean("keepParasitesPersistent", "brutal", true,
            "Prevent vanilla idle/far-distance despawn for parasites and flying creatures. May increase saved entities in busy loaded chunks; local spawn caps remain active.");
        patrolIntervalTicks = config.getInt("patrolIntervalTicks", "spawning", 3600, 200, 24000,
            "Period for one limited patrol attempt per occupied overworld. Only near players beyond the current safe boundary; unloaded chunks are never generated.");
        patrolLocalCap = config.getInt("patrolLocalCap", "spawning", 8, 1, 24,
            "Maximum ordinary + flying parasites near a player for background scouting patrols.");
        contagiousInfection = config.getBoolean("contagiousInfection", "infection", true,
            "Incubating creatures may spread spores to a nearby eligible creature every few seconds.");
        infectionContagionTicks = config.getInt("infectionContagionTicks", "infection", 200, 40, 2400,
            "Period in ticks between low-probability short-range infection attempts by infected hosts.");
        infectionContagionChance = config.getFloat("infectionContagionChance", "infection", 0.22F, 0F, 1F,
            "Chance per contagious-host check to transmit infection to one nearby creature.");
        infectionRadiationCure = config.getBoolean("infectionRadiationCure", "infection", true,
            "High HBM radiation or an upgraded ward cures an incubating host before transformation.");
        infectedLocalLimit = config.getInt("infectedLocalLimit", "infection", 8, 1, 32,
            "Maximum infected hosts within eight blocks when spores spread between creatures.");

        adaptiveDefense = config.getBoolean("adaptiveDefense", "mutations", true,
            "Collective resistance to fire, explosions, ranged hits and radiation-named damage. No HBM dependency.");
        adaptationMaxResistance = config.getFloat("maxAdaptiveResistance", "mutations", 0.6F, 0F, 0.75F,
            "Damage reduction ceiling: 0.6 means at most 60 percent, never full immunity.");
        preserveTamedAnimals = config.getBoolean("preserveTamedAnimals", "infection", true,
            "Prevent conversion of tamed wolves, cats and other tameable pets.");
        nestsEnabled = config.getBoolean("enableNests", "colonies", true,
            "Generate rare nest structures and enable nesting behavior.");
        nestChancePer10000Chunks = config.getInt("nestChancePer10000Chunks", "colonies", 65, 0, 10000,
            "Approximate chunks with a nest per 10000, in new overworld terrain only.");
        nestPulseTicks = config.getInt("nestPulseTicks", "colonies", 2400, 200, 24000,
            "Nest pulse timer in ticks. 2400 = 2 minutes at 20 TPS.");
        nestSpawnUnlockStage = config.getInt("nestSpawnUnlockStage", "colonies", 3, 0, 1000000,
            "Nests won't spawn parasites before this evolution stage.");
        nestPopulationLimit = config.getInt("nestLocalPopulationLimit", "colonies", 8, 1, 32,
            "Maximum parasites within 20 blocks from a nest.");
        nestExpansion = config.getBoolean("nestExpansion", "colonies", true,
            "Allow established nests at stage 40+ to establish a very rare daughter nest nearby.");
        nestExpansionChance = config.getInt("nestExpansionChancePerPulse", "colonies", 120, 5, 10000,
            "Chance 1/N per nest pulse to attempt establishing a daughter nest. Default 1/120 = about every four loaded-world hours per nest.");
        taintedSoilSpread = config.getBoolean("taintedSoilSpread", "colonies", true,
            "Slowly spread custom infected soil around nests, bounded by soil age and vanilla soil allowlist.");
        wardsEnabled = config.getBoolean("wardsEnabled", "defense", true,
            "Craftable iron/redstone/chitin ward: weakens nearby parasites and reclaims tainted soil.");
        wardRadius = config.getInt("wardRadius", "defense", 8, 3, 12,
            "Effective radius of a ward. Kept small to avoid large scans.");
        wardPulseTicks = config.getInt("wardPulseTicks", "defense", 120, 60, 600,
            "Time between ward pulses in game ticks (120 = 6 seconds).");
        aggressionRange = config.getInt("aggressionRange", "mobAbilities", 24, 8, 40,
            "Nearby scan for ALL living prey. Long-range player scanning has separate distantPlayerDetectionRange knob.");
        aggressionCloseRadius = config.getInt("aggressionCloseRadius", "mobAbilities", 8, 3, 12,
            "Nearby creatures are sensed even without line of sight. At longer distances a clear line of sight is required.");
        aggressionScanTicks = config.getInt("aggressionScanTicks", "performance", 20, 5, 100,
            "Check for nearby prey at this interval in ticks; 20 = once per second per parasite, staggered by entity ID.");
        maxPathRequestsPerTick = config.getInt("maxPathRequestsPerTick", "performance", 4, 1, 32,
            "Maximum synchronous pathfinding jobs per game tick across all ground brood in a world. Lower for NTM-heavy servers.");
        maxWaveSpawnsPerPulse = config.getInt("maxWaveSpawnsPerPulse", "performance", 6, 1, 32,
            "Maximum new wave creatures per 4-second pulse across all co-op groups. Total planned wave size is unchanged.");
        farPursuitCooldownTicks = config.getInt("farPursuitCooldownTicks", "performance", 30, 20, 200,
            "Interval between 12-block waypoint path attempts for targets farther than 24 blocks. Staggered between parasites. Higher = less server load.");
        farPursuitStepBlocks = config.getInt("farPursuitStepBlocks", "performance", 12, 6, 14,
            "Maximum length of a distant pursuit path. Do not increase this aggressively on servers with HBM NTM.");
        scuttlerPounce = config.getBoolean("scuttlerPounce", "mobAbilities", true,
            "The small scuttler can occasionally leap at prey from a medium distance.");
        thornbackRetaliation = config.getBoolean("thornbackRetaliation", "mobAbilities", true,
            "Thornbacks can deal 1 point of retaliatory contact damage.");
        colossusRoar = config.getBoolean("colossusRoar", "mobAbilities", true,
            "Rare late-game colossi debuff nearby prey instead of creating destructive explosions.");


        // New options apply to existing worlds with existing configs (1.2.6).
        swarmTacticsEnabled = config.getBoolean("enableSwarmTactics", "swarmTactics", true,
            "Pack signals, flank routes and coordinated aerial circles. No additional spawns or chunks loaded.");
        swarmSignalRadius = config.getInt("signalRadius", "swarmTactics", 24, 8, 40,
            "Nearby loaded parasites that can hear a hunting signal.");
        swarmSignalTicks = config.getInt("signalIntervalTicks", "swarmTactics", 100, 40, 400,
            "Staggered interval between local target broadcasts (100 ticks = 5 seconds).");
        swarmMaxFollowers = config.getInt("maxFollowersPerSignal", "swarmTactics", 6, 1, 12,
            "Maximum additional ground/air creatures contacted during a signal.");
        swarmFlankTicks = config.getInt("flankRepathTicks", "swarmTactics", 55, 30, 160,
            "Minimum delay between local flank path requests. Vanilla attacks keep priority in melee.");
        swarmFlankUnlockStage = config.getInt("flankUnlockStage", "swarmTactics", 12, 0, 1000000,
            "Normal hunts flank at this evolution stage. Wave participants may flank earlier.");
        swarmGroundFlankRadius = config.getFloat("groundFlankRadius", "swarmTactics", 4.5F, 2.5F, 8F,
            "Approach radius around the victim for agile ground units; never teleports or breaks blocks.");
        swarmAirOrbitRadius = config.getFloat("flierOrbitRadius", "swarmTactics", 6.5F, 4F, 11F,
            "Separation of flying wingman positions before their dive attacks.");

        horrorSoundsEnabled = config.getBoolean("enableHorrorSounds", "horror", true,
            "Custom original growls, chittering and swoop shrieks. Audio is spatial and uses vanilla sound attenuation.");
        horrorAmbushEnabled = config.getBoolean("enableStalkerAmbush", "horror", true,
            "Stalkers may freeze for 0.6 seconds when within sight of a player, then make a short pounce. Never delays major siege mobs.");
        horrorDiveEnabled = config.getBoolean("enableFlierDive", "horror", true,
            "Flying parasites telegraph a swoop with a screech and briefly accelerate toward the target.");
        horrorAmbushCooldownTicks = config.getInt("stalkerAmbushCooldownTicks", "horror", 320, 160, 1200,
            "Individual cooldown between stalker feints; does not pause normal attack logic during a siege.");
        horrorDiveCooldownTicks = config.getInt("flierDiveCooldownTicks", "horror", 105, 60, 400,
            "Cooldown after each aerial dive sequence, in ticks; use higher values on busy NTM servers.");
        colonyTiers = config.getBoolean("enableColonyTiers", "colonies", true,
            "Single nest block upgrades from Seed -> Mature -> Citadel, preserving tier as metadata.");
        matureNestStage = config.getInt("matureNestStage", "colonies", 12, 0, 1000000,
            "Global stage required before a seed nest can mature.");
        citadelNestStage = config.getInt("citadelNestStage", "colonies", 50, 0, 1000000,
            "Global stage required before a mature nest can become a citadel.");
        nestUpgradeChance = config.getInt("nestUpgradeChancePerPulse", "colonies", 16, 1, 10000,
            "Chance 1/N per nest pulse to advance one tier after the stage threshold.");
        queenUnlockStage = config.getInt("queenUnlockStage", "colonies", 60, 0, 1000000,
            "First stage eligible to produce a brood matriarch at citadel nests.");
        queenSpawnChance = config.getInt("queenSpawnChancePerPulse", "colonies", 30, 1, 10000,
            "Chance 1/N at an unprotected citadel's successful spawn opportunity. At most one matriarch nearby.");
        leaderRallyRadius = config.getInt("leaderRallyRadius", "mobAbilities", 12, 4, 18,
            "Leader buffs nearby parasites only; no world-wide search.");
        leaderRallyTicks = config.getInt("leaderRallyPeriodTicks", "mobAbilities", 200, 100, 1200,
            "Ticks between a matriarch's rally pulses; 200 = 10 seconds.");

        sovereignFootsteps = config.getBoolean("sovereignFootsteps", "sovereignAtmosphere", true,
            "Low original footstep rumble while the three-block sovereign walks; not played when stationary.");
        sovereignCameraShake = config.getBoolean("sovereignCameraShake", "sovereignAtmosphere", true,
            "Small client-only camera pulse near a walking sovereign. No effect on server aiming.");
        sovereignCameraShakeStrength = config.getFloat("sovereignCameraShakeStrength", "sovereignAtmosphere", 0.55F, 0F, 1F,
            "Maximum visual amplitude, attenuates to zero beyond 24 blocks. Set 0 to disable.");
        earlyScoutStartDay = config.getInt("earlyScoutStartDay", "earlyInfection", 1, 0, 10,
            "First scouts near players after this many REAL played Minecraft days. Independent of old 768-block home radius; no nests or biome changes from scouts.");
        earlyScoutIntervalTicks = config.getInt("earlyScoutIntervalTicks", "earlyInfection", 1800, 400, 24000,
            "Time between bounded attempts at a 1-2 creature scout pack in protected home territory.");
        earlyScoutLocalCap = config.getInt("earlyScoutLocalCap", "earlyInfection", 3, 1, 8,
            "Maximum nearby scouts while home protected. A wave uses its own caps.");
        earlyNestEnabled = config.getBoolean("enableEarlyInfectionNests", "earlyInfection", true,
            "Seed at most a few nests 56-100 blocks away in loaded chunks starting around day 3; wards and radiation block them.");
        earlyNestStartDay = config.getInt("earlyNestStartDay", "earlyInfection", 3, 1, 20,
            "Real played Minecraft day for a rare near-home infection nest. No ungenerated chunks scanned.");
        earlyNestMaxCount = config.getInt("earlyNestMaxCount", "earlyInfection", 2, 0, 5,
            "World-wide cap on nearby initial nests from the early infection path (stored in world data).");
        threatGraceDays = config.getInt("threatGraceDays", "evolution", 3, 0, 30,
            "No nests, natural/colony parasites or passive evolution for this many 20-minute Minecraft days after FIRST INSTALLATION into a world, including old saves. Previously saved values remain unchanged. Spawn eggs bypass this.");
        initialOutbreakDistance = config.getInt("initialOutbreakDistance", "outbreak", 768, 128, 4096,
            "Minimum horizontal distance in blocks between INITIAL outbreaks and world spawn / each co-op player's first-login position during the grace period.");
        invasionApproachDays = config.getInt("invasionApproachDays", "outbreak", 40, 1, 365,
            "Initial outbreaks begin outside initialOutbreakDistance, then the home exclusion zone gradually shrinks over this many REAL Minecraft days (24000 SERVER ticks each). /time set does not fast-forward simulation.");
        outbreakPlayerBuffer = config.getInt("outbreakPlayerBuffer", "outbreak", 96, 0, 256,
            "Initial nests must also be this far from any currently online player. Does NOT protect a moving player against existing parasites.");
        retroactiveDistantNests = config.getBoolean("retroactiveDistantNests", "outbreak", true,
            "Allow a few initial nests to appear in ALREADY GENERATED and currently loaded distant chunks. No forced chunk loads.");
        retroSeedLimit = config.getInt("retroSeedLimit", "outbreak", 4, 0, 12,
            "Maximum number of starter nests on already loaded land. Existing config files retain their old saved value; raise it manually if desired.");
        retroSeedIntervalTicks = config.getInt("retroSeedIntervalTicks", "outbreak", 1200, 200, 24000,
            "How often to attempt one retroactive distant starter nest while someone explores far from their starting base.");
        blockNaturalSpawnInHomeZones = config.getBoolean("blockNaturalSpawnInHomeZones", "outbreak", true,
            "Prevent RANDOM natural parasite spawn inside remembered starting-base areas. Parasites and infection may STILL spread into these areas from external colonies.");
        wardsBlockNaturalSpawns = config.getBoolean("wardsBlockNaturalSpawns", "defense", true,
            "Prevent naturally spawning parasites in the ward's protected area, in addition to existing colony/dig protection.");
        colonyGuardAI = config.getBoolean("colonyGuardAI", "mobAbilities", true,
            "Nest-born parasites return toward their recorded nest if idle and too far away. No scan for nests or unloaded chunks.");
        colonyGuardReturnRadius = config.getInt("colonyGuardReturnRadius", "performance", 18, 8, 32,
            "Distance at which an idle colony member tries returning home (checks approximately every 10 seconds).");
        leaderDefenseAlarm = config.getBoolean("leaderDefenseAlarm", "mobAbilities", true,
            "Hurting a matriarch can attract a limited number of already-spawned nearby defenders. No new mobs created.");
        leaderDefenseRadius = config.getInt("leaderDefenseRadius", "performance", 18, 6, 24,
            "Maximum radius of a matriarch's emergency defense alarm.");
        leaderDefenseLimit = config.getInt("leaderDefenseLimit", "performance", 6, 1, 12,
            "Maximum number of existing parasites redirected by a matriarch's alarm.");
        villageRaids = config.getBoolean("villageRaids", "mobAbilities", true,
            "After unlocking, idle parasites may approach a nearby inhabited village at night. No blocks are changed by the raid itself.");
        raidUnlockStage = config.getInt("villageRaidUnlockStage", "mobAbilities", 20, 0, 1000000,
            "First global stage when late-night village navigation is available.");
        raidSearchRadius = config.getInt("villageRaidSearchRadius", "performance", 48, 16, 64,
            "Maximum radius of a late-game village lookup; never loads destination chunks.");
        raidSearchInterval = config.getInt("villageRaidSearchIntervalTicks", "performance", 800, 200, 6000,
            "Cooldown between village lookups by a single idle parasite; adds random jitter.");
        nestDefense = config.getBoolean("nestDefense", "mobAbilities", true,
            "Clicking/attacking a nest provokes a limited number of nearby guards.");
        nestGuardRadius = config.getInt("nestGuardRadius", "performance", 18, 8, 24,
            "Local radius for guards that defend an attacked nest.");
        nestGuardLimit = config.getInt("nestGuardLimit", "performance", 6, 1, 12,
            "Maximum defenders assigned to a nest aggressor per alert.");
        queenHeals = config.getBoolean("matriarchHealing", "mobAbilities", true,
            "The queen's existing local rally also gently heals up to 4 injured allies per pulse.");

        radiationFear = config.getBoolean("radiationFear", "hbmRadiation", true,
            "If HBM 1.7.10 is present, parasites flee its actual chunk radiation and are hurt by strong radiation. Without HBM this feature is inert.");
        radiationFearThreshold = config.getFloat("fearThreshold", "hbmRadiation", 1.0F, 0.1F, 100000F,
            "HBM chunk RAD level that frightens parasites. Low levels force retreat but do not deal damage.");
        radiationDamageThreshold = config.getFloat("damageThreshold", "hbmRadiation", 5.0F, 0.1F, 100000F,
            "HBM chunk RAD level above which parasites take irradiation damage.");
        radiationSoilCleanThreshold = config.getFloat("soilCleanThreshold", "hbmRadiation", 5.0F, 0.1F, 100000F,
            "HBM chunk RAD level that slowly returns Endless Brood tainted soil to normal dirt.");
        radiationDamageAmount = config.getFloat("damagePerPulse", "hbmRadiation", 2.0F, 0.1F, 40F,
            "Health points lost per radiation pulse; high radiation does more, capped at 3x.");
        radiationPulseTicks = config.getInt("pulseTicks", "hbmRadiation", 60, 20, 400,
            "Radiation check interval in actual game ticks per parasite, staggered for server load.");
        radiationStopsNests = config.getBoolean("radiationStopsNests", "hbmRadiation", true,
            "Highly radioactive nests cannot spawn offspring, spread soil or expand, and new nests avoid radiation.");

        allowTerrainDamage = config.getBoolean("allowTerrainDamage", "blockBreaking", true,
            "Let evolved parasites dig their limited vanilla-block allowlist to pursue a nearby target. Respects mobGriefing gamerule.");
        dropDestroyedBlocks = config.getBoolean("dropDestroyedBlocks", "blockBreaking", false,
            "Drop items when parasites chew a block. False reduces item-entity lag during attacks.");
        blockDigTicks = config.getInt("baseDigTicks", "blockBreaking", 100, 20, 1200,
            "Minimum sustained time (in ticks) to break one permitted block. Stone takes twice as long.");
        softDigStage = config.getInt("softDigUnlockStage", "blockBreaking", 6, 0, 1000000,
            "First stage that can dig dirt, sand, gravel, leaves, snow, etc.");
        woodenDigStage = config.getInt("woodDigUnlockStage", "blockBreaking", 20, 0, 1000000,
            "First stage that can dig wood, glass and wool.");
        stoneDigStage = config.getInt("stoneDigUnlockStage", "blockBreaking", 60, 0, 1000000,
            "First stage when the CORROSIVE mutation can dig basic stone and bricks.");
        String[] ids = config.getStringList("protectedBlocks", "blockBreaking", new String[] {
            "minecraft:obsidian", "minecraft:bedrock", "minecraft:end_portal_frame",
            "minecraft:iron_block", "minecraft:diamond_block", "minecraft:emerald_block",
            "hbm:tile.concrete_rebar", "hbm:tile.concrete_super",
            "hbm:tile.reinforced_glass", "hbm:tile.reinforced_glass_pane"
        }, "Additional immune blocks by registry ID, one per line. All HBM/NTM blocks, including reinforced concrete and glass, are permanently protected even if omitted from this list. This setting does not affect explosions from other mods.");
        Set<String> names = new HashSet<String>();
        for (String name : ids) {
            String id = name.trim().toLowerCase(Locale.ROOT);
            if (!id.isEmpty()) names.add(id);
        }
        protectedBlocks = Collections.unmodifiableSet(names);
        abyssDimensionId = config.getInt("abyssDimensionId", "abyss", 74, 2, 10000,
            "Parasitic Abyss dimension ID. Must be unused by HBM and other installed mods; do not change after entering the dimension.");
        wavesEnabled = config.getBoolean("enableInvasionWaves", "waves", true,
            "Finite assault groups every N real played Minecraft days. No forced chunk loading.");
        waveIntervalDays = config.getInt("daysBetweenWaves", "waves", 15, 1, 1000,
            "Default 15 Minecraft days (5 real hours at 20 TPS). Old world age does NOT trigger instant waves.");
        waveMaxMobs = config.getInt("mobsPerWave", "waves", 24, 4, 64,
            "Maximum ordinary wave creatures in one wave, across active player groups.");
        waveLocalCap = config.getInt("maxNearPlayers", "waves", 28, 6, 70,
            "Maximum nearby parasite entities allowed during waves, including natural spawns.");
        waveMaxGroups = config.getInt("maxSimultaneousPlayerGroups", "waves", 2, 1, 4,
            "Co-op players within 128 blocks share one assault; groups are capped.");
        waveMinSpawnDistance = config.getInt("minWaveSpawnDistance", "waves", 36, 20, 60,
            "Distance from the player to an approaching assault mob.");
        waveMaxSpawnDistance = config.getInt("maxWaveSpawnDistance", "waves", 55, 30, 90,
            "Maximum distance, bounded to already-loaded chunks.");
        if (waveMaxSpawnDistance < waveMinSpawnDistance) waveMaxSpawnDistance = waveMinSpawnDistance;
        waveBosses = config.getBoolean("enableWaveMinibosses", "waves", true,
            "A huge ~Wither-class Dread Sovereign appears ONLY on every fifth wave (5, 10, 15...).");
        flyerUnlockStage = config.getInt("flyerEvolutionStage", "waves", 15, 1, 1000000,
            "Mature colonies can spawn flyers from this stage; wave 3+ also brings flyers.");
        if (config.hasChanged()) config.save();
    }
}
