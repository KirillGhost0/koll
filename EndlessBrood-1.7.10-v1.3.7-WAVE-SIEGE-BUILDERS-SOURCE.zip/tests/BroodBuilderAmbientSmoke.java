package test;
import java.math.BigInteger;
import java.util.Random;
import com.endlessbrood.common.BroodAmbientSpawnRules;
import com.endlessbrood.common.BroodBuilderRules;

public final class BroodBuilderAmbientSmoke {
    private static void check(boolean value, String reason) {
        if (!value) throw new AssertionError(reason);
    }
    public static void main(String[] args) {
        Random random = new Random(42);
        for (int i=0; i<10000; i++) {
            check(BroodAmbientSpawnRules.allow(random, 100), "100% keeps all");
            check(!BroodAmbientSpawnRules.allow(random, 0), "0% rejects all");
        }
        int kept=0, n=100000;
        for (int i=0; i<n; i++)
            if (BroodAmbientSpawnRules.allow(random, 50)) kept++;
        check(Math.abs(kept - n/2) < 700, "half of outside-wave spawn attempts: " + kept);
        check(!BroodBuilderRules.unlocked(BigInteger.valueOf(5)), "builder too early");
        check(BroodBuilderRules.unlocked(BigInteger.valueOf(6)), "builder unlock stage 6");
        check(BroodBuilderRules.mayBuild(true, true, true, false, 0, true, true), "valid construction");
        check(!BroodBuilderRules.mayBuild(false, true, true, false, 0, true, true), "mobGriefing");
        check(!BroodBuilderRules.mayBuild(true, false, true, false, 0, true, true), "terrain config");
        check(!BroodBuilderRules.mayBuild(true, true, false, false, 0, true, true), "missing nest");
        check(!BroodBuilderRules.mayBuild(true, true, true, true, 0, true, true), "ward");
        check(!BroodBuilderRules.mayBuild(true, true, true, false,
            BroodBuilderRules.MAX_BLOCKS_PER_BUILDER, true, true), "build cap");
        check(!BroodBuilderRules.mayBuild(true, true, true, false, 0, false, true), "modded foundation");
        check(!BroodBuilderRules.mayBuild(true, true, true, false, 0, true, false), "no replace blocks");
        System.out.println("PASS: ambient 50% statistical test (" + kept + "/" + n + "), builder boundaries");
    }
}
