package com.endlessbrood.common;

import com.endlessbrood.EndlessBrood;
import java.util.List;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.boss.IBossDisplayData;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

/** Dread Sovereign, a three-block tall wave-5/10/15... siege boss.
 * Server-owned, no explosions and never bypasses HBM/obsidian block policy.
 */
public class EntityBroodCommander extends EntityParasite implements IBossDisplayData {
    private int waveLevel = 5;
    public EntityBroodCommander(World world) {
        super(world);
        setSize(2.65F, 3.0F); // REAL hitbox, not renderer-only scaling
        experienceValue = 85;
        this.getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(0.85D);
    }

    @Override public String getCommandSenderName() { return "Владыка ужаса"; }
    /** Once spawned, the rare boss stays in the world until killed. */
    @Override protected boolean canDespawn() { return false; }

    public void setWaveLevel(int level) {
        waveLevel = Math.max(5, level);
        configureSpawnMorph(4);
        setSize(2.65F, 3.0F); // configureSpawnMorph modifies size; restore boss bounds
        applyBossFloor(true);
    }
    private void applyBossFloor(boolean healFull) {
        double max = Math.max(getMaxHealth(), BroodWaveRules.bossHealth(waveLevel));
        getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(max);
        getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(
            Math.max(getEntityAttribute(SharedMonsterAttributes.attackDamage).getBaseValue(),
                BroodWaveRules.bossAttack(waveLevel)));
        getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(0.85D);
        if (healFull) setHealth((float)max);
    }
    /** The base creature updates evolution stats every 200 ticks. Preserve boss HP
     * when its colossus-derived numbers are recalculated so it cannot suddenly
     * lose most of its health without being hit. */
    @Override protected void updateAttributesFromEvolution() {
        float before = getHealth();
        super.updateAttributesFromEvolution();
        applyBossFloor(false);
        if (before > 0F) setHealth(Math.min(before, getMaxHealth()));
    }
    @Override public void onLivingUpdate() {
        super.onLivingUpdate();
        // Base morph synchronisation may resize the hitbox on clients.
        if (width < 2.6F || height < 2.99F) setSize(2.65F, 3.0F);
        if (worldObj.isRemote || !isEntityAlive()) return;
        // Heavy footsteps are audible only while the boss is actually walking.
        // A single periodic check replaces collision/block scans every tick.
        double speedSq = motionX * motionX + motionZ * motionZ;
        if (BroodConfig.sovereignFootsteps &&
            BroodFootstepRules.shouldStomp(ticksExisted, onGround, speedSq)) {
            worldObj.playSoundAtEntity(this, "endlessbrood:sovereign_stomp",
                1.45F, 0.82F + rand.nextFloat() * 0.06F);
        }
        if (ticksExisted == 1 || ticksExisted % 200 == 0) applyBossFloor(false);
        if (ticksExisted == 20) worldObj.playSoundAtEntity(this, "endlessbrood:roar", 2.0F, 0.55F);
        // One regeneration pass per 5 seconds, capped, never invulnerable to HBM.
        if (ticksExisted % 100 == 0 && getHealth() < getMaxHealth()) {
            heal(getHealth() < getMaxHealth() / 3F ? 3F : 2F);
        }
        if (ticksExisted % 160 == 0) {
            rally();
            if (getAttackTarget() != null)
                BroodSwarmCoordinator.alert(this, getAttackTarget());
        }
        // Health phase makes the battle evolve without spawning more entities.
        if (ticksExisted % 120 == 0 && getHealth() < getMaxHealth() * 0.67F)
            shockwave();
    }
    @SuppressWarnings("unchecked")
    private void shockwave() {
        worldObj.playSoundAtEntity(this, "endlessbrood:roar", 1.8F, 0.65F);
        List<EntityPlayer> near = worldObj.getEntitiesWithinAABB(EntityPlayer.class,
            boundingBox.expand(6D, 3D, 6D));
        for (EntityPlayer p : near) {
            if (p.capabilities.isCreativeMode || !p.isEntityAlive() ||
                getDistanceSqToEntity(p) > 49D) continue;
            p.addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, 90, 0));
            if (getHealth() < getMaxHealth()/3F)
                p.addPotionEffect(new PotionEffect(Potion.weakness.id, 90, 0));
            // Stomp is NOT a block-destroying explosion. Damage respects armor.
            p.attackEntityFrom(DamageSource.causeMobDamage(this), 4F);
            double dx = p.posX - posX, dz = p.posZ - posZ;
            double len = Math.max(1D, Math.sqrt(dx*dx+dz*dz));
            p.addVelocity(dx/len*0.55D, 0.18D, dz/len*0.55D);
        }
    }
    @SuppressWarnings("unchecked")
    private void rally() {
        List<EntityParasite> near = worldObj.getEntitiesWithinAABB(EntityParasite.class,
            boundingBox.expand(16D, 7D, 16D));
        int boosted = 0;
        for (EntityParasite member : near) {
            if (member == this || !member.isEntityAlive()) continue;
            member.addPotionEffect(new PotionEffect(Potion.damageBoost.id, 120, 0));
            if (++boosted >= 6) break; // Never summon infinite helper entities
        }
    }
    @Override protected void dropFewItems(boolean recent, int looting) {
        super.dropFewItems(recent, looting);
        if (recent && EndlessBrood.broodCore != null)
            BroodLootDrops.roll(this, EndlessBrood.broodCore, 3);
        // Unique guarantee: every four boss kills grant the 4 different seals.
        // Never apply the 1/5 ordinary loot penalty to this progression key.
        if (!worldObj.isRemote && EndlessBrood.abyssFragment != null &&
            !(this instanceof EntityBroodAbyssOverlord)) {
            net.minecraft.world.World progressWorld=net.minecraftforge.common.DimensionManager.getWorld(0);
            int seal = BroodTrophyData.get(progressWorld!=null?progressWorld:worldObj).nextFragment();
            entityDropItem(new net.minecraft.item.ItemStack(EndlessBrood.abyssFragment,1,seal),0.0F);
        }
    }
    @Override public void writeEntityToNBT(NBTTagCompound tag) {
        super.writeEntityToNBT(tag);
        tag.setInteger("EndlessBroodWaveLevel", waveLevel);
    }
    @Override public void readEntityFromNBT(NBTTagCompound tag) {
        super.readEntityFromNBT(tag);
        waveLevel = Math.max(5, tag.getInteger("EndlessBroodWaveLevel"));
        setSize(2.65F, 3.0F);
        // Attributes are loaded by vanilla and may be rebalanced on next tick.
    }
}
