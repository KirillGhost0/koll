# 1.3.7 — MUTATION & CONSISTENCY PASS
- Visible transformations at **every 10 global evolution stages**: persistent server-synced tier for ground and air castes.
- Evolving skeletal appendages and progressively corrupted/horror-themed textures (70 new PNGs), with cosmetic alternation at arbitrarily large stages.
- Modest bounded growth for ordinary/elite parasites (<= 12%), but boss collision geometry remains constant.
- Fixed repeating elite HP/damage multiplier stacking and Skyreaper HP compounding. Preserve real current health when reapplying caste multipliers.
- Fixed subtype collision sizes being overwritten by generic morph configuration.
- One-time migration of legacy 300-point configs to new 100-point default without overwriting custom costs other than the historical 300 default.
- Improved stub-based verification and included a full Russian consistency audit.
- Gameplay balancing and fortress-generation limitations remain explicitly documented pending real Forge + HBM testing.
