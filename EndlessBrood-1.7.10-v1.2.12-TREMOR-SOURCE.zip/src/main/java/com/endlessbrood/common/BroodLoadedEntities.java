package com.endlessbrood.common;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;

/** Entity scan limited to chunks that were already loaded by the game. */
public final class BroodLoadedEntities {
    private BroodLoadedEntities() { }
    @SuppressWarnings({"unchecked", "rawtypes"})
    public static <T extends Entity> List<T> find(World world, Class<T> type, AxisAlignedBB area) {
        List<T> found = new ArrayList<T>();
        int minCx = MathHelper.floor_double(area.minX) >> 4;
        int maxCx = MathHelper.floor_double(area.maxX) >> 4;
        int minCz = MathHelper.floor_double(area.minZ) >> 4;
        int maxCz = MathHelper.floor_double(area.maxZ) >> 4;
        for (int cx = minCx; cx <= maxCx; ++cx) {
            for (int cz = minCz; cz <= maxCz; ++cz) {
                if (!world.getChunkProvider().chunkExists(cx, cz)) continue;
                Chunk chunk = world.getChunkFromChunkCoords(cx, cz);
                chunk.getEntitiesOfTypeWithinAAAB(type, area, found, null);
            }
        }
        return found;
    }
}
