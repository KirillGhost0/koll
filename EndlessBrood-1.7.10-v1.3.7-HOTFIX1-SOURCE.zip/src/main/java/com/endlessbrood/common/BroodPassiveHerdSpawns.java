package com.endlessbrood.common;

import cpw.mods.fml.common.eventhandler.Event;
import cpw.mods.fml.common.eventhandler.EventPriority;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import java.util.List;
import net.minecraft.entity.passive.EntityChicken;
import net.minecraft.entity.passive.EntityCow;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.living.LivingSpawnEvent;

/**
 * Infect vanilla passive NATURAL spawn packs on world days 20..29 and replace
 * those packs starting day 30. CheckSpawn/SpecialSpawn do not fire for breeding
 * or item spawn eggs. Actual replacement entities are deferred to the world
 * tick, never spawned recursively inside a Forge spawn event.
 */
public final class BroodPassiveHerdSpawns {
    private static final int MAX_QUEUE = 48;
    private final Map<World, State> states = new WeakHashMap<World, State>();

    private static final class Request {
        final int x, y, z;
        Request(int xx, int yy, int zz) { x = xx; y = yy; z = zz; }
    }
    private static final class State {
        final ArrayDeque<Request> queue = new ArrayDeque<Request>();
        final HashMap<Long, Long> herdCooldown = new HashMap<Long, Long>();
    }

    private State state(World world) {
        State result = states.get(world);
        if (result == null) { result = new State(); states.put(world, result); }
        return result;
    }

    private static boolean validWorld(World world) {
        return world != null && !world.isRemote && world.provider.dimensionId == 0 &&
            world.difficultySetting != EnumDifficulty.PEACEFUL &&
            world.getGameRules().getGameRuleBooleanValue("doMobSpawning") &&
            BroodConfig.naturalHerdInfection && !BroodVictoryData.isDefeated(world);
    }

    /** Scope replacement to vanilla livestock rather than modded tameable pets / HBM entities. */
    private static boolean passiveHerd(Entity entity) {
        return entity instanceof EntityCow || entity instanceof EntitySheep ||
            entity instanceof EntityPig || entity instanceof EntityChicken ||
            entity instanceof EntityHorse;
    }

    private static long cell(int x, int z) {
        return ((long)(x >> 5) << 32) ^ ((z >> 5) & 0xffffffffL);
    }

    /** Only one companion per natural herd cluster. No unlimited entries per biome. */
    private boolean request(World world, float px, float py, float pz,
                            int cooldown, int amount) {
        int x = MathHelper.floor_double(px);
        int y = MathHelper.floor_double(py);
        int z = MathHelper.floor_double(pz);
        if (!world.blockExists(x, y, z) || y < 2 || y > 245 ||
            BroodWardRules.protects(world, x, y, z)) return false;
        State state = state(world);
        long time = world.getTotalWorldTime();
        Long last = state.herdCooldown.get(cell(x,z));
        if (last != null && time - last.longValue() < cooldown && time >= last.longValue()) return false;
        if (state.queue.size() + amount > MAX_QUEUE) return false;
        state.herdCooldown.put(cell(x,z), time);
        for (int i = 0; i < amount; i++) state.queue.addLast(new Request(x, y, z));
        if (state.herdCooldown.size() > 512) state.herdCooldown.clear();
        return true;
    }

    /** From day 30 replace NATURAL animal attempts, not bred animals or spawn eggs. */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onCheckSpawn(LivingSpawnEvent.CheckSpawn event) {
        if (!validWorld(event.world) || !passiveHerd(event.entityLiving) ||
            event.getResult() == Event.Result.DENY) return;
        long day = BroodCalendarRules.day(event.world.getWorldTime());
        if (!BroodCalendarRules.replaceHerd(day, BroodConfig.herdReplaceStartDay)) return;
        // Even if the local cap is reached the animal's NATURAL spawn is suppressed
        // after day 30. Eggs, breeding and old animals are not removed.
        event.setResult(Event.Result.DENY);
        request(event.world, event.x, event.y, event.z, 20,
            2 + event.world.rand.nextInt(2));
    }

    /** One infiltrator per natural herd from day 20 through day 29. */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onSpecialSpawn(LivingSpawnEvent.SpecialSpawn event) {
        if (!validWorld(event.world) || event.isCanceled() ||
            !passiveHerd(event.entityLiving)) return;
        long day = BroodCalendarRules.day(event.world.getWorldTime());
        if (!BroodCalendarRules.mixHerd(day, BroodConfig.herdMixStartDay,
            BroodConfig.herdReplaceStartDay) ||
            event.world.rand.nextInt(100) >= BroodConfig.herdCompanionPercent) return;
        request(event.world, event.x, event.y, event.z, 200, 1);
    }

    @SubscribeEvent
    public void onWorldTick(TickEvent.WorldTickEvent event) {
        World world = event.world;
        if (event.phase != TickEvent.Phase.END || world.isRemote ||
            world.provider.dimensionId != 0) return;
        if (!validWorld(world)) {
            State invalid = states.get(world);
            if (invalid != null) invalid.queue.clear();
            return;
        }
        // Vanilla passive spawning is rare in explored worlds. During days
        // 20..29, periodically infect one already-existing livestock herd too.
        // One scan/40 seconds, up to two active players, entirely loaded area.
        long day = BroodCalendarRules.day(world.getWorldTime());
        if (BroodCalendarRules.mixHerd(day, BroodConfig.herdMixStartDay,
                BroodConfig.herdReplaceStartDay) &&
            world.getTotalWorldTime() % 800L == 0L) {
            int searched = 0;
            for (Object object : world.playerEntities) {
                if (!(object instanceof EntityPlayer) || searched++ >= 2) break;
                EntityPlayer player = (EntityPlayer)object;
                List<EntityAnimal> animals = world.getEntitiesWithinAABB(EntityAnimal.class,
                    player.boundingBox.expand(64D, 18D, 64D));
                if (animals.size() < 2) continue;
                for (EntityAnimal animal : animals) {
                    if (!passiveHerd(animal)) continue;
                    // A pair within 12 blocks indicates a herd, rather than a
                    // single named pet. Existing domestic animals are not removed.
                    boolean paired = false;
                    for (EntityAnimal other : animals) {
                        if (animal != other && passiveHerd(other) &&
                            animal.getDistanceSqToEntity(other) < 144D) { paired = true; break; }
                    }
                    if (paired && request(world, (float)animal.posX, (float)animal.posY,
                            (float)animal.posZ, 2400, 1)) break;
                }
            }
        }
        State state = states.get(world);
        if (state == null || state.queue.isEmpty()) return;
        // Bounded work; persistent pressure, but no spawning during Forge hooks
        // and no new chunk generation or path calculation in this ticker.
        for (int n = 0; n < 3 && !state.queue.isEmpty(); n++) {
            Request request = state.queue.removeFirst();
            if (!world.blockExists(request.x, request.y, request.z)) continue;
            if (BroodWardRules.protects(world, request.x, request.y, request.z) ||
                BroodRadiationBridge.getRadiation(world, request.x, request.y, request.z) >=
                    BroodConfig.radiationFearThreshold) continue;
            AxisAlignedBB around = AxisAlignedBB.getBoundingBox(request.x-32, request.y-16, request.z-32,
                request.x+33, request.y+17, request.z+33);
            int count = BroodLoadedEntities.find(world, EntityParasite.class, around).size() +
                BroodLoadedEntities.find(world, EntityBroodFlier.class, around).size();
            if (count >= BroodConfig.herdLocalCap) continue;
            for (int tries = 0; tries < 6; tries++) {
                int x = request.x + world.rand.nextInt(7) - 3;
                int z = request.z + world.rand.nextInt(7) - 3;
                int y = request.y + world.rand.nextInt(3) - 1;
                if (y < 2 || y >= 245 || !world.blockExists(x, y + 2, z) ||
                    !world.getBlock(x, y-1, z).getMaterial().isSolid() ||
                    !world.isAirBlock(x, y, z) || !world.isAirBlock(x,y+1,z) ||
                    BroodWardRules.protects(world,x,y,z)) continue;
                EntityParasite parasite = new EntityParasite(world);
                parasite.setPosition(x + 0.5D, y, z + 0.5D);
                if (world.checkNoEntityCollision(parasite.boundingBox) &&
                    world.getCollidingBoundingBoxes(parasite, parasite.boundingBox).isEmpty()) {
                    world.spawnEntityInWorld(parasite);
                    break;
                }
            }
        }
    }
}
