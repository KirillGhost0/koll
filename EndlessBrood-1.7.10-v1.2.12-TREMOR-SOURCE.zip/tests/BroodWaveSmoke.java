package test;
import com.endlessbrood.common.BroodWaveRules;
public final class BroodWaveSmoke {
  public static void main(String[] args) {
    if (BroodWaveRules.intervalTicks(15) != 360000L) throw new AssertionError("15 days");
    if (BroodWaveRules.packSize(1, 24) != 12) throw new AssertionError("first wave");
    if (BroodWaveRules.packSize(200, 24) != 24) throw new AssertionError("cap");
    if (BroodWaveRules.flyersUnlocked(1, 4, 15)) throw new AssertionError("early flyers");
    if (!BroodWaveRules.flyersUnlocked(3, 1, 15)) throw new AssertionError("third wave flyers");
    if (!BroodWaveRules.flyersUnlocked(1, 15, 15)) throw new AssertionError("evolution");
    if (BroodWaveRules.bossHealth(9000) > 840) throw new AssertionError("boss ceiling");
    System.out.println("OK: 15-day waves, caps, flyers, boss scaling");
  }
}
