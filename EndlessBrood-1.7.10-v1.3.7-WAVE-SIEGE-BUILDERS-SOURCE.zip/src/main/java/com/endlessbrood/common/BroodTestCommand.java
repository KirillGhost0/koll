package com.endlessbrood.common;

import java.math.BigInteger;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.ChatComponentText;
import net.minecraft.world.World;

/** Controlled operator tests: NOT enabled for players in ordinary survival. */
public final class BroodTestCommand extends CommandBase {
    @Override public String getCommandName() { return "broodtest"; }
    @Override public String getCommandUsage(ICommandSender sender) {
        return "/broodtest days <0-1000> | stage <0-999999999999999999> | fortress";
    }
    @Override public int getRequiredPermissionLevel() { return 2; }

    @Override
    public void processCommand(ICommandSender sender, String[] args) {
        if (args.length == 1 && "fortress".equalsIgnoreCase(args[0])) {
            sender.addChatMessage(new ChatComponentText(
                "[Endless Brood] Fortress: dimension " + BroodRealmTravel.dimensionId +
                ", X=" + BroodRealmRules.FORT_X +
                ", Z=" + BroodRealmRules.FORT_Z +
                ". Follow glowing waymarks from the portal: east, then south."));
            return;
        }
        if (args.length != 2) {
            sender.addChatMessage(new ChatComponentText(getCommandUsage(sender)));
            return;
        }
        World world = sender.getEntityWorld();
        if (world.provider.dimensionId != 0) {
            sender.addChatMessage(new ChatComponentText("[Endless Brood] Test only in the Overworld."));
            return;
        }
        if (BroodVictoryData.isDefeated(world)) {
            sender.addChatMessage(new ChatComponentText("[Endless Brood] Рой уничтожен. Эволюция остановлена."));
            return;
        }
        try {
            if ("days".equalsIgnoreCase(args[0])) {
                int days = Integer.parseInt(args[1]);
                if (days < 0 || days > 1000) throw new IllegalArgumentException("days range");
                BroodOutbreakData data = BroodOutbreakData.get(world);
                data.debugSetDays(world.getTotalWorldTime(), days);
                sender.addChatMessage(new ChatComponentText("[Endless Brood] Virtual outbreak age: " +
                    data.elapsedTicks(world.getTotalWorldTime()) / 24000L +
                    " days. Scout patrols appear on their next periodic tick in loaded chunks."));
            } else if ("stage".equalsIgnoreCase(args[0])) {
                if (args[1].length() > 18) throw new IllegalArgumentException("stage too large");
                BigInteger stage = new BigInteger(args[1]);
                if (stage.signum() < 0) throw new IllegalArgumentException("negative stage");
                EvolutionData.get(world).debugSetStage(stage);
                sender.addChatMessage(new ChatComponentText("[Endless Brood] Test stage: " + stage));
            } else sender.addChatMessage(new ChatComponentText(getCommandUsage(sender)));
        } catch (NumberFormatException error) {
            sender.addChatMessage(new ChatComponentText("[Endless Brood] Invalid number."));
        } catch (IllegalArgumentException error) {
            sender.addChatMessage(new ChatComponentText("[Endless Brood] " + error.getMessage()));
        }
    }
}
