package com.endlessbrood.common;

import java.util.WeakHashMap;
import net.minecraft.world.World;

/** Main-thread, dimension-local terrain edits throttled separately from pathfinding. */
public final class BroodDigBudget {
    private static final WeakHashMap<World, State> STATES = new WeakHashMap<World, State>();
    private BroodDigBudget() { }
    public static boolean tryBreak(World world) {
        State s = STATES.get(world);
        if (s == null) { s = new State(); STATES.put(world, s); }
        long tick = world.getTotalWorldTime();
        if (s.lastTick == Long.MIN_VALUE || tick < s.lastTick || tick - s.lastTick >= 5L) {
            s.lastTick = tick;
            return true;
        }
        return false;
    }
    private static final class State { long lastTick = Long.MIN_VALUE; }
}
