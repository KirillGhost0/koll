package com.endlessbrood.common;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

/** Fast utility dagger: lower base damage, small chance to apply poison. */
public final class ItemSporeDagger extends ItemSword {
    public ItemSporeDagger(Item.ToolMaterial material) {
        super(material);
        setUnlocalizedName("endlessbrood.sporeDagger");
        setTextureName("endlessbrood:spore_dagger");
        setCreativeTab(CreativeTabs.tabCombat);
    }
    @Override
    public boolean hitEntity(ItemStack stack, EntityLivingBase target, EntityLivingBase attacker) {
        boolean success = super.hitEntity(stack, target, attacker);
        if (!target.worldObj.isRemote && attacker.getRNG().nextInt(4) == 0)
            target.addPotionEffect(new PotionEffect(Potion.poison.id, 80, 0));
        return success;
    }
}
