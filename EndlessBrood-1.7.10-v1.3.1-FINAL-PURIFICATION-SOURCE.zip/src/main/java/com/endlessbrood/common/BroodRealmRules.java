package com.endlessbrood.common;

/** Deterministic, pure rules for the late-game parasitic dimension. */
public final class BroodRealmRules {
    public static final int FORT_X = 384, FORT_Z = 384;
    public static final int ARRIVAL_Y = 125;
    private BroodRealmRules() { }

    public static int fragmentFromKill(int priorBossKills) {
        return Math.floorMod(priorBossKills, 4);
    }

    public static boolean isCorrectCorner(int dx, int dz, int fragment) {
        return (dx == 0 && dz == 0 && fragment == 0)
            || (dx == 3 && dz == 0 && fragment == 1)
            || (dx == 0 && dz == 3 && fragment == 2)
            || (dx == 3 && dz == 3 && fragment == 3);
    }

    /** Height of the solid ground at each integer X/Z; -1 means open void. */
    public static int islandTop(long seed, int x, int z) {
        double spawn = Math.sqrt((double)x * x + (double)z * z);
        double fort = Math.hypot((double)x - FORT_X, (double)z - FORT_Z);
        if (spawn < 35D) return 123 + (int)(2.5D * Math.sin(x*.16D) * Math.cos(z*.12D));
        if (fort < 78D) return 137 + (int)(3.0D * Math.sin(x*.09D) * Math.cos(z*.1D));
        // Narrow elevated infection bridges link spawn with the faraway citadel.
        if (x >= 5 && x <= FORT_X && Math.abs(z) <= 3) return 122;
        if (z >= 0 && z <= FORT_Z && Math.abs(x - FORT_X) <= 3) return 124;
        int cellX = Math.floorDiv(x, 112), cellZ = Math.floorDiv(z, 112);
        long h = mix(seed, cellX, cellZ);
        double cx = cellX * 112D + 56D + ((h >>> 18) & 31) - 15;
        double cz = cellZ * 112D + 56D + ((h >>> 28) & 31) - 15;
        double radius = 39D + ((h >>> 39) & 15);
        double dx = x-cx, dz=z-cz;
        double wobble = 3.0D * Math.sin(x*.13D + (h&7)) * Math.cos(z*.17D);
        if (dx*dx + dz*dz > (radius+wobble)*(radius+wobble)) return -1;
        return 112 + (int)((h >>> 50) & 15) + (int)(2.0D*Math.sin(x*.08D)*Math.sin(z*.07D));
    }

    public static long mix(long seed, int x, int z) {
        long v = seed ^ (x * 341873128712L) ^ (z * 132897987541L);
        v ^= v >>> 33; v *= 0xff51afd7ed558ccdL;
        v ^= v >>> 33; v *= 0xc4ceb9fe1a85ec53L;
        return v ^ (v >>> 33);
    }
}
