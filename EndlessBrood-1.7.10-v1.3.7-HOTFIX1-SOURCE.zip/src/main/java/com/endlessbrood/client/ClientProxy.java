package com.endlessbrood.client;

import com.endlessbrood.common.CommonProxy;
import com.endlessbrood.common.EntityParasite;
import com.endlessbrood.common.EntityBroodFlier;
import com.endlessbrood.common.EntityBroodCommander;
import com.endlessbrood.common.EntityBroodAbyssOverlord;
import com.endlessbrood.common.EntityBroodElite;
import com.endlessbrood.common.EntityBroodSkyreaper;
import cpw.mods.fml.client.registry.RenderingRegistry;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.gameevent.TickEvent;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.Minecraft;
import java.util.concurrent.ConcurrentLinkedQueue;

public class ClientProxy extends CommonProxy {
    private final ConcurrentLinkedQueue<int[]> pending = new ConcurrentLinkedQueue<int[]>();
    @Override public void openSkillGui() {
        Minecraft.getMinecraft().displayGuiScreen(new GuiBroodSkills());
    }
    @Override public void acceptSkillSnapshot(int level, int xp, int next, int points, int[] ranks) {
        int[] update = new int[4 + ranks.length];
        update[0] = level; update[1] = xp; update[2] = next; update[3] = points;
        System.arraycopy(ranks, 0, update, 4, ranks.length);
        pending.offer(update);
    }
    @SubscribeEvent public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        int[] update;
        while ((update = pending.poll()) != null) {
            if (Minecraft.getMinecraft().currentScreen instanceof GuiBroodSkills) {
                int[] ranks = new int[update.length - 4];
                System.arraycopy(update, 4, ranks, 0, ranks.length);
                ((GuiBroodSkills)Minecraft.getMinecraft().currentScreen).apply(
                    update[0], update[1], update[2], update[3], ranks);
            }
        }
    }
    @Override
    public void registerRenderers() {
        FMLCommonHandler.instance().bus().register(new BroodCameraShake());
        FMLCommonHandler.instance().bus().register(this);
        RenderingRegistry.registerEntityRenderingHandler(EntityParasite.class, new RenderParasite());
        RenderingRegistry.registerEntityRenderingHandler(EntityBroodFlier.class, new RenderBroodFlier());
        RenderingRegistry.registerEntityRenderingHandler(EntityBroodCommander.class, new RenderBroodCommander());
        RenderingRegistry.registerEntityRenderingHandler(EntityBroodAbyssOverlord.class, new RenderBroodAbyssOverlord());
        RenderingRegistry.registerEntityRenderingHandler(EntityBroodElite.Ravager.class, new RenderBroodElite());
        RenderingRegistry.registerEntityRenderingHandler(EntityBroodElite.Sporecaller.class, new RenderBroodElite());
        RenderingRegistry.registerEntityRenderingHandler(EntityBroodElite.Ironmaw.class, new RenderBroodElite());
        RenderingRegistry.registerEntityRenderingHandler(EntityBroodSkyreaper.class, new RenderBroodSkyreaper());
        RenderingRegistry.registerEntityRenderingHandler(EntityBroodElite.Overmind.class, new RenderBroodElite());
    }
}
