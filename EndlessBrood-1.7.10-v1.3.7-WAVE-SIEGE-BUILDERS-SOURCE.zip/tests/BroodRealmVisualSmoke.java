package test;

import com.endlessbrood.client.ModelBroodDreadSovereign;
import com.endlessbrood.common.BroodRealmRules;
import java.lang.reflect.Field;
import net.minecraft.client.model.ModelRenderer;

/** Rendering geometry assumptions (Forge 1.7.10's model floor is Y=24). */
public final class BroodRealmVisualSmoke {
    public static void main(String[] args) throws Exception {
        ModelBroodDreadSovereign boss = new ModelBroodDreadSovereign();
        Field l = ModelBroodDreadSovereign.class.getDeclaredField("leftLeg");
        Field r = ModelBroodDreadSovereign.class.getDeclaredField("rightLeg");
        l.setAccessible(true); r.setAccessible(true);
        ModelRenderer left = (ModelRenderer)l.get(boss);
        ModelRenderer right = (ModelRenderer)r.get(boss);
        // Original pivots were -19; their attached foot boxes end 19px below.
        // +24 root shift brings the foot contact plane to the same world floor
        // that the entity collision box uses (24 model pixels below the origin).
        assert left.rotationPointY == 5F;
        assert right.rotationPointY == 5F;
        assert BroodRealmRules.islandThickness(8L,0,0)>=10;
        assert BroodRealmRules.islandThickness(8L,384,384)==24;
        assert BroodRealmRules.isPathBeacon(64,0);
        assert BroodRealmRules.isPathBeacon(384,64);
        assert !BroodRealmRules.isPathBeacon(65,0);
        for(int x=-200;x<=600;x+=11) for(int z=-200;z<=600;z+=13) {
            int top = BroodRealmRules.islandTop(57L,x,z);
            if(top>=0) {
                int thick=BroodRealmRules.islandThickness(57L,x,z);
                assert thick>=4 && thick<=40;
                assert top-thick>0;
            }
        }
        System.out.println("PASS: grounded sovereign feet, smooth island bodies, skybridge markers");
    }
}
