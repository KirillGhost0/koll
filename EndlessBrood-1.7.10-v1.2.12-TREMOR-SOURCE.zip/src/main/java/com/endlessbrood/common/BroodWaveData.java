package com.endlessbrood.common;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraft.world.WorldSavedData;

/** World-owned invasion clock. Time-set commands cannot skip real played ticks. */
public final class BroodWaveData extends WorldSavedData {
    private static final String ID = "endlessbrood_invasion_waves";
    public long playedTicks;
    public int waveIndex;
    public int waveTicksLeft;
    public int spawned;
    public boolean bossSpawned;
    public boolean warned;
    public boolean debugWave;
    public int failedPlacement, blockedByCap, noTargets;
    public int plannedTotal, spawnedRegular;
    public int[] eliteQuotas = new int[BroodEliteWaveRules.CASTES];
    public int[] eliteSpawned = new int[BroodEliteWaveRules.CASTES];

    public BroodWaveData() { super(ID); }
    public BroodWaveData(String name) { super(name); }
    public static BroodWaveData get(World world) {
        BroodWaveData data = (BroodWaveData) world.loadItemData(BroodWaveData.class, ID);
        if (data == null) {
            data = new BroodWaveData(ID);
            world.setItemData(ID, data);
        }
        return data;
    }
    @Override
    public void readFromNBT(NBTTagCompound tag) {
        playedTicks = Math.max(0L, tag.getLong("PlayedTicks"));
        waveIndex = Math.max(0, tag.getInteger("WaveIndex"));
        waveTicksLeft = Math.max(0, tag.getInteger("WaveTicksLeft"));
        spawned = Math.max(0, tag.getInteger("Spawned"));
        bossSpawned = tag.getBoolean("BossSpawned");
        warned = tag.getBoolean("Warned");
        debugWave = tag.getBoolean("DebugWave");
        failedPlacement = Math.max(0, tag.getInteger("FailedPlacement"));
        blockedByCap = Math.max(0, tag.getInteger("BlockedByCap"));
        noTargets = Math.max(0, tag.getInteger("NoTargets"));
        plannedTotal = Math.max(0, tag.getInteger("PlannedTotal"));
        spawnedRegular = Math.max(0, tag.getInteger("SpawnedRegular"));
        int[] q = tag.getIntArray("EliteQuotas");
        int[] n = tag.getIntArray("EliteSpawned");
        if (q.length == BroodEliteWaveRules.CASTES) eliteQuotas = q;
        if (n.length == BroodEliteWaveRules.CASTES) eliteSpawned = n;
    }
    @Override
    public void writeToNBT(NBTTagCompound tag) {
        tag.setLong("PlayedTicks", playedTicks);
        tag.setInteger("WaveIndex", waveIndex);
        tag.setInteger("WaveTicksLeft", waveTicksLeft);
        tag.setInteger("Spawned", spawned);
        tag.setBoolean("BossSpawned", bossSpawned);
        tag.setBoolean("Warned", warned);
        tag.setBoolean("DebugWave", debugWave);
        tag.setInteger("FailedPlacement", failedPlacement);
        tag.setInteger("BlockedByCap", blockedByCap);
        tag.setInteger("NoTargets", noTargets);
        tag.setInteger("PlannedTotal", plannedTotal);
        tag.setInteger("SpawnedRegular", spawnedRegular);
        tag.setIntArray("EliteQuotas", eliteQuotas);
        tag.setIntArray("EliteSpawned", eliteSpawned);
    }
}
