package com.endlessbrood.client;

import com.endlessbrood.common.EntityBroodFlier;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;

public final class RenderBroodFlier extends RenderLiving {
    private static final ResourceLocation TEXTURE = new ResourceLocation("endlessbrood", "textures/entity/flier.png");
    public RenderBroodFlier() { super(new ModelBroodFlier(), 0.45F); }
    @Override protected ResourceLocation getEntityTexture(Entity entity) { return TEXTURE; }
}
