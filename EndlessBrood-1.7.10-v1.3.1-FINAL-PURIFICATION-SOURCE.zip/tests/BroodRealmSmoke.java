package test;

import com.endlessbrood.common.BroodRealmRules;

public final class BroodRealmSmoke {
    public static void main(String[] args) {
        for(int i=0;i<16;i++) {
            assert BroodRealmRules.fragmentFromKill(i)==i%4;
        }
        int[][] corners={{0,0,0},{3,0,1},{0,3,2},{3,3,3}};
        for(int[] corner:corners) for(int i=0;i<4;i++)
            assert BroodRealmRules.isCorrectCorner(corner[0],corner[1],i)==(corner[2]==i);
        assert BroodRealmRules.islandTop(12345L,0,0)>120;
        assert BroodRealmRules.islandTop(12345L,384,384)>130;
        assert BroodRealmRules.islandTop(12345L,150,0)>0;
        assert BroodRealmRules.islandTop(12345L,384,200)>0;
        for(int x=-200;x<=800;x+=13) for(int z=-200;z<=800;z+=11) {
            int y=BroodRealmRules.islandTop(12345L,x,z);
            assert y<200 && y>=-1;
            assert y==BroodRealmRules.islandTop(12345L,x,z);
        }
        System.out.println("PASS: 4 unique guaranteed seals, 4-corner pattern, islands, traversable bridges, fixed citadel, deterministic terrain");
    }
}
