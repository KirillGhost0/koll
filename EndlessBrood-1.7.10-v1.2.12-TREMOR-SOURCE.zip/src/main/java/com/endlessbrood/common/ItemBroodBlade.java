package com.endlessbrood.common;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemSword;
import net.minecraft.item.Item;

public final class ItemBroodBlade extends ItemSword {
    public ItemBroodBlade(Item.ToolMaterial material) {
        super(material);
        setUnlocalizedName("endlessbrood.broodBlade");
        setTextureName("endlessbrood:brood_blade");
        setCreativeTab(CreativeTabs.tabCombat);
    }
}
