package com.endlessbrood.common;

import java.util.List;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.world.World;

/** Local rally, not a global registry. Never loads chunks or spawns extra mobs.
 * Signals at most a small number of existing ground and air creatures.
 */
public final class BroodSwarmCoordinator {
    private BroodSwarmCoordinator() { }

    public static void alert(EntityParasite caller, EntityLivingBase victim) {
        if (!BroodConfig.swarmTacticsEnabled || caller.worldObj.isRemote ||
            !caller.isEntityAlive() || victim == null || !victim.isEntityAlive() ||
            victim.worldObj != caller.worldObj ||
            victim instanceof EntityParasite || victim instanceof EntityBroodFlier || victim instanceof EntityBroodBuilder ||
            victim instanceof EntityPlayer && ((EntityPlayer) victim).capabilities.isCreativeMode)
            return;
        World world = caller.worldObj;
        double r = BroodConfig.swarmSignalRadius;
        AxisAlignedBB area = caller.boundingBox.expand(r, 9D, r);
        int budget = BroodConfig.swarmMaxFollowers;
        List<EntityParasite> ground = BroodLoadedEntities.find(world, EntityParasite.class, area);
        for (EntityParasite member : ground) {
            if (budget == 0) break;
            if (member == caller || !member.isEntityAlive() ||
                caller.getDistanceSqToEntity(member) > r * r) continue;
            if (member.acceptSwarmTarget(victim)) --budget;
        }
        if (budget == 0) return;
        List<EntityBroodFlier> air = BroodLoadedEntities.find(world, EntityBroodFlier.class, area);
        for (EntityBroodFlier flyer : air) {
            if (budget == 0) break;
            if (!flyer.isEntityAlive() || caller.getDistanceSqToEntity(flyer) > r * r) continue;
            if (flyer.acceptSwarmTarget(victim)) --budget;
        }
    }
}
