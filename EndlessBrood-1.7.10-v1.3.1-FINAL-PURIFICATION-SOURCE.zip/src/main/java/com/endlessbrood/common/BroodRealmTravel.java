package com.endlessbrood.common;

import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.Teleporter;
import net.minecraft.world.WorldServer;
import net.minecraftforge.common.DimensionManager;
import net.minecraft.entity.Entity;

/** Server-only safe teleportation; honors installed-mod dimension-ID collisions. */
public final class BroodRealmTravel {
    public static int dimensionId=74;
    public static boolean realmAvailable=false;
    private BroodRealmTravel() { }
    public static void register(int id) {
        dimensionId=id;
        if (DimensionManager.isDimensionRegistered(id)) {
            System.err.println("[Endless Brood] Dimension "+id+" already used. Set abyssDimensionId in config; realm disabled.");
            realmAvailable=false;
            return;
        }
        if(!DimensionManager.registerProviderType(id,WorldProviderBrood.class,false)) {
            System.err.println("[Endless Brood] Failed to register provider type "+id);
            realmAvailable=false;
            return;
        }
        DimensionManager.registerDimension(id,id);
        realmAvailable=true;
    }
    public static void travel(EntityPlayerMP player) {
        if(!realmAvailable || player.timeUntilPortal>0 || player.ridingEntity!=null) return;
        int destination;
        double x,y,z;
        NBTTagCompound nbt=player.getEntityData();
        if(player.dimension==0) {
            nbt.setDouble("EndlessBroodReturnX",player.posX);
            nbt.setDouble("EndlessBroodReturnY",player.posY);
            nbt.setDouble("EndlessBroodReturnZ",player.posZ);
            destination=dimensionId;
            x=3.5D; y=BroodRealmRules.ARRIVAL_Y + 1D; z=0.5D;
        } else if(player.dimension==dimensionId) {
            destination=0;
            x=nbt.hasKey("EndlessBroodReturnX")?nbt.getDouble("EndlessBroodReturnX")+2.5D:player.mcServer.worldServerForDimension(0).getSpawnPoint().posX+0.5D;
            y=nbt.hasKey("EndlessBroodReturnY")?nbt.getDouble("EndlessBroodReturnY")+1D:85D;
            z=nbt.hasKey("EndlessBroodReturnZ")?nbt.getDouble("EndlessBroodReturnZ"):player.mcServer.worldServerForDimension(0).getSpawnPoint().posZ+0.5D;
        } else return;
        MinecraftServer server=player.mcServer;
        WorldServer target=DimensionManager.getWorld(destination);
        if(target==null) {
            DimensionManager.initDimension(destination);
            target=DimensionManager.getWorld(destination);
        }
        if(target==null) return;
        player.timeUntilPortal=120;
        // Place the player at a safe lit platform, not in an ungenerated void chunk.
        if(destination==dimensionId) {
            target.getBlock(0, 120, 0); // ensure arrival chunk is generated
            for(int xx=0;xx<6;xx++) for(int zz=-2;zz<=3;zz++)
                target.setBlock(xx,BroodRealmRules.ARRIVAL_Y-1,zz,Blocks.obsidian,0,2);
            target.setBlock(1,BroodRealmRules.ARRIVAL_Y,1,com.endlessbrood.EndlessBrood.abyssPortal,0,2);
        }
        server.getConfigurationManager().transferPlayerToDimension(player,destination,
            new BroodTeleporter(target,x,y,z));
        player.timeUntilPortal=120;
        player.fallDistance=0F;
    }
    private static final class BroodTeleporter extends Teleporter {
        private final double x,y,z;
        BroodTeleporter(WorldServer world,double x,double y,double z) { super(world); this.x=x;this.y=y;this.z=z; }
        @Override public void placeInPortal(Entity entity,double fromX,double fromY,double fromZ,float yaw) {
            entity.setLocationAndAngles(x,y,z,yaw,entity.rotationPitch);
            entity.motionX=entity.motionY=entity.motionZ=0D;
            entity.fallDistance=0F;
        }
        @Override public boolean placeInExistingPortal(Entity entity,double x,double y,double z,float yaw) { return false; }
        @Override public boolean makePortal(Entity entity) { return true; }
    }
}
