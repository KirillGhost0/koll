package com.endlessbrood.common;

/** Bounded geometry for a walkable siege stair and horizontal access bridge.
 * A 5x5 perimeter avoids stacking blocks above a creature's head every lap.
 */
public final class BroodSiegeBuilderRules {
    public static final int BUILDERS_PER_WAVE = 2;
    public static final int MAX_HEIGHT = 160;
    public static final int MAX_BRIDGE = 16;
    public static final int MAX_BLOCKS = MAX_HEIGHT * 2 + MAX_BRIDGE + 1;
    private BroodSiegeBuilderRules() { }

    /** Horizontal coordinates of the next 1-block ascending stair on a 5x5 loop. */
    public static int stairX(int step) {
        int i = step & 15;
        if (i <= 4) return -2 + i;
        if (i <= 8) return 2;
        if (i <= 12) return 2 - (i - 8);
        return -2;
    }
    public static int stairZ(int step) {
        int i = step & 15;
        if (i <= 4) return -2;
        if (i <= 8) return -2 + (i - 4);
        if (i <= 12) return 2;
        return 2 - (i - 12);
    }
    public static int stepsToTarget(int groundY, int targetFloorY) {
        return Math.max(0, Math.min(MAX_HEIGHT, targetFloorY - groundY));
    }
    public static boolean canStart(int groundY, int targetFloorY) {
        return groundY >= 2 && groundY <= 247 && targetFloorY > groundY + 3 &&
            targetFloorY <= 249 && targetFloorY - groundY <= MAX_HEIGHT;
    }
    public static boolean canAdd(boolean griefing, boolean terrain, boolean protectedByWard,
                                 boolean loaded, boolean empty, boolean noEntities, int placed) {
        return griefing && terrain && !protectedByWard && loaded && empty &&
            noEntities && placed < MAX_BLOCKS;
    }
}
