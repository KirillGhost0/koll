package com.endlessbrood.common;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ChatComponentText;

/** Server-authoritative persistent co-op progression, independent of vanilla XP. */
public final class BroodSkills {
    public static final String[] KEYS = {"hunter", "carapace", "vigor", "scavenger", "purity"};
    private static final String PERSIST_KEY = "EndlessBroodSkills";
    private BroodSkills() { }
    public static NBTTagCompound get(EntityPlayer player) {
        NBTTagCompound tags = player.getEntityData();
        NBTTagCompound persisted = tags.getCompoundTag(EntityPlayer.PERSISTED_NBT_TAG);
        if (!tags.hasKey(EntityPlayer.PERSISTED_NBT_TAG))
            tags.setTag(EntityPlayer.PERSISTED_NBT_TAG, persisted);
        NBTTagCompound progress = persisted.getCompoundTag(PERSIST_KEY);
        if (!persisted.hasKey(PERSIST_KEY)) persisted.setTag(PERSIST_KEY, progress);
        return progress;
    }
    public static int level(NBTTagCompound data) { return Math.max(0, data.getInteger("level")); }
    public static int points(NBTTagCompound data) { return Math.max(0, data.getInteger("points")); }
    public static int rank(NBTTagCompound data, int skill) {
        return skill < 0 || skill >= KEYS.length ? 0 :
            BroodSkillRules.capRank(data.getInteger(KEYS[skill]));
    }
    public static int xpForNext(int atLevel) {
        return BroodSkillRules.nextLevelXp(atLevel);
    }
    public static void grant(EntityPlayer player, int experience) {
        if (player.worldObj.isRemote || experience <= 0) return;
        NBTTagCompound data = get(player);
        int lv = level(data);
        int xp = (int) Math.min(1000000L, (long) Math.max(0, data.getInteger("xp")) + experience);
        int gains = 0;
        while (lv < 10000 && xp >= xpForNext(lv)) {
            xp -= xpForNext(lv);
            lv++;
            gains++;
        }
        data.setInteger("level", lv);
        data.setInteger("xp", xp);
        if (gains > 0) {
            data.setInteger("points", Math.min(10000, points(data) + gains));
            player.addChatMessage(new ChatComponentText("[Endless Brood] Survivor level " + lv +
                ", unspent skill points: " + points(data) + ". Use the Skill Codex."));
        }
    }
    public static boolean upgrade(EntityPlayer player, int selected) {
        NBTTagCompound data = get(player);
        if (points(data) <= 0 || rank(data, selected) >= 10) return false;
        data.setInteger("points", points(data) - 1);
        data.setInteger(KEYS[selected], rank(data, selected) + 1);
        return true;
    }
}
