package com.endlessbrood.common;

import java.util.List;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

/** Four independent elite ground species. All reuse the original bounded ground AI. */
public abstract class EntityBroodElite extends EntityParasite {
    protected EntityBroodElite(World world) { super(world); experienceValue = 14; }
    protected abstract int caste();
    public final void prepareForWave() {
        configureSpawnMorph(caste() == 0 ? 3 : caste() == 1 ? 5 : caste() == 2 ? 4 : 2);
        updateAttributesFromEvolution();
    }
    @Override public void onLivingUpdate() {
        super.onLivingUpdate();
        if (worldObj.isRemote || !isEntityAlive()) return;
        if (ticksExisted == 1 || ticksExisted % 200 == 0) updateAttributesFromEvolution();
        if ((ticksExisted + getEntityId()) % 100 == 0) useCasteAbility();
    }
    @Override protected void updateAttributesFromEvolution() {
        float previousHealth = getHealth();
        double previousMax = getMaxHealth();
        super.updateAttributesFromEvolution(); // reset base before applying caste multiplier
        applyEliteStats(previousHealth, previousMax);
    }
    private void applyEliteStats(float previousHealth, double previousMax) {
        // Multiply the freshly recalculated BASE stats once, never the last elite stats.
        double multiplier = caste()==0 ? 1.7D : caste()==1 ? 2.0D : caste()==2 ? 2.35D : 2.7D;
        double max = Math.min(450D, getEntityAttribute(SharedMonsterAttributes.maxHealth).getBaseValue()*multiplier);
        getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(max);
        getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(
            Math.min(52D, getEntityAttribute(SharedMonsterAttributes.attackDamage).getBaseValue() *
                (caste()==2 ? 1.65D : caste()==0 ? 1.55D : 1.1D)));
        // A periodic rebase must never erase current health or heal damage for free.
        if (previousHealth > 0.0F)
            setHealth((float)Math.min(max, previousHealth + Math.min(40D, Math.max(0D, max - previousMax))));
        if (caste()==2) getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(0.85D);
        if (caste()==0) experienceValue = 14;
        else if (caste()==1) experienceValue = 18;
        else if (caste()==2) experienceValue = 24;
        else experienceValue = 28;
    }
    @SuppressWarnings("unchecked")
    private void useCasteAbility() {
        EntityLivingBase victim=getAttackTarget();
        if (caste()==0 && victim!=null && victim.isEntityAlive() && getDistanceSqToEntity(victim)<16D) {
            // Ravager: a short stagger, not permanent slowness.
            victim.addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, 60, 0));
        } else if (caste()==1) {
            // Sporecaller: one bounded scan each 5 seconds, up to three targets.
            List<EntityLivingBase> nearby=worldObj.getEntitiesWithinAABB(EntityLivingBase.class,
                boundingBox.expand(6D, 3D, 6D));
            int hits=0;
            for (EntityLivingBase enemy: nearby) {
                if (!eligible(enemy)) continue;
                enemy.addPotionEffect(new PotionEffect(Potion.weakness.id, 90, 0));
                if (++hits >= 3) break;
            }
        } else if (caste()==2 && victim!=null && victim.isEntityAlive() &&
                   getDistanceSqToEntity(victim)<12D) {
            // Ironmaw: short knockback. NEVER explodes or breaks protected HBM blocks.
            double dx=victim.posX-posX, dz=victim.posZ-posZ;
            double d=Math.sqrt(dx*dx+dz*dz);
            if (d>0.01D) victim.addVelocity(dx/d*0.44D, 0.12D, dz/d*0.44D);
        } else if (caste()==3) {
            // Overmind: reinforce nearby parasite defenders, no summoned minions.
            List<EntityParasite> nearby=worldObj.getEntitiesWithinAABB(EntityParasite.class,
                boundingBox.expand(10D, 5D, 10D));
            int boosted=0;
            for (EntityParasite ally: nearby) {
                if (ally==this || !ally.isEntityAlive()) continue;
                if (ally.getHealth() < ally.getMaxHealth()) ally.heal(3F);
                ally.addPotionEffect(new PotionEffect(Potion.resistance.id, 100, 0));
                if (++boosted >= 4) break;
            }
        }
    }
    private boolean eligible(EntityLivingBase e) {
        return e!=this && e.isEntityAlive() && !(e instanceof EntityParasite) &&
            !(e instanceof EntityBroodFlier) && !(e instanceof EntityBroodBuilder) &&
            (!(e instanceof EntityPlayer) || !((EntityPlayer)e).capabilities.isCreativeMode);
    }
    public static final class Ravager extends EntityBroodElite {
        public Ravager(World world) { super(world); setSize(1.05F, 1.5F); }
        @Override protected int caste() { return 0; }
    }
    public static final class Sporecaller extends EntityBroodElite {
        public Sporecaller(World world) { super(world); setSize(1.45F, 2.1F); }
        @Override protected int caste() { return 1; }
    }
    public static final class Ironmaw extends EntityBroodElite {
        public Ironmaw(World world) { super(world); setSize(1.9F, 2.5F); }
        @Override protected int caste() { return 2; }
    }
    public static final class Overmind extends EntityBroodElite {
        public Overmind(World world) { super(world); setSize(1.1F, 1.6F); }
        @Override protected int caste() { return 3; }
    }
}
