package test;
import com.endlessbrood.common.BroodSkillRules;
import com.endlessbrood.common.BroodWardLevels;
public final class BroodAdditionsSmoke {
    public static void main(String[] args) {
        if (BroodWardLevels.radius(8, 0) != 8) throw new AssertionError("ward 0");
        if (BroodWardLevels.radius(8, 1) != 14) throw new AssertionError("ward 1");
        if (BroodWardLevels.radius(8, 2) != 22) throw new AssertionError("ward 2");
        if (BroodWardLevels.radius(8, 3) != 32) throw new AssertionError("ward 3");
        if (!BroodWardLevels.accepts(0, 1) || BroodWardLevels.accepts(0, 3) ||
            BroodWardLevels.accepts(3, 3)) throw new AssertionError("sequential upgrades");
        if (BroodSkillRules.nextLevelXp(0) != 20 ||
            BroodSkillRules.nextLevelXp(1) != 32 ||
            BroodSkillRules.nextLevelXp(Integer.MAX_VALUE) != 2020)
            throw new AssertionError("XP cost");
        if (BroodSkillRules.killReward(0) != 6 || BroodSkillRules.killReward(5) != 21)
            throw new AssertionError("kill XP");
        if (BroodSkillRules.capRank(99) != 10 || BroodSkillRules.capRank(-1) != 0)
            throw new AssertionError("skill rank cap");
        System.out.println("OK: skill progression math and 4 ward tiers");
    }
}
