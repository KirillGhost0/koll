package net.minecraft.entity; public class Entity {public int getEntityId(){return 0;} }
