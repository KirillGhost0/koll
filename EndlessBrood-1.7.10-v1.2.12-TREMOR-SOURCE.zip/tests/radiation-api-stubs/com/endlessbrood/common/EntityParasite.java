package com.endlessbrood.common;
import net.minecraft.world.World;
import net.minecraft.util.DamageSource;
public class EntityParasite {
 public World worldObj=new World(); public double posX=0D,posY=64D,posZ=0D;
 public Object target=new Object(); public float damage=0F; public Navigator nav=new Navigator();
 public void setAttackTarget(Object t){target=t;}
 public boolean attackEntityFrom(DamageSource src,float dmg){damage+=dmg;return true;}
 public Navigator getNavigator(){return nav;}
 public static class Navigator { public double x=Double.NaN,y=0,z=0;public void clearPathEntity(){}
   public boolean tryMoveToXYZ(double a,double b,double c,double speed){x=a;y=b;z=c;return true;}}
}
