package com.endlessbrood.common;

import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.ChatComponentText;

/** Read-only, works in survival on a dedicated server without cheats. */
public final class EvolutionCommand extends CommandBase {
    @Override
    public String getCommandName() { return "broodstage"; }

    @Override
    public String getCommandUsage(ICommandSender sender) { return "/broodstage"; }

    @Override
    public int getRequiredPermissionLevel() { return 0; }

    @Override
    public void processCommand(ICommandSender sender, String[] args) {
        EvolutionData data = EvolutionData.get(sender.getEntityWorld());
        sender.addChatMessage(new ChatComponentText(
            "[Endless Brood] Stage: " + data.getStage() +
            " | biomass: " + data.getPoints() +
            " | next stage cost: " + BroodConfig.effectiveEvolutionCost()));
        sender.addChatMessage(new ChatComponentText(
            "[Brood pacing] Combat progress today: " +
            data.getCombatPointsToday(sender.getEntityWorld().getTotalWorldTime()) +
            "/" + BroodConfig.combatPointsPerDay +
            " (passive growth is not capped)."));
        BroodOutbreakData outbreak = BroodOutbreakData.get(sender.getEntityWorld());
        long now = sender.getEntityWorld().getTotalWorldTime();
        sender.addChatMessage(new ChatComponentText(
            "[Outbreak] days since install (including tests): " + (outbreak.elapsedTicks(now) / 24000L) +
            " | grace time remaining: " + (outbreak.remainingGraceTicks(now) / 20L) + " sec" +
            " | current home exclusion radius: " + outbreak.currentHomeRadius(now) + " blocks" +
            " | distant nests seeded: " + outbreak.retroSeedCount()));
        sender.addChatMessage(new ChatComponentText(
            "[Outbreak] Distant nests materialize ONLY in loaded chunks; " +
            "explore outside the current exclusion radius to discover them."));
        if (sender instanceof net.minecraft.entity.player.EntityPlayer) {
            net.minecraft.entity.player.EntityPlayer player =
                (net.minecraft.entity.player.EntityPlayer) sender;
            boolean near = outbreak.naturalSpawnsAllowed(player.worldObj, player.posX, player.posZ);
            sender.addChatMessage(new ChatComponentText(
                "[Brood patrol] near player: " + (near ? "ACTIVE" : "SAFE ZONE") +
                " | patrol interval: " + (BroodConfig.patrolIntervalTicks / 20) + " seconds" +
                " | /time set DOES NOT advance invasion."));
        }
        if (BroodConfig.adaptiveDefense) {
            sender.addChatMessage(new ChatComponentText(
                "[Brood resistance] fire: " + percent(data.getResistance(BroodAdaptiveMath.FIRE)) +
                " / blast: " + percent(data.getResistance(BroodAdaptiveMath.EXPLOSIVE)) +
                " / ranged: " + percent(data.getResistance(BroodAdaptiveMath.RANGED)) +
                " / radiation: " + percent(data.getResistance(BroodAdaptiveMath.RADIATION))));
        }
    }

    private static String percent(double value) {
        return (int) Math.round(value * 100.0D) + "%";
    }
}
