package com.endlessbrood.common;

import java.math.BigInteger;

/** Pure guardrails for a pacifist construction caste. */
public final class BroodBuilderRules {
    public static final int UNLOCK_STAGE = 6;
    public static final int MAX_BUILDERS_NEAR_NEST = 2;
    public static final int MAX_BLOCKS_PER_BUILDER = 12;
    private BroodBuilderRules() { }
    public static boolean unlocked(BigInteger stage) {
        return stage != null && stage.compareTo(BigInteger.valueOf(UNLOCK_STAGE)) >= 0;
    }
    public static boolean mayBuild(boolean mobGriefing, boolean terrainEnabled,
                                   boolean nearNest, boolean wardProtected,
                                   int completed, boolean validFoundation, boolean emptySpace) {
        return mobGriefing && terrainEnabled && nearNest && !wardProtected &&
            completed < MAX_BLOCKS_PER_BUILDER && validFoundation && emptySpace;
    }
}
