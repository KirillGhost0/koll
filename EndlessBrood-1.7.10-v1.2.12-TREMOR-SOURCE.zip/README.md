**1.2.9 — see SOVEREIGN_UPDATE_RU.md (boss only every five waves, unique 3-block model).**

# Endless Brood 1.2.7 SWARM BALANCE

Compared with 1.2.6, invasion wave ordinary spawn goals are scaled to 80%, and all parasite material drops are independently thinned to 20% of former item rolls. The wave miniboss count and player XP are unchanged. See BALANCE_1_2_7_RU.md.

# 1.2.6 SWARM TACTICS

# Endless Brood 1.2.6 — SWARM TACTICS / Тактика роя

Версия объединяет всё из **1.2.5 DREAD** с согласованными атаками. Никаких отдельных аддонов устанавливать не нужно.

## Что изменено
- **Передача цели:** каждые 100 тиков (со смещением по ID) паразит с целью оповещает соседей в 24 блоках. За одно оповещение подключается до 6 союзников, включая Крыланов.
- **Окружение:** лёгкие наземные особи выбирают стабильные роли и подходят к жертве с флангов, когда видят её на расстоянии 8–25 блоков. Бастион, Колосс, Матка и Командир идут напролом.
- **Авиация:** Крыланы распределяются по разным секторам вокруг жертвы до пикирования. Существующие предупреждающие крики, атаки и отлёт после удара сохранены.
- **Командир:** во время усиления группы передаёт цель наземным и воздушным бойцам.
- **Два игрока:** у разных существ остаются собственные цели и роли; блокировка волн на определённого игрока имеет приоритет перед обычной охотой.
- **Безопасность для HBM:** никаких дополнительных спавнов, телепортации, взрывов, загрузки чанков и разрушения защищённых блоков.

Настройки `config/endlessbrood.cfg`, раздел `[swarmTactics]`: `enableSwarmTactics`, `signalRadius`, `signalIntervalTicks`, `maxFollowersPerSignal`, `flankRepathTicks`, `flankUnlockStage`, `groundFlankRadius`, `flierOrbitRadius`. Новые поля появятся в существующем конфиге после запуска. Стандартные значения: true, 24, 100, 6, 55, 12, 4.5, 6.5.

**Важное:** логика написана и проверяется локальными автономными тестами, но реальная сборка Forge 1.7.10, ИИ и совместимость с NTM должны пройти проверку в игре. Не устанавливайте не проверенный JAR в единственную копию сохранения. До испытания замените JAR только в тестовой сборке у всех игроков и на сервере.

---

# Endless Brood 1.2.1

More reliable remote outbreak seeding, periodic scout patrols, nest offspring groups and contagious incubation are added in 1.2.1. Flying caste, 15-day invasion waves and minibosses remain from 1.2.0. See `UPDATE_1_2_RU.md`.

This package is a single Forge 1.7.10 mod source project. Build via the included GitHub Actions workflow to get one installable JAR. Scanner: 256 blocks (loaded chunks only). Tiered wards, new loot and weapons/armor, persistent survivor skill system. See `UPDATE_1_1_RU.md` for upgrade guidance. This archive is **not** an already-built or runtime-tested JAR.

# Endless Brood 1.0.0-rc2 — Minecraft 1.7.10 Forge

**STATUS: unverified SOURCE release candidate, not a compiled or in-game tested mod JAR.** Do not put the ZIP into the `mods` directory.

Update in rc2: first infection is kept far from the original co-op bases and world spawn (default 768 blocks). A three-day grace period starts when the mod is first installed even in an old world. A few nests can appear in already-generated *loaded* remote terrain without forced chunk loading; vanilla parasite spawns are kept away from remembered starting bases. Infection can later spread toward them naturally through colonies. The initial base positions must be recorded during the first three game days; this does not discover base buildings automatically.

Changes since 0.9.0: idle nest-born parasites patrol back to their saved home nest; matriarchs can call up to six existing guards when attacked (ten-second cooldown); brood wards now block natural spawning nearby; initial threat-free grace defaults to three Minecraft days (60 minutes at 20 TPS) since installation; evolution BigInteger storage now uses an NBT byte array with backward-compatible reading of the old `Points` string.

All 0.9 gameplay features remain: six original 3D models and textures, infinite stages, tiered nests, tainted soil, limited block digging with absolute obsidian/bedrock/end-portal-frame immunity, scanners, serum, damage adaptations, protective wards, staggered village raids, and configurable low entity counts for NTM-heavy packs.

The source has offline smoke tests and a GitHub Actions Java 8 / Gradle 4.4.1 / ForgeGradle 1.2 workflow, but **there has not yet been a full compilation with actual Forge 1.7.10 nor a multiplayer or HBM NTM integration test**.

Russian explanation: `README_RU.md`. Release test procedure: `RELEASE_CHECKLIST_RU.md`. Changelog: `CHANGELOG.md`.

## Build

Upload the archive contents to a GitHub repository, choose **Actions → Build Minecraft 1.7.10 mod → Run workflow**, and inspect the full logs. The action is not proof of compatibility until it actually finishes successfully. Run `bash scripts/smoke-test.sh` locally to check only pure Java rules, model syntax with fake APIs, and PNG headers/dimensions.

The optional `/broodtest days 60` and `/broodtest stage 50` operator-only commands make isolated world testing practical. These commands change persistent test-world data and must not be used on your main survival world.


### Version 1.2.3 BRUTAL
Persistent parasites, reliable near-base siege packs, better short-view-distance patrol and invasion waves. Details in `UPDATE_1_2_3_RU.md`. Not yet Forge-tested.


## HORROR VISUAL UPDATE 1.2.4
All six ground creature models and their distinct skins have been remade as connected skeletal/organic meshes. Winged brood now have serrated segmented membranes, talons, long mandibles and animated wing strokes. UV maps were generated without overlapping face rectangles; each affected creature has its own 512x128 texture. Gameplay, waves, spawn rules, HBM block protection and stage persistence are unchanged. Build and in-game rendering still require verification.


See `TREMOR_1_2_12_RU.md` for heavy boss steps and early parasite sightings.
