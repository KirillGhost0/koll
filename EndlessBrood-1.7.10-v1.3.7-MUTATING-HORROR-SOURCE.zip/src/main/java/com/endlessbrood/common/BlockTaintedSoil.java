package com.endlessbrood.common;

import com.endlessbrood.EndlessBrood;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

/** Mycelium-like self-sustaining soil; metadata 0..3 is visual age, not an artificial spread cutoff. */
public final class BlockTaintedSoil extends Block {
    public BlockTaintedSoil() {
        super(Material.ground);
        setBlockName("endlessbrood.taintedSoil");
        setBlockTextureName("endlessbrood:tainted_soil");
        setHardness(0.65F);
        setStepSound(soundTypeGravel);
        setCreativeTab(CreativeTabs.tabBlock);
        setTickRandomly(true);
    }

    @Override
    public void updateTick(World world, int x, int y, int z, Random random) {
        if (world.isRemote) return;
        if (BroodVictoryData.isDefeated(world)) {
            world.setBlock(x,y,z,Blocks.dirt,0,3);
            return;
        }
        // Radiation decontaminates soil independently of mobGriefing and soil spread.
        // Minecraft random ticks mean cleanup is gradual and only on loaded terrain.
        if (BroodConfig.radiationFear &&
            BroodRadiationBridge.getRadiation(world, x, y, z) >=
                BroodConfig.radiationSoilCleanThreshold) {
            if (random.nextInt(3) == 0) world.setBlock(x, y, z, Blocks.dirt, 0, 3);
            return;
        }
        if (!BroodConfig.taintedSoilSpread ||
            !world.getGameRules().getGameRuleBooleanValue("mobGriefing") ||
            random.nextInt(BroodCalendarRules.soilDivisor(
                BroodConfig.effectiveSoilSpreadDivisor(),
                BroodCalendarRules.day(world.getWorldTime()))) != 0) return;
        // Vanilla-mycelium-like adjacent propagation on the loaded terrain.
        // Older soil may continue spreading; previously it stopped at metadata 3.
        int age = Math.min(3, world.getBlockMetadata(x, y, z));
        int nx = x + random.nextInt(3) - 1;
        int nz = z + random.nextInt(3) - 1;
        int ny = y + random.nextInt(3) - 1;
        if ((nx == x && nz == z && ny == y) || ny < 1 || ny > 250 ||
            !world.blockExists(nx, ny, nz)) return;
        if (BroodWardRules.protects(world, nx, ny, nz)) return;
        Block target = world.getBlock(nx, ny, nz);
        if ((target == Blocks.grass || target == Blocks.dirt || target == Blocks.mycelium) &&
            world.isAirBlock(nx, ny + 1) &&
            (!BroodConfig.radiationFear || BroodRadiationBridge.getRadiation(world, nx, ny, nz)
                < BroodConfig.radiationSoilCleanThreshold)) {
            // Flag 2 sends block update without unnecessary neighbor cascades.
            world.setBlock(nx, ny, nz, EndlessBrood.taintedSoil,
                Math.min(3, age + 1), 2);
        }
    }

    @Override
    public void onEntityWalking(World world, int x, int y, int z, Entity entity) {
        if (world.isRemote || BroodVictoryData.isDefeated(world)) return;
        if (entity instanceof EntityPlayer && world.rand.nextInt(100) == 0)
            ((EntityPlayer) entity).addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, 50, 0));
        // A prolonged stay on corrupted soil may infect livestock and monsters.
        // No immunity checks or TE scan in the hot path unless a rare roll passes.
        else if (entity instanceof EntityLivingBase && BroodConfig.contagiousInfection &&
            world.rand.nextInt(BroodCalendarRules.soilInfectionDivisor(
                BroodConfig.effectiveSoilInfectionDivisor(),
                BroodCalendarRules.day(world.getWorldTime()))) == 0)
            InfectionEvents.infectFromSoil((EntityLivingBase) entity);
    }
}
