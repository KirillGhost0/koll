#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
out="$(mktemp -d)"
trap 'rm -rf "$out"' EXIT
javac -encoding UTF-8 -source 8 -target 8 -d "$out" \
  src/main/java/com/endlessbrood/common/EvolutionMath.java \
  src/main/java/com/endlessbrood/common/ParasiteGenes.java \
  src/main/java/com/endlessbrood/common/ParasiteGenome.java \
  src/main/java/com/endlessbrood/common/BroodAdaptiveMath.java \
  src/main/java/com/endlessbrood/common/BroodDailyBudget.java \
  src/main/java/com/endlessbrood/common/BroodColonyRules.java \
  src/main/java/com/endlessbrood/common/BroodRaidRules.java \
  src/main/java/com/endlessbrood/common/BroodPacingRules.java \
  src/main/java/com/endlessbrood/common/BroodTerritoryRules.java \
  src/main/java/com/endlessbrood/common/BroodBlockPolicy.java \
  src/main/java/com/endlessbrood/common/BroodOutbreakRules.java \
  src/main/java/com/endlessbrood/common/BroodTargetRules.java \
  src/main/java/com/endlessbrood/common/BroodWardLevels.java \
  src/main/java/com/endlessbrood/common/BroodSkillRules.java \
  src/main/java/com/endlessbrood/common/BroodWaveRules.java \
  src/main/java/com/endlessbrood/common/BroodSpawnRules.java \
  src/main/java/com/endlessbrood/common/BroodPressureRules.java \
  src/main/java/com/endlessbrood/common/BroodSiegeRules.java \
  src/main/java/com/endlessbrood/common/BroodThreatTuning.java \
  src/main/java/com/endlessbrood/common/BroodSwarmRules.java \
  src/main/java/com/endlessbrood/common/BroodLootRules.java \
  src/main/java/com/endlessbrood/common/BroodEliteWaveRules.java \
  src/main/java/com/endlessbrood/common/BroodNavigationRules.java \
  src/main/java/com/endlessbrood/common/BroodFootstepRules.java \
  src/main/java/com/endlessbrood/common/BroodRealmRules.java \
  tests/BroodRealmSmoke.java tests/BroodFootstepSmoke.java tests/BroodRulesSmoke.java tests/BroodAdditionsSmoke.java tests/BroodOutbreakProgressSmoke.java tests/BroodWaveSmoke.java tests/BroodSpawnSmoke.java tests/BroodPressureSmoke.java tests/BroodSiegeSmoke.java tests/BroodThreatTuningSmoke.java tests/BroodSwarmSmoke.java tests/BroodBalanceSmoke.java tests/BroodEliteWaveSmoke.java tests/BroodNavigationSmoke.java
java -ea -cp "$out" test.BroodRealmSmoke
java -ea -cp "$out" test.BroodFootstepSmoke
java -cp "$out" test.BroodRulesSmoke
java -cp "$out" test.BroodAdditionsSmoke
java -cp "$out" test.BroodOutbreakProgressSmoke
java -cp "$out" test.BroodWaveSmoke
java -cp "$out" test.BroodSpawnSmoke
java -cp "$out" test.BroodPressureSmoke
java -cp "$out" test.BroodSiegeSmoke
java -cp "$out" test.BroodThreatTuningSmoke
java -cp "$out" test.BroodSwarmSmoke
java -cp "$out" test.BroodBalanceSmoke
java -cp "$out" test.BroodEliteWaveSmoke
java -cp "$out" test.BroodNavigationSmoke
# Optional-HBM RAD stub tests. These test the reflection bridge and fleeing
# without bundling HBM or adding stubs to the production source set.
find tests/radiation-api-stubs -name '*.java' -print0 | xargs -0 javac -encoding UTF-8 -source 8 -target 8 -d "$out" \
  src/main/java/com/endlessbrood/common/BroodRadiationBridge.java \
  src/main/java/com/endlessbrood/common/BroodRadiationBehavior.java
java -cp "$out" test.BroodRadiationSmoke
# Stub compile catches Java syntax errors in model/renderer; it is NOT Forge.
find tests/client-api-stubs -name '*.java' -print0 | xargs -0 javac -encoding UTF-8 -source 8 -target 8 -cp "$out" -d "$out" \
    src/main/java/com/endlessbrood/common/BroodVisualEvolution.java \
    src/main/java/com/endlessbrood/client/BroodStageSkins.java \
    src/main/java/com/endlessbrood/client/ModelBroodParasite.java \
    src/main/java/com/endlessbrood/client/RenderParasite.java \
    src/main/java/com/endlessbrood/client/ModelBroodFlier.java \
    src/main/java/com/endlessbrood/client/RenderBroodFlier.java \
    src/main/java/com/endlessbrood/client/ModelBroodDreadSovereign.java \
    src/main/java/com/endlessbrood/client/RenderBroodCommander.java \
    src/main/java/com/endlessbrood/client/RenderBroodElite.java \
    src/main/java/com/endlessbrood/client/RenderBroodSkyreaper.java
javac -encoding UTF-8 -source 8 -target 8 -cp "$out" -d "$out" tests/BroodRealmVisualSmoke.java
java -ea -cp "$out" test.BroodRealmVisualSmoke
printf '%s\n' 'OK: 6 morph models + renderer compile against mock client API' 
python3 - <<'PY'
import pathlib, struct
base=pathlib.Path('src/main/resources/assets/endlessbrood/textures')
for path in sorted(base.rglob('*.png')):
    d=path.read_bytes()
    assert d[:8] == b'\x89PNG\r\n\x1a\n', f'{path} is not PNG'
    w,h=struct.unpack('>II',d[16:24]); assert w>0 and h>0
    print('PNG OK:', path.name, f'{w}x{h}')
assert len(list((base/'entity').glob('*.png'))) == 85, 'Expect 15 original creature textures + 70 decay variants'
assert (base/'items'/'parasite_egg.png').exists(), 'Missing creative egg icon'
assert len(list((base/'blocks').glob('*.png'))) == 11
assert all((base/'items'/n).exists() for n in ['chitin.png','serum.png','scanner.png','sinew.png','sporeSac.png','boneShard.png','broodCore.png','ward_upgrade.png','skill_codex.png','brood_blade.png','broodHelmet.png','broodChest.png','broodLegs.png','broodBoots.png'])
assert all((base/'models/armor'/n).exists() for n in ['brood_layer_1.png','brood_layer_2.png'])
print('OK: 15 base creatures, 70 stage-decay variants, blocks, items and armor layers')
PY
# Structural regression assertions for the new raid targeting/diagnostics code.
python3 - <<'PY'
from pathlib import Path
root=Path('src/main/java/com/endlessbrood/common')
wave=(root/'BroodWaveTicker.java').read_text()
ground=(root/'EntityParasite.java').read_text()
air=(root/'EntityBroodFlier.java').read_text()
data=(root/'BroodWaveData.java').read_text()
cmd=(root/'BroodWaveCommand.java').read_text()
assert 'spawnPulse(world, data);' in wave, 'First attack group must appear without delay'
assert 'findFloorNearPlayer' in wave and 'player.posY' in wave
assert 'data.failedPlacement++' in wave and 'data.blockedByCap++' in wave
assert 'pursueDistantPrey();' in ground
assert 'EntityAIBroodCloseAttack(this' in ground
assert 'EntityAIBroodIdleWander(this' in ground
assert 'tryMoveToEntityLiving(waveTarget' not in ground
assert 'BroodNavigationRules.shortWaypoint' in ground
assert 'if (hasValidWaveTarget()) {' in ground
assert 'if (waveTarget != null) { target = waveTarget; return; }' in air
assert 'debugWave = tag.getBoolean("DebugWave")' in data
assert 'BroodWaveTicker.beginWave(world, data, index, true)' in cmd
print('PASS: wavefix structural checks, target pursuit and wave diagnostics')
PY

python3 tests/check-horror-uv.py

# Dread Update: check sound registration and bounded visual/AI state transitions.
python3 - <<'PYTEST'
import json, pathlib, subprocess, shutil
base=pathlib.Path('src/main/resources/assets/endlessbrood')
sounds=json.loads((base/'sounds.json').read_text())
assert len(sounds)>=7
for name,entry in sounds.items():
    assert entry['category']=='hostile'
    for raw in entry['sounds']:
        assert (base/'sounds'/(raw.split(':')[-1]+'.ogg')).exists(),raw
        assert (base/'sounds'/(raw.split(':')[-1]+'.ogg')).stat().st_size>2000
    audio=base/'sounds'/(name+'.ogg')
    assert audio.read_bytes()[:4] == b'OggS'
    if shutil.which('ffprobe'):
        probe=subprocess.run(['ffprobe','-v','error','-show_entries','stream=codec_name','-of','default=noprint_wrappers=1',str(audio)],capture_output=True,text=True,check=True)
        assert 'vorbis' in probe.stdout
common=pathlib.Path('src/main/java/com/endlessbrood/common')
ground=(common/'EntityParasite.java').read_text()
flier=(common/'EntityBroodFlier.java').read_text()
for key in ['nextDreadStareAt','getHorrorPose','getNavigator().clearPathEntity()', 'hasValidWaveTarget()']:
    assert key in ground,key
for key in ['getDivePhase','changeDivePhase(1)','changeDivePhase(2)','changeDivePhase(3)','radiationAvoidTicks']:
    assert key in flier,key
assert 'horrorSoundsEnabled' in (common/'BroodConfig.java').read_text()
print('PASS: 1.2.5 sounds, radio-fear override, 4-phase flier dive, synchronized animation poses')
PYTEST

python3 - <<'PYBOSS'
from pathlib import Path
root=Path('src/main/java/com/endlessbrood')
wave=(root/'common/BroodWaveTicker.java').read_text()
entity=(root/'common/EntityBroodCommander.java').read_text()
render=(root/'client/RenderBroodCommander.java').read_text()
assert 'BroodWaveRules.hasSovereign(data.waveIndex)' in wave
assert 'setSize(2.65F, 3.0F)' in entity
assert 'implements IBossDisplayData' in entity
assert 'getHealth() < getMaxHealth() * 0.67F' in entity
assert 'BossStatus.setBossStatus' in render
assert 'BroodStageSkins.forName("dread_sovereign")' in render
assert 'getBlock(' not in entity and 'createExplosion(' not in entity
print('PASS: 5-wave boss schedule, full collision bounds, phases, HBM-safe stomp, boss bar')
PYBOSS
# Additional 1.2.11 budget tests: no real Minecraft/Forge API needed.
perf="$(mktemp -d)"
trap 'rm -rf "$out" "$perf"' EXIT
javac -encoding UTF-8 -source 8 -target 8 -d "$perf" \
  tests/performance-api-stubs/net/minecraft/world/World.java \
  tests/performance-api-stubs/com/endlessbrood/common/BroodConfig.java \
  src/main/java/com/endlessbrood/common/BroodAiBudget.java \
  tests/BroodAiBudgetSmoke.java
java -cp "$perf" test.BroodAiBudgetSmoke
python3 - <<'PY'
from pathlib import Path
c=Path('src/main/java/com/endlessbrood/common')
p=(c/'EntityParasite.java').read_text()
a=(c/'EntityAIBroodCloseAttack.java').read_text()
w=(c/'BroodWaveTicker.java').read_text()
assert 'BroodAiBudget.tryPath(worldObj)' in p
assert 'BroodAiBudget.tryPath(mob.worldObj)' in a
assert 'maxWaveSpawnsPerPulse' in w
assert 'mode == 2 ? 24 : 14' in w
assert 'BroodAiBudget.tryPath(parasite.worldObj)' in (c/'EntityAIBroodNestGuard.java').read_text()
assert 'BroodAiBudget.tryPath(parasite.worldObj)' in (c/'EntityAIBroodVillageRaid.java').read_text()
print('PASS: wave burst and ground navigation structural constraints')
PY

python3 - <<'PY1212'
from pathlib import Path
p=Path('src/main/java/com/endlessbrood')
a=(p/'common/BroodPatrolTicker.java').read_text()
b=(p/'common/BroodOutbreakTicker.java').read_text()
cc=(p/'client/BroodCameraShake.java').read_text()
model=(p/'client/ModelBroodDreadSovereign.java').read_text()
assert 'earlyScoutStartDay' in a and 'earlyScoutLocalCap' in a
assert 'data.canSeedEarlyNest' in b
assert 'Phase.END' in cc and 'adjustedPlayer.rotationPitch -=' in cc
assert 'leftLeg.addChild' in model and 'rightLeg.addChild' in model
print('PASS: day-1 scouts, day-3 nearby nests, reversible client shake, leg pivots')
PY1212
# 1.3.1: Keep final-boss victory and incremental chunk cleansing wired up.
python3 tests/check-victory.py

# 1.3.2 independent resource and integration checks (Forge runtime still required).
python3 - <<'PYRELICS'
from pathlib import Path
b=Path('src/main/java/com/endlessbrood')
main=(b/'EndlessBrood.java').read_text()
boss=(b/'common/EntityBroodAbyssOverlord.java').read_text()
handler=(b/'common/BroodVictoryHandler.java').read_text()
provider=(b/'common/WorldProviderBrood.java').read_text()
network=(b/'common/BroodVictoryNetwork.java').read_text()
for item in ('abyssHeart','abyssEssence','abyssHelmet','abyssChest','abyssLegs','abyssBoots','abyssalReaver','abyssTrophy'):
    assert '"'+item+'"' in main, 'Missing registration '+item
assert 'new ItemStack(abyssEssence, 24)' in main
assert 'entityDropItem(new net.minecraft.item.ItemStack(com.endlessbrood.EndlessBrood.abyssHeart)' in boss
assert 'BroodVictoryNetwork.announceVictory()' in handler
assert 'BroodVictoryClientState.daylightProgress()' in provider
assert 'channel.sendToAll' in network
assert 'BroodVictoryEquipment' in main
assert 'getCurrentArmor(0)' in (b/'common/BroodVictoryEquipment.java').read_text()
assert 'Potion.wither.id' in (b/'common/ItemAbyssalReaver.java').read_text()
assert 'spawnParticle("portal"' in (b/'common/BlockAbyssTrophy.java').read_text()
import struct
assets=Path('src/main/resources/assets/endlessbrood/textures')
for k in ('abyssHeart','abyssEssence','abyssHelmet','abyssChest','abyssLegs','abyssBoots','abyssalReaver'):
    data=(assets/'items'/(k+'.png')).read_bytes(); assert struct.unpack('>II',data[16:24])==(32,32)
data=(assets/'blocks/abyss_trophy.png').read_bytes(); assert struct.unpack('>II',data[16:24])==(32,32)
print('PASS: guaranteed boss reward, crafting economy, set and sword classes, trophy, sky synchronization')
PYRELICS


# Regression checks introduced in the 1.3.2 QA1 pass.
python3 tests/check-qa1.py

# 1.3.3: 15/30-day calendar and mycelium-like terrain propagation.
calendar="$(mktemp -d)"
javac -encoding UTF-8 -source 8 -target 8 -d "$calendar" \
  src/main/java/com/endlessbrood/common/BroodCalendarRules.java \
  tests/BroodCalendarSmoke.java
java -cp "$calendar" test.BroodCalendarSmoke
rm -rf "$calendar"
python3 - <<'PY133'
from pathlib import Path
r=Path('src/main/java/com/endlessbrood')
w=(r/'common/BroodWaveTicker.java').read_text()
p=(r/'common/BroodPassiveHerdSpawns.java').read_text()
s=(r/'common/BlockTaintedSoil.java').read_text()
c=(r/'common/BroodConfig.java').read_text()
assert 'getWorldTime()' in w and 'lastCalendarCycle' in w
assert 'event.setResult(Event.Result.DENY)' in p
assert 'LivingSpawnEvent.SpecialSpawn' in p and 'MAX_QUEUE = 48' in p
assert 'world.getBlock(nx, ny, nz)' in s and 'Blocks.mycelium' in s
assert 'age >= 3' not in s
assert 'herdReplaceStartDay' in c
print('PASS: Forge spawn hook + bounded replacement queue + endless mycelium-like soil spread')
PY133

# 1.3.4 integration wiring (not a substitute for a real Forge build).
bash scripts/verify-134.sh

# 1.3.5: enforce effective 100-point stage cost and migration compatibility.
python3 tests/check-stage100.py
# 1.3.6 daily combat budget and passive-growth regression tests.
python3 tests/check-evolution-136.py
javac -encoding UTF-8 -source 8 -target 8 -cp "$out" -d "$out" tests/BroodEvolution136Smoke.java
java -ea -cp "$out" test.BroodEvolution136Smoke

# 1.3.7: every 10 global stages changes the phenotype, with bounded hitboxes.
vis="$(mktemp -d)"
javac -encoding UTF-8 -source 8 -target 8 -d "$vis" \
    src/main/java/com/endlessbrood/common/BroodVisualEvolution.java \
    tests/BroodVisualEvolutionSmoke.java
java -ea -cp "$vis" test.BroodVisualEvolutionSmoke
rm -rf "$vis"
python3 - <<'PY137'
from pathlib import Path
try:
    from PIL import Image
except ImportError:
    Image = None  # Vanilla Actions runner may not bundle Pillow.
import struct
src=Path('src/main/resources/assets/endlessbrood/textures/entity')
base=['stalker','scuttler','bulwark','thornback','colossus','matriarch','ravager','sporecaller','ironmaw','overmind','flier','skyreaper','dread_sovereign','abyss_overlord']
for n in base:
    base=(src/(n+'.png')).read_bytes()
    for p in range(1,6):
        variant=(src/(n+'_decay'+str(p)+'.png')).read_bytes()
        assert base[:8]==variant[:8]==b'\x89PNG\r\n\x1a\n'
        assert struct.unpack('>II',base[16:24])==struct.unpack('>II',variant[16:24])
        if Image is not None:
            original=Image.open(src/(n+'.png')).convert('RGBA')
            changed=Image.open(src/(n+'_decay'+str(p)+'.png')).convert('RGBA')
            assert changed.getchannel('A').tobytes()==original.getchannel('A').tobytes(),n
code=Path('src/main/java/com/endlessbrood/common/BroodConfig.java').read_text()
assert 'stageCostMigrated137' in code and 'evolutionCost = 100;' in code
boss=Path('src/main/java/com/endlessbrood/client/RenderBroodCommander.java').read_text()
assert 'GL11.glScalef' not in boss
print('PASS: 70 UV-alpha-safe decay sprites, config stage-cost migration, unchanged boss alignment')
PY137
