package com.endlessbrood.common;

import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.world.World;

/** A shared per-world, per-tick quota on expensive synchronous operations.
 * Server tick thread only; never force-loads chunks or moves work off-thread.
 * Keeps 50 pathfinders from all computing A* on the same world tick.
 */
public final class BroodAiBudget {
    private static final Map<World, Quota> BY_WORLD = new WeakHashMap<World, Quota>();
    private static final class Quota {
        long tick = Long.MIN_VALUE;
        int paths;
    }
    private BroodAiBudget() { }

    public static boolean tryPath(World world) {
        if (world == null || world.isRemote) return false;
        long tick = world.getTotalWorldTime();
        synchronized (BY_WORLD) {
            Quota quota = BY_WORLD.get(world);
            if (quota == null) {
                quota = new Quota();
                BY_WORLD.put(world, quota);
            }
            if (quota.tick != tick) {
                quota.tick = tick;
                quota.paths = 0;
            }
            if (quota.paths >= Math.max(1, BroodConfig.maxPathRequestsPerTick)) return false;
            quota.paths++;
            return true;
        }
    }
}
