package com.endlessbrood.common;

import net.minecraft.world.WorldProvider;
import net.minecraft.util.Vec3;
import com.endlessbrood.client.BroodVictoryClientState;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.biome.WorldChunkManagerHell;
import net.minecraft.world.chunk.IChunkProvider;

/** A gloomy independent sky realm; its chunks are generated as floating infested islands. */
public final class WorldProviderBrood extends WorldProvider {
    @Override public void registerWorldChunkManager() {
        worldChunkMgr = new WorldChunkManagerHell(BiomeGenBase.sky, 0.1F);
        dimensionId = BroodRealmTravel.dimensionId;
        hasNoSky = false;
    }
    @Override public IChunkProvider createChunkGenerator() {
        return new ChunkProviderBrood(worldObj, worldObj.getSeed());
    }
    @Override public String getDimensionName() { return "Parasitic Abyss"; }
    @Override public boolean canRespawnHere() { return false; }
    @Override public boolean isSurfaceWorld() { return false; }
    private float restoredSky() {
        if(worldObj == null) return 0F;
        return worldObj.isRemote ? BroodVictoryClientState.daylightProgress() :
            (BroodVictoryData.isDefeated(worldObj) ? 1F : 0F);
    }
    @Override public float calculateCelestialAngle(long time, float partial) {
        return 0.80F - 0.30F * restoredSky();
    }
    @Override public Vec3 getFogColor(float angle, float partial) {
        float p=restoredSky();
        // Slowly transition from dark violet to a clear, muted daytime blue.
        return Vec3.createVectorHelper(0.08D + 0.49D*p,
            0.055D + 0.65D*p, 0.12D + 0.77D*p);
    }
    @Override public boolean canDoLightning(net.minecraft.world.chunk.Chunk chunk) { return false; }
    @Override public boolean canDoRainSnowIce(net.minecraft.world.chunk.Chunk chunk) { return false; }
}
