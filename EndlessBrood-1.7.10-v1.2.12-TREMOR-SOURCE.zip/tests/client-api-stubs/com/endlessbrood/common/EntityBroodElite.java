package com.endlessbrood.common;
public abstract class EntityBroodElite extends EntityParasite {
    public static class Ravager extends EntityBroodElite {}
    public static class Sporecaller extends EntityBroodElite {}
    public static class Ironmaw extends EntityBroodElite {}
    public static class Overmind extends EntityBroodElite {}
}
