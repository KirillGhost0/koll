package test;
import com.endlessbrood.common.BroodSwarmRules;
import java.util.HashSet;
import java.util.Set;
public final class BroodSwarmSmoke {
    private static void check(boolean ok, String why) { if (!ok) throw new AssertionError(why); }
    public static void main(String[] a) {
        Set<String> positions = new HashSet<String>();
        for (int id=0; id<6; id++) {
            double[] p=BroodSwarmRules.flankPoint(100, -100, 90F, id, 5D);
            check(Double.isFinite(p[0]) && Double.isFinite(p[1]),"finite flank");
            check(Math.abs(Math.hypot(p[0]-100,p[1]+100)-5D)<.00001,"fixed orbit distance");
            positions.add(String.format("%.2f %.2f", p[0],p[1]));
            double[] air=BroodSwarmRules.airOrbit(100,-100,id,800L,6.5D);
            check(Math.abs(Math.hypot(air[0]-100,air[1]+100)-6.5D)<.00001,"air orbit radius");
        }
        check(positions.size()>=5,"distributed assault formation");
        check(BroodSwarmRules.shouldFlank(100D,1,true),"flank eligible");
        check(!BroodSwarmRules.shouldFlank(100D,1,false),"blocked sight");
        check(!BroodSwarmRules.shouldFlank(16D,1,true),"no flank in melee");
        check(!BroodSwarmRules.shouldAcceptSharedTarget(64,64),"sticky current target");
        check(BroodSwarmRules.shouldAcceptSharedTarget(16,64),"switch to urgent prey");
        System.out.println("PASS: 1.2.6 swarm geometry and target arbitration");
    }
}
