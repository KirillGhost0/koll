package com.endlessbrood.common;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;

/** Three sequentially installed upgrades; damage value is the target tier. */
public final class ItemWardUpgrade extends Item {
    public ItemWardUpgrade() {
        setUnlocalizedName("endlessbrood.wardUpgrade");
        setTextureName("endlessbrood:ward_upgrade");
        setHasSubtypes(true);
        setMaxDamage(0);
        setCreativeTab(CreativeTabs.tabMaterials);
    }
    @Override
    public String getUnlocalizedName(ItemStack stack) {
        return super.getUnlocalizedName() + Math.max(1, Math.min(3, stack.getItemDamage()));
    }
    @Override
    @SuppressWarnings({"unchecked", "rawtypes"})
    @SideOnly(Side.CLIENT)
    public void getSubItems(Item item, CreativeTabs tab, List list) {
        for (int i = 1; i <= 3; i++) list.add(new ItemStack(item, 1, i));
    }
}
