package com.endlessbrood.client;

import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.boss.BossStatus;
import net.minecraft.entity.boss.IBossDisplayData;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

/** Old 3-block sovereign model scaled up to a five-block final boss. */
public final class RenderBroodAbyssOverlord extends RenderLiving {
    private static final ResourceLocation[] SKINS = BroodStageSkins.forName("abyss_overlord");
    public RenderBroodAbyssOverlord(){ super(new ModelBroodDreadSovereign(),2F); }
    @Override protected ResourceLocation getEntityTexture(Entity e) { return SKINS[BroodStageSkins.phase(e)]; }
    @Override protected void preRenderCallback(EntityLivingBase e,float partial) {
        if(e instanceof IBossDisplayData) BossStatus.setBossStatus((IBossDisplayData)e,true);
        GL11.glScalef(5F/3F,5F/3F,5F/3F);
    }
}
