package com.endlessbrood.common;

/** Pure, bounded intensity arithmetic. Existing config values stay intact:
 * the new 1.2.2 pressure settings scale them even in upgraded worlds. */
public final class BroodPressureRules {
    private BroodPressureRules() { }

    public static int quickerInterval(int ticks, int pressure, int minimum) {
        return Math.max(minimum, ticks / Math.max(1, pressure));
    }

    public static int more(int original, int pressure, int maximum) {
        long scaled = (long) Math.max(0, original) * Math.max(1, pressure);
        return (int) Math.min((long) maximum, scaled);
    }

    /** Cap increases ~50% at intensity 2 instead of doubling to prevent lag. */
    public static int populationCap(int original, int pressure, int maximum) {
        int delta = Math.max(0, pressure - 1);
        long scaled = (long) original + (long) delta * Math.max(2, original / 2);
        return (int) Math.min((long) maximum, scaled);
    }

    public static float chance(float original, int pressure, float ceiling) {
        float bounded = Math.max(0F, original);
        return Math.min(ceiling, bounded * (1F + 0.75F * Math.max(0, pressure - 1)));
    }
}
