package com.endlessbrood.client;

import com.endlessbrood.common.BroodSkillNetwork;
import com.endlessbrood.common.BroodSkills;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.resources.I18n;
import java.util.Arrays;

/** Separate book screen: server decides XP, skill ranks and spending. */
public final class GuiBroodSkills extends GuiScreen {
    private int survivorLevel, xp, nextXp, availablePoints;
    private final int[] ranks = new int[BroodSkills.KEYS.length];
    private boolean received;

    @Override
    @SuppressWarnings("unchecked")
    public void initGui() {
        buttonList.clear();
        int left = width / 2 - 145;
        int top = height / 2 - 100;
        for (int i = 0; i < ranks.length; ++i)
            buttonList.add(new GuiButton(i, left + 196, top + 44 + i * 25, 84, 20, "+"));
        buttonList.add(new GuiButton(99, left + 105, top + 188, 85, 20, I18n.format("gui.done")));
        received = false;
        BroodSkillNetwork.request(-1);
    }

    public void apply(int level, int xp, int nextXp, int points, int[] snapshot) {
        this.survivorLevel = Math.max(0, level);
        this.xp = Math.max(0, xp);
        this.nextXp = Math.max(1, nextXp);
        this.availablePoints = Math.max(0, points);
        System.arraycopy(snapshot, 0, ranks, 0, Math.min(snapshot.length, ranks.length));
        received = true;
    }

    @Override protected void actionPerformed(GuiButton button) {
        if (button.id == 99) { mc.displayGuiScreen(null); return; }
        if (received && button.id >= 0 && button.id < ranks.length &&
            availablePoints > 0 && ranks[button.id] < 10) {
            received = false; // wait for server acknowledgement, prevents double clicks
            BroodSkillNetwork.request(button.id);
        }
    }

    @Override public void drawScreen(int mouseX, int mouseY, float delta) {
        drawDefaultBackground();
        int left = width / 2 - 145;
        int top = height / 2 - 100;
        drawRect(left, top, left + 290, top + 213, 0xEE151620);
        drawRect(left + 3, top + 3, left + 287, top + 30, 0xFF3C2333);
        drawCenteredString(fontRendererObj, I18n.format("endlessbrood.gui.skills.title"), width / 2, top + 10, 0xFFE7D6D3);
        String status = received ? I18n.format("endlessbrood.gui.skills.level", survivorLevel, availablePoints) :
            I18n.format("endlessbrood.gui.skills.loading");
        fontRendererObj.drawStringWithShadow(status, left + 10, top + 35, 0xFFDFCEBA);
        if (received) {
            fontRendererObj.drawStringWithShadow(I18n.format("endlessbrood.gui.skills.xp", xp, nextXp),
                left + 12, top + 166, 0xFFB1A6B0);
            int barWidth = Math.min(270, Math.max(0, (int)(270L * xp / nextXp)));
            drawRect(left + 10, top + 56 + 5 * 25, left + 280, top + 62 + 5 * 25, 0xFF352D34);
            drawRect(left + 10, top + 56 + 5 * 25, left + 10 + barWidth, top + 62 + 5 * 25, 0xFFBC5F65);
        }
        for (int i = 0; i < ranks.length; ++i) {
            int y = top + 50 + i * 25;
            drawRect(left + 9, y - 3, left + 188, y + 16, 0xFF28242C);
            fontRendererObj.drawStringWithShadow(I18n.format("endlessbrood.gui.skill." + BroodSkills.KEYS[i]) +
                "  " + ranks[i] + "/10", left + 15, y + 2, 0xFFE4DDCD);
        }
        for (Object b : buttonList) {
            GuiButton button = (GuiButton)b;
            if (button.id < ranks.length)
                button.enabled = received && availablePoints > 0 && ranks[button.id] < 10;
        }
        super.drawScreen(mouseX, mouseY, delta);
        for (int i = 0; i < ranks.length; ++i) {
            int rowY = top + 44 + i * 25;
            if (mouseX >= left + 10 && mouseX < left + 280 &&
                mouseY >= rowY && mouseY < rowY + 20) {
                drawHoveringText(Arrays.asList(I18n.format("endlessbrood.gui.skill.tip." +
                    BroodSkills.KEYS[i])), mouseX, mouseY, fontRendererObj);
                break;
            }
        }
    }
    @Override public boolean doesGuiPauseGame() { return false; }
}
