# Endless Brood 1.3.7 — HOTFIX 1 (Forge 1.7.10)

## Причина падения GitHub Actions

Из лога `:compileJava FAILED`:

`BlockTaintedSoil.java:59: error: no suitable method found for isAirBlock(int,int)`

Вызов `world.isAirBlock(nx, ny + 1)` содержит только две координаты, однако Minecraft 1.7.10 требует три: `isAirBlock(int x, int y, int z)`.

## Исправление

`src/main/java/com/endlessbrood/common/BlockTaintedSoil.java`:

- Было: `world.isAirBlock(nx, ny + 1)`.
- Стало: `world.isAirBlock(nx, ny + 1, nz)`.

Проверка используется при распространении заражённой почвы: над соседним блоком должен быть воздух.
Изменения баланса, сущностей, генерации измерения и идентификатора `modid` не выполнялись.

Добавлена проверка всех простых вызовов `isAirBlock` в `scripts/smoke-test.sh`, чтобы ошибка не повторилась.
Обновлён только номер сборки: `1.3.7-mutating-horror-hotfix1`.

## Проверка

Автономные тесты запускаются через `bash scripts/smoke-test.sh`.
Полную компиляцию с Forge на GitHub Actions и запуск игры следует проверить отдельно.

## Как установить

1. Поместить ZIP исходников в корень репозитория `koll` (не распаковывая).
2. Поместить новый YAML в `.github/workflows`.
3. В Actions запустить **Build Endless Brood 1.3.7 HOTFIX1**.
4. После успешной сборки скачать JAR из `Artifacts`, удалить старый JAR Endless Brood из папки `mods` и поставить новый.

Старые версии исходного ZIP можно оставить в репозитории: новый workflow использует только HOTFIX1 ZIP.
