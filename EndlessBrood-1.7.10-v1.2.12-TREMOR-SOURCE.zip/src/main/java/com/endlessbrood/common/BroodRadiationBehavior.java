package com.endlessbrood.common;

import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

/** Staggered radiation damage + retreat. No mob pathfinder or chunk forced to load. */
public final class BroodRadiationBehavior {
    private BroodRadiationBehavior() { }

    /** @return true when radiation is sufficiently high to trigger flight */
    public static boolean pulse(EntityParasite parasite) {
        World world = parasite.worldObj;
        int x = MathHelper.floor_double(parasite.posX);
        int y = MathHelper.floor_double(parasite.posY);
        int z = MathHelper.floor_double(parasite.posZ);
        float current = BroodRadiationBridge.getRadiation(world, x, y, z);
        if (current < BroodConfig.radiationFearThreshold) return false;
        parasite.setAttackTarget(null);
        if (current >= BroodConfig.radiationDamageThreshold) {
            float multiplier = Math.min(3.0F, Math.max(1.0F,
                current / BroodConfig.radiationDamageThreshold));
            // Source 'magic' bypasses armor; intentionally unaffected by the
            // evolving combat resistance, so irradiation remains a counter.
            parasite.attackEntityFrom(DamageSource.magic,
                BroodConfig.radiationDamageAmount * multiplier);
        }
        // Peek at neighboring chunks. Prefer a smaller radiation dose.
        // 24-block steps cross chunks in the common HBM chunk-RAD model.
        int[] dx = {24, -24, 0, 0, 17, 17, -17, -17};
        int[] dz = {0, 0, 24, -24, 17, -17, 17, -17};
        float best = current;
        int bestX = x, bestZ = z;
        for (int i = 0; i < dx.length; i++) {
            int tx = x + dx[i], tz = z + dz[i];
            if (!world.blockExists(tx, y, tz)) continue;
            float nearby = BroodRadiationBridge.getRadiation(world, tx, y, tz);
            if (nearby + 0.1F < best) {
                best = nearby;
                bestX = tx;
                bestZ = tz;
            }
        }
        // Within a uniform hot zone there's no known cooler loaded target;
        // retreat in a random available direction instead of attacking.
        if (bestX == x && bestZ == z) {
            int start = world.rand.nextInt(dx.length);
            for (int i = 0; i < dx.length; i++) {
                int k = (i + start) % dx.length;
                if (world.blockExists(x + dx[k], y, z + dz[k])) {
                    bestX = x + dx[k]; bestZ = z + dz[k]; break;
                }
            }
        }
        if (bestX != x || bestZ != z) {
            parasite.getNavigator().clearPathEntity();
            parasite.getNavigator().tryMoveToXYZ(bestX + .5D, parasite.posY,
                bestZ + .5D, 1.35D);
        }
        return true;
    }
}
