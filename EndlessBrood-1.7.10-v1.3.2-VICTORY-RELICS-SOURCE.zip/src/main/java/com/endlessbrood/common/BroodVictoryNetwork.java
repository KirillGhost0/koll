package com.endlessbrood.common;

import com.endlessbrood.EndlessBrood;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.PlayerEvent;
import cpw.mods.fml.common.network.NetworkRegistry;
import cpw.mods.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import cpw.mods.fml.relauncher.Side;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.world.World;

/** Sends the permanent world victory flag on join, dimension change and victory. */
public final class BroodVictoryNetwork {
    private static SimpleNetworkWrapper channel;
    public static void init() {
        channel=NetworkRegistry.INSTANCE.newSimpleChannel("eb_victory");
        channel.registerMessage(BroodVictoryPacket.Handler.class, BroodVictoryPacket.class, 0, Side.CLIENT);
    }
    public static void announceVictory() {
        if(channel!=null) channel.sendToAll(new BroodVictoryPacket(true));
    }
    private static void send(EntityPlayerMP player) {
        if(channel != null && player != null) {
            World world=player.worldObj;
            channel.sendTo(new BroodVictoryPacket(BroodVictoryData.isDefeated(world)),player);
        }
    }
    @SubscribeEvent public void login(PlayerEvent.PlayerLoggedInEvent event) {
        if(event.player instanceof EntityPlayerMP) send((EntityPlayerMP)event.player);
    }
    @SubscribeEvent public void dimensionChanged(PlayerEvent.PlayerChangedDimensionEvent event) {
        if(event.player instanceof EntityPlayerMP) send((EntityPlayerMP)event.player);
    }
}
