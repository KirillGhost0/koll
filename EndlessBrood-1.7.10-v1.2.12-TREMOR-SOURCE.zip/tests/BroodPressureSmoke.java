package test;

import com.endlessbrood.common.BroodPressureRules;

/** Tests the new multipliers without Forge/HBM jars. */
public final class BroodPressureSmoke {
    public static void main(String[] args) {
        check(BroodPressureRules.quickerInterval(3600, 2, 200) == 1800, "twice as many patrol opportunities");
        check(BroodPressureRules.quickerInterval(1800, 2, 100) == 900, "incubation reduced to 45 sec");
        check(BroodPressureRules.quickerInterval(200, 2, 40) == 100, "faster contagious checks");
        check(BroodPressureRules.more(5, 2, 100) == 10, "natural spawn weight");
        check(BroodPressureRules.more(3, 2, 6) == 6, "colony offspring cap");
        check(BroodPressureRules.populationCap(12, 2, 36) == 18, "moderate population increase");
        check(BroodPressureRules.populationCap(28, 2, 70) == 42, "wave local cap");
        check(BroodPressureRules.chance(0.35F, 2, 0.85F) > 0.61F, "increased bite infection");
        check(BroodPressureRules.chance(0.65F, 2, 0.95F) == 0.95F, "fatal conversion capped");
        check(BroodPressureRules.chance(0.9F, 4, 0.95F) == 0.95F, "probability ceiling");
        check(BroodPressureRules.quickerInterval(5, 4, 2) == 2, "minimum interval");
        check(BroodPressureRules.more(0, 2, 100) == 0, "zero disables spawns");
        check(BroodPressureRules.more(3, 1, 6) == 3, "intensity 1 preserves behavior");
        System.out.println("PASS: intensified spawning, swarms and infection stay bounded");
    }
    private static void check(boolean value, String why) {
        if (!value) throw new AssertionError(why);
    }
}
