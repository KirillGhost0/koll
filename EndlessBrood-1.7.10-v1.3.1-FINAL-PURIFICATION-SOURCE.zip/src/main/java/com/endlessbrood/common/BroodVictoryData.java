package com.endlessbrood.common;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraft.world.WorldSavedData;
import net.minecraftforge.common.DimensionManager;

/** Permanent, save-scoped victory switch shared by the Overworld and the Abyss. */
public final class BroodVictoryData extends WorldSavedData {
    private static final String ID = "endlessbrood_abyss_defeated";
    private boolean defeated;

    public BroodVictoryData() { super(ID); }
    public BroodVictoryData(String key) { super(key); }

    public static BroodVictoryData get(World world) {
        // Store in the overworld's MapStorage, not the local dimension, so it
        // survives unloading and remains one flag for the entire save.
        World overworld = DimensionManager.getWorld(0);
        World storageWorld = overworld != null ? overworld : world;
        BroodVictoryData result = (BroodVictoryData) storageWorld.loadItemData(BroodVictoryData.class, ID);
        if (result == null) {
            result = new BroodVictoryData(ID);
            storageWorld.setItemData(ID, result);
        }
        return result;
    }

    public static boolean isDefeated(World world) {
        return world != null && !world.isRemote && get(world).defeated;
    }

    /** @return true only for the first victory in this save. */
    public boolean defeat() {
        if (defeated) return false;
        defeated = true;
        markDirty();
        return true;
    }

    @Override public void readFromNBT(NBTTagCompound nbt) {
        defeated = nbt.getBoolean("Defeated");
    }

    @Override public void writeToNBT(NBTTagCompound nbt) {
        nbt.setBoolean("Defeated", defeated);
    }
}
