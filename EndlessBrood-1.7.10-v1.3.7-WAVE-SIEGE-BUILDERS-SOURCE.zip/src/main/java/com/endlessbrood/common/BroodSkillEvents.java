package com.endlessbrood.common;

import com.endlessbrood.EndlessBrood;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;

public final class BroodSkillEvents {
    @SubscribeEvent
    public void onKill(LivingDeathEvent event) {
        if (event.entityLiving.worldObj.isRemote ||
            !(event.entityLiving instanceof EntityParasite ||
              event.entityLiving instanceof EntityBroodFlier ||
              event.entityLiving instanceof EntityBroodBuilder) ||
            !(event.source.getEntity() instanceof EntityPlayer)) return;
        EntityPlayer killer = (EntityPlayer) event.source.getEntity();
        EntityLivingBase killed = event.entityLiving;
        int worth = killed instanceof EntityParasite ?
            BroodSkillRules.killReward(((EntityParasite) killed).getMorph()) : 8;
        BroodSkills.grant(killer, worth);
        int scavenger = BroodSkills.rank(BroodSkills.get(killer), 3);
        if (scavenger > 0 && killed.getRNG().nextInt(15) < scavenger) {
            BroodLootDrops.roll(killed, EndlessBrood.sinew, 1);
        }
    }
    @SubscribeEvent
    public void onHurt(LivingHurtEvent event) {
        if (event.entityLiving.worldObj.isRemote || event.ammount <= 0F) return;
        if (event.entityLiving instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer) event.entityLiving;
            int defensive = BroodSkills.rank(BroodSkills.get(player), 1);
            // Defensive skill caps at 20% damage mitigation, before armor.
            event.ammount *= (1.0F - 0.02F * defensive);
        }
        if (event.source.getEntity() instanceof EntityPlayer &&
            (event.entityLiving instanceof EntityParasite ||
             event.entityLiving instanceof EntityBroodFlier ||
             event.entityLiving instanceof EntityBroodBuilder)) {
            EntityPlayer player = (EntityPlayer) event.source.getEntity();
            int hunter = BroodSkills.rank(BroodSkills.get(player), 0);
            event.ammount *= 1.0F + 0.035F * hunter;
        }
    }
    @SubscribeEvent
    public void onPlayerUpdate(LivingEvent.LivingUpdateEvent event) {
        if (!(event.entityLiving instanceof EntityPlayer) || event.entityLiving.worldObj.isRemote)
            return;
        EntityPlayer player = (EntityPlayer) event.entityLiving;
        if ((player.ticksExisted + player.getEntityId()) % 100 != 0) return;
        NBTTagCompound data = BroodSkills.get(player);
        int vigor = BroodSkills.rank(data, 2);
        if (vigor > 0 && player.getHealth() > 0 && player.getHealth() < player.getMaxHealth() &&
            player.getFoodStats().getFoodLevel() >= 14)
            player.heal(Math.min(1.0F, vigor * 0.1F));
        int purity = BroodSkills.rank(data, 4);
        if (purity >= 3 && player.isPotionActive(Potion.poison) &&
            player.getRNG().nextInt(12) < purity) player.removePotionEffect(Potion.poison.id);
        if (purity >= 7 && player.isPotionActive(Potion.weakness) &&
            player.getRNG().nextInt(12) < purity) player.removePotionEffect(Potion.weakness.id);
    }
    @SubscribeEvent
    public void onClone(PlayerEvent.Clone event) {
        // Some 1.7.10 Forge code already copies PlayerPersisted, but explicitly
        // copying our own subtree makes this robust across modded respawns.
        NBTTagCompound old = BroodSkills.get(event.original);
        NBTTagCompound dest = BroodSkills.get(event.entityPlayer);
        NBTTagCompound clone = (NBTTagCompound) old.copy();
        for (String key : BroodSkills.KEYS) dest.setInteger(key, clone.getInteger(key));
        dest.setInteger("level", clone.getInteger("level"));
        dest.setInteger("xp", clone.getInteger("xp"));
        dest.setInteger("points", clone.getInteger("points"));
    }
}
