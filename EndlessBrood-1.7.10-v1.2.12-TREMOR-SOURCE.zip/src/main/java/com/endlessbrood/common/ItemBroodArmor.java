package com.endlessbrood.common;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;

public final class ItemBroodArmor extends ItemArmor {
    public ItemBroodArmor(ArmorMaterial material, int slot, String name) {
        super(material, 0, slot);
        setUnlocalizedName("endlessbrood." + name);
        setTextureName("endlessbrood:" + name);
        setCreativeTab(CreativeTabs.tabCombat);
    }
    @Override
    public String getArmorTexture(ItemStack stack, Entity entity, int slot, String type) {
        return "endlessbrood:textures/models/armor/brood_layer_" + (slot == 2 ? "2" : "1") + ".png";
    }
}
