package test;
import com.endlessbrood.common.BroodCalendarRules;
public final class BroodCalendarSmoke {
    private static void eq(long actual,long expected) {
        if(actual!=expected) throw new AssertionError(actual+" != "+expected);
    }
    public static void main(String[] args) {
        long day14=14L*24000L, day15=15L*24000L, day30=30L*24000L;
        eq(BroodCalendarRules.waveCycle(day14,15),0);
        eq(BroodCalendarRules.initialCompletedCycle(day14,15),0);
        eq(BroodCalendarRules.waveCycle(day15,15),1);
        eq(BroodCalendarRules.initialCompletedCycle(day15,15),0); // install on wave day
        eq(BroodCalendarRules.waveCycle(day30,15),2);
        eq(BroodCalendarRules.initialCompletedCycle(day30,15),1);
        eq(BroodCalendarRules.initialCompletedCycle(31L*24000L,15),2);
        eq(BroodCalendarRules.countdownDays(day14,15),1);
        eq(BroodCalendarRules.countdownDays(day15,15),15);
        eq(BroodCalendarRules.waveCycle(600L*24000L,15),40);
        if (BroodCalendarRules.mixHerd(19,20,30) || !BroodCalendarRules.mixHerd(20,20,30) ||
            !BroodCalendarRules.mixHerd(29,20,30) || BroodCalendarRules.mixHerd(30,20,30))
            throw new AssertionError("herd infiltration stage");
        if (BroodCalendarRules.replaceHerd(29,30) || !BroodCalendarRules.replaceHerd(30,30))
            throw new AssertionError("herd replacement stage");
        eq(BroodCalendarRules.soilDivisor(7,0),7);
        eq(BroodCalendarRules.soilDivisor(7,20),5);
        eq(BroodCalendarRules.soilDivisor(7,60),3);
        eq(BroodCalendarRules.patrolInterval(1600,0),1600);
        eq(BroodCalendarRules.patrolInterval(1600,60),640);
        eq(BroodCalendarRules.extraScouts(60),4);
        if (Math.abs(BroodCalendarRules.infectionChance(0.35D, 30) - 0.49D) > 1.e-9 ||
            BroodCalendarRules.infectionChance(0.90D, 100) > 0.95D ||
            BroodCalendarRules.soilInfectionDivisor(160, 60) != 70)
            throw new AssertionError("calendar contagion pressure");
        System.out.println("PASS: calendar waves for existing worlds, infiltrated/replaced herds, capped growth acceleration");
    }
}
