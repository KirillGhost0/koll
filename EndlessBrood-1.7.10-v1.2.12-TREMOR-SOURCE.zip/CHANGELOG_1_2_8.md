## 1.2.8 Elite Sieges
- Five elite entity types with unique registration, textures, basic special attacks and wave stage unlocks.
- Replace ~42% of wave headcount while keeping 1.2.7 reduced loot and protected blocks.
- Plan and spawned-elite breakdown persisted in world NBT.
- Creative eggs 8..12.
- New configurable eliteWaveHeadcountPercent=58.
- Additional smoke tests.
