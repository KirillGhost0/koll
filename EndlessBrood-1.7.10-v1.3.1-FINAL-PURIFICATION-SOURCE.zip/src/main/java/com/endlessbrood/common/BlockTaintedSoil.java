package com.endlessbrood.common;

import com.endlessbrood.EndlessBrood;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

/** Saturation metadata 0..3 bounds propagation from a single nest seed. */
public final class BlockTaintedSoil extends Block {
    public BlockTaintedSoil() {
        super(Material.ground);
        setBlockName("endlessbrood.taintedSoil");
        setBlockTextureName("endlessbrood:tainted_soil");
        setHardness(0.65F);
        setStepSound(soundTypeGravel);
        setCreativeTab(CreativeTabs.tabBlock);
        setTickRandomly(true);
    }

    @Override
    public void updateTick(World world, int x, int y, int z, Random random) {
        if (world.isRemote) return;
        if (BroodVictoryData.isDefeated(world)) {
            world.setBlock(x,y,z,Blocks.dirt,0,3);
            return;
        }
        // Radiation decontaminates soil independently of mobGriefing and soil spread.
        // Minecraft random ticks mean cleanup is gradual and only on loaded terrain.
        if (BroodConfig.radiationFear &&
            BroodRadiationBridge.getRadiation(world, x, y, z) >=
                BroodConfig.radiationSoilCleanThreshold) {
            if (random.nextInt(3) == 0) world.setBlock(x, y, z, Blocks.dirt, 0, 3);
            return;
        }
        if (!BroodConfig.taintedSoilSpread ||
            !world.getGameRules().getGameRuleBooleanValue("mobGriefing") ||
            random.nextInt(BroodConfig.effectiveSoilSpreadDivisor()) != 0) return;
        int age = world.getBlockMetadata(x, y, z);
        if (age >= 3) return;
        int nx = x + random.nextInt(3) - 1;
        int nz = z + random.nextInt(3) - 1;
        if (nx == x && nz == z || !world.blockExists(nx, y, nz)) return;
        if (BroodWardRules.protects(world, nx, y, nz)) return;
        if ((world.getBlock(nx, y, nz) == Blocks.grass || world.getBlock(nx, y, nz) == Blocks.dirt) &&
            world.isAirBlock(nx, y + 1, nz)) {
            world.setBlock(nx, y, nz, EndlessBrood.taintedSoil, age + 1, 3);
        }
    }

    @Override
    public void onEntityWalking(World world, int x, int y, int z, Entity entity) {
        if (world.isRemote || BroodVictoryData.isDefeated(world)) return;
        if (entity instanceof EntityPlayer && world.rand.nextInt(100) == 0)
            ((EntityPlayer) entity).addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, 50, 0));
        // A prolonged stay on corrupted soil may infect livestock and monsters.
        // No immunity checks or TE scan in the hot path unless a rare roll passes.
        else if (entity instanceof EntityLivingBase && BroodConfig.contagiousInfection &&
            world.rand.nextInt(BroodConfig.effectiveSoilInfectionDivisor()) == 0)
            InfectionEvents.infectFromSoil((EntityLivingBase) entity);
    }
}
