package com.endlessbrood.common;

/** Pure timing and difficulty arithmetic, usable by local tests without Forge. */
public final class BroodWaveRules {
    private BroodWaveRules() { }
    public static long intervalTicks(int days) { return Math.max(1L, days) * 24000L; }
    public static int packSize(int wave, int max) {
        return Math.min(Math.max(4, max), 12 + Math.max(0, wave - 1) * 3);
    }
    public static boolean flyersUnlocked(int wave, int stage, int unlockStage) {
        return stage >= unlockStage || wave >= 3;
    }
    /** True only for wave 5, 10, 15, ... . No miniboss in other waves. */
    public static boolean hasSovereign(int wave) { return wave > 0 && wave % 5 == 0; }
    /** Fifth-wave boss: 320 HP; every later fifth wave raises the floor by 40 HP. */
    public static int bossHealth(int wave) {
        return Math.min(840, 280 + Math.max(1, wave / 5) * 40);
    }
    /** Fifth-wave boss: 16 attack; later waves increase damage slowly. */
    public static int bossAttack(int wave) {
        return Math.min(32, 14 + Math.max(1, wave / 5) * 2);
    }
    /** Boss combat weight used only to balance headcount, not gameplay DPS. */
    public static double bossThreatWeight(int wave) {
        return hasSovereign(wave) ? 30D + Math.min(30, Math.max(0, wave / 5 - 1) * 3) : 0D;
    }
    /** Desired late-wave headcount. Sovereign waves trade the regular wave's bulk
     * for one expensive, large entity (which does not break protected blocks). */
    public static int siegeHeadcountCeiling(int wave) {
        if (hasSovereign(wave)) return Math.min(42, 32 + 2 * Math.max(0, wave / 5 - 1));
        if (wave == 7) return 48;
        if (wave == 8) return 50;
        return 52;
    }
}
