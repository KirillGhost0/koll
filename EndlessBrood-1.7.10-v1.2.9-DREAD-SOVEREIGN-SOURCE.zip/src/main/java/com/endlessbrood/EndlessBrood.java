package com.endlessbrood;

import com.endlessbrood.common.*;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.event.FMLServerStartingEvent;
import cpw.mods.fml.common.registry.EntityRegistry;
import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.block.Block;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemArmor;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraftforge.common.MinecraftForge;

@Mod(modid = EndlessBrood.MODID, name = "Endless Brood", version = "1.2.9")
public final class EndlessBrood {
    public static final String MODID = "endlessbrood";
    public static ItemBroodEgg parasiteEgg;
    public static Item chitin;
    public static Item serum;
    public static Item scanner;
    public static Item sinew, sporeSac, boneShard, broodCore;
    public static Item wardUpgrade, skillCodex, broodBlade, sporeDagger;
    public static Item broodHelmet, broodChest, broodLegs, broodBoots;
    private static final Item.ToolMaterial BLADE_MATERIAL = EnumHelper.addToolMaterial(
        "ENDLESSBROOD_BLADE", 2, 900, 5.0F, 2.5F, 14);
    private static final Item.ToolMaterial DAGGER_MATERIAL = EnumHelper.addToolMaterial(
        "ENDLESSBROOD_SPORE", 2, 650, 5.0F, 1.0F, 19);
    private static final ItemArmor.ArmorMaterial ARMOR_MATERIAL = EnumHelper.addArmorMaterial(
        "ENDLESSBROOD_ARMOR", 24, new int[]{2, 6, 5, 2}, 12);
    public static Block nest;
    public static Block taintedSoil;
    public static Block ward;

    @Mod.Instance(MODID)
    public static EndlessBrood instance;

    @SidedProxy(clientSide = "com.endlessbrood.client.ClientProxy",
                serverSide = "com.endlessbrood.common.CommonProxy")
    public static CommonProxy proxy;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        BroodConfig.load(event.getSuggestedConfigurationFile());
        EntityRegistry.registerModEntity(EntityParasite.class, "parasite", 0, this, 64, 3, true);
        EntityRegistry.registerModEntity(EntityBroodFlier.class, "broodFlier", 1, this, 80, 3, true);
        EntityRegistry.registerModEntity(EntityBroodCommander.class, "broodCommander", 2, this, 80, 3, true);
        EntityRegistry.registerModEntity(EntityBroodElite.Ravager.class, "broodRavager", 3, this, 80, 3, true);
        EntityRegistry.registerModEntity(EntityBroodElite.Sporecaller.class, "broodSporecaller", 4, this, 80, 3, true);
        EntityRegistry.registerModEntity(EntityBroodElite.Ironmaw.class, "broodIronmaw", 5, this, 80, 3, true);
        EntityRegistry.registerModEntity(EntityBroodSkyreaper.class, "broodSkyreaper", 6, this, 80, 3, true);
        EntityRegistry.registerModEntity(EntityBroodElite.Overmind.class, "broodOvermind", 7, this, 80, 3, true);
        parasiteEgg = new ItemBroodEgg();
        GameRegistry.registerItem(parasiteEgg, "parasiteEgg");
        chitin = new Item().setUnlocalizedName("endlessbrood.chitin")
            .setTextureName("endlessbrood:chitin").setCreativeTab(CreativeTabs.tabMaterials);
        GameRegistry.registerItem(chitin, "chitin");
        serum = new ItemBroodSerum();
        GameRegistry.registerItem(serum, "serum");
        scanner = new ItemBroodScanner();
        GameRegistry.registerItem(scanner, "scanner");
        sinew = material("sinew");
        sporeSac = material("sporeSac");
        boneShard = material("boneShard");
        broodCore = material("broodCore");
        wardUpgrade = new ItemWardUpgrade();
        GameRegistry.registerItem(wardUpgrade, "wardUpgrade");
        skillCodex = new ItemSkillCodex();
        GameRegistry.registerItem(skillCodex, "skillCodex");
        broodBlade = new ItemBroodBlade(BLADE_MATERIAL);
        GameRegistry.registerItem(broodBlade, "broodBlade");
        sporeDagger = new ItemSporeDagger(DAGGER_MATERIAL);
        GameRegistry.registerItem(sporeDagger, "sporeDagger");
        broodHelmet = new ItemBroodArmor(ARMOR_MATERIAL, 0, "broodHelmet");
        broodChest = new ItemBroodArmor(ARMOR_MATERIAL, 1, "broodChest");
        broodLegs = new ItemBroodArmor(ARMOR_MATERIAL, 2, "broodLegs");
        broodBoots = new ItemBroodArmor(ARMOR_MATERIAL, 3, "broodBoots");
        GameRegistry.registerItem(broodHelmet, "broodHelmet");
        GameRegistry.registerItem(broodChest, "broodChest");
        GameRegistry.registerItem(broodLegs, "broodLegs");
        GameRegistry.registerItem(broodBoots, "broodBoots");
        nest = new BlockBroodNest();
        GameRegistry.registerBlock(nest, "nest");
        taintedSoil = new BlockTaintedSoil();
        GameRegistry.registerBlock(taintedSoil, "taintedSoil");
        ward = new BlockBroodWard();
        GameRegistry.registerBlock(ward, "ward");
        GameRegistry.registerTileEntity(TileEntityBroodWard.class, "EndlessBroodWardTile");
        GameRegistry.registerWorldGenerator(new BroodWorldGenerator(), 0);
        proxy.registerRenderers();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        GameRegistry.addShapelessRecipe(new ItemStack(serum, 2),
            Items.ghast_tear, Items.sugar, Items.glass_bottle, chitin);
        GameRegistry.addRecipe(new ItemStack(ward),
            "IRI", "RCR", "IRI", 'I', Items.iron_ingot, 'R', Items.redstone, 'C', chitin);
        GameRegistry.addRecipe(new ItemStack(scanner),
            " R ", "ICI", " G ", 'R', Items.redstone, 'I', Items.iron_ingot,
            'C', Items.compass, 'G', chitin);
        GameRegistry.addRecipe(new ItemStack(wardUpgrade, 1, 1),
            "SCS", "IRI", "SCS", 'S', sinew, 'C', chitin,
            'I', Items.iron_ingot, 'R', Items.redstone);
        GameRegistry.addRecipe(new ItemStack(wardUpgrade, 1, 2),
            "GCG", "DUD", "GCG", 'G', sporeSac, 'C', chitin,
            'D', Items.diamond, 'U', new ItemStack(wardUpgrade, 1, 1));
        GameRegistry.addRecipe(new ItemStack(wardUpgrade, 1, 3),
            "BCB", "NUN", "BCB", 'B', boneShard, 'C', broodCore,
            'N', Items.nether_star, 'U', new ItemStack(wardUpgrade, 1, 2));
        GameRegistry.addRecipe(new ItemStack(skillCodex),
            "CRC", "SBS", "CPC", 'C', chitin, 'R', Items.redstone,
            'S', sinew, 'B', Items.book, 'P', Items.paper);
        GameRegistry.addRecipe(new ItemStack(broodBlade),
            " C ", " B ", " S ", 'C', broodCore, 'B', boneShard, 'S', sinew);
        GameRegistry.addRecipe(new ItemStack(sporeDagger),
            " G ", " B ", " S ", 'G', sporeSac, 'B', boneShard, 'S', sinew);
        GameRegistry.addRecipe(new ItemStack(broodHelmet),
            "CCC", "C C", 'C', chitin);
        GameRegistry.addRecipe(new ItemStack(broodChest),
            "C C", "CSC", "CCC", 'C', chitin, 'S', sinew);
        GameRegistry.addRecipe(new ItemStack(broodLegs),
            "CCC", "S S", "C C", 'C', chitin, 'S', sinew);
        GameRegistry.addRecipe(new ItemStack(broodBoots),
            "S S", "C C", 'C', chitin, 'S', sinew);
        if (BroodConfig.effectiveNaturalSpawnWeight() > 0) EntityRegistry.addSpawn(EntityParasite.class,
            BroodConfig.effectiveNaturalSpawnWeight(), 1, 3, EnumCreatureType.monster,
            BiomeGenBase.plains, BiomeGenBase.forest, BiomeGenBase.taiga,
            BiomeGenBase.swampland, BiomeGenBase.extremeHills,
            BiomeGenBase.jungle, BiomeGenBase.savanna);
        MinecraftForge.EVENT_BUS.register(new InfectionEvents());
        MinecraftForge.EVENT_BUS.register(new BroodAdaptationEvents());
        MinecraftForge.EVENT_BUS.register(new BroodCombatEvents());
        MinecraftForge.EVENT_BUS.register(new BroodSerumEvents());
        MinecraftForge.EVENT_BUS.register(new BroodSkillEvents());
        FMLCommonHandler.instance().bus().register(new BroodOutbreakTicker());
        FMLCommonHandler.instance().bus().register(new BroodPatrolTicker());
        FMLCommonHandler.instance().bus().register(new BroodSiegeTicker());
        FMLCommonHandler.instance().bus().register(new EvolutionTicker());
        FMLCommonHandler.instance().bus().register(new BroodWaveTicker());
    }

    private static Item material(String id) {
        Item result = new Item().setUnlocalizedName("endlessbrood." + id)
            .setTextureName("endlessbrood:" + id).setCreativeTab(CreativeTabs.tabMaterials);
        GameRegistry.registerItem(result, id);
        return result;
    }

    @Mod.EventHandler
    public void serverStarting(FMLServerStartingEvent event) {
        event.registerServerCommand(new EvolutionCommand());
        event.registerServerCommand(new BroodWaveCommand());
        event.registerServerCommand(new BroodTestCommand());
    }
}
