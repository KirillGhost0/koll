package com.endlessbrood.client;

import com.endlessbrood.common.EntityBroodElite;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

/** Shares optimized original meshes with recognizable caste-specific textures. */
public final class RenderBroodElite extends RenderLiving {
    public RenderBroodElite() { super(new ModelBroodParasite(), 0.55F); }
    @Override protected ResourceLocation getEntityTexture(Entity entity) {
        String skin = entity instanceof EntityBroodElite.Ravager ? "ravager" :
            entity instanceof EntityBroodElite.Sporecaller ? "sporecaller" :
            entity instanceof EntityBroodElite.Ironmaw ? "ironmaw" : "overmind";
        return new ResourceLocation("endlessbrood", "textures/entity/"+skin+".png");
    }
    @Override protected void preRenderCallback(EntityLivingBase entity, float partial) {
        float s=entity instanceof EntityBroodElite.Ironmaw ? 1.23F :
            entity instanceof EntityBroodElite.Overmind ? 1.17F : 1.08F;
        GL11.glScalef(s, s, s);
    }
}
