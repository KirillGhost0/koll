# Исправление ошибки сборки Forge 1.7.10 (RC2 fix1)

Лог GitHub Actions показывал 17 ошибок в `EvolutionData.java` и `BroodOutbreakData.java`.

Причина: `WorldSavedData` в Minecraft 1.7.10 находится в пакете
`net.minecraft.world`, а не `net.minecraft.world.storage`.

Исправлено в двух исходниках:
- `src/main/java/com/endlessbrood/common/EvolutionData.java`
- `src/main/java/com/endlessbrood/common/BroodOutbreakData.java`

Была строка:
```java
import net.minecraft.world.storage.WorldSavedData;
```

Стала:
```java
import net.minecraft.world.WorldSavedData;
```

Это также устраняет ошибки наследования и вызовов `markDirty()` в тех же классах.
Другие файлы проекта не менялись. Выполнены локальные smoke-тесты,
но полная компиляция Forge и запуск в Minecraft пока не подтверждены.
