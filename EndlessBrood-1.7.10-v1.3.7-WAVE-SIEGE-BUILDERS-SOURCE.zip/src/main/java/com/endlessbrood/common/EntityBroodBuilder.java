package com.endlessbrood.common;

import com.endlessbrood.EndlessBrood;
import java.math.BigInteger;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.EntityCreature;
import net.minecraft.init.Blocks;
import net.minecraft.block.Block;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

/** Noncombat support parasite: approaches a linked nest and builds organic ramparts.
 * Zero attack tasks, zero prey scanning, zero block breaking or offspring generation.
 * Builds only into air over natural ground in already-loaded chunks; ward-safe.
 */
public final class EntityBroodBuilder extends EntityCreature {
    private boolean hasHome;
    private int homeX, homeY, homeZ;
    private int blocksBuilt;
    private long nextWorkTick;
    private int siteX, siteY, siteZ;
    private boolean hasSite;
    private int cachedTier = -1;
    // Siege workers are separate from nest workers and build a ramp to an elevated base.
    private boolean siegeMode;
    private int siegeX, siegeZ, siegeGroundY, siegeTargetX, siegeTargetZ, siegeTargetY;
    private int siegeProgress, siegeBridgeProgress, siegeDirection;
    private long siegeExpireTick;


    public EntityBroodBuilder(World world) {
        super(world);
        setSize(0.90F, 1.15F);
        experienceValue = 3;
        tasks.addTask(0, new EntityAISwimming(this));
        tasks.addTask(5, new EntityAIWatchClosest(this, EntityPlayer.class, 8F));
        tasks.addTask(6, new EntityAILookIdle(this));
        // In particular: NO attack AI, retaliation, village raiding or digging.
    }

    public void setBroodHome(int x, int y, int z) {
        hasHome = true;
        homeX = x; homeY = y; homeZ = z;
    }

    /** The two wave workers build independent spiral approaches; never target players in combat. */
    public void setWaveConstructionSite(int groundX, int groundY, int groundZ,
                                        int playerX, int playerFeetY, int playerZ, int direction) {
        siegeMode = true;
        hasHome = false;
        siegeDirection = direction & 3;
        siegeX = groundX;
        siegeZ = groundZ;
        siegeGroundY = groundY;
        siegeTargetX = playerX;
        siegeTargetZ = playerZ;
        siegeTargetY = Math.max(3, Math.min(249, playerFeetY - 1));
        siegeProgress = 0;
        siegeBridgeProgress = 0;
        blocksBuilt = 0;
        nextWorkTick = 0L;
        siegeExpireTick = worldObj.getTotalWorldTime() + 3600L;
    }

    @Override protected void entityInit() {
        super.entityInit();
        dataWatcher.addObject(20, Integer.valueOf(0));
    }
    public int getVisualTier() { return dataWatcher.getWatchableObjectInt(20); }

    @Override protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(24D);
        getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.25D);
        getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(20D);
    }
    @Override protected boolean isAIEnabled() { return true; }
    @Override protected boolean canDespawn() { return !BroodConfig.parasitesPersistent && super.canDespawn(); }
    @Override protected String getLivingSound() { return BroodConfig.horrorSoundsEnabled ? "endlessbrood:chitter" : "mob.spider.say"; }
    @Override protected String getHurtSound() { return BroodConfig.horrorSoundsEnabled ? "endlessbrood:hiss" : "mob.spider.say"; }
    @Override protected String getDeathSound() { return BroodConfig.horrorSoundsEnabled ? "endlessbrood:death" : "mob.spider.death"; }
    @Override public boolean attackEntityAsMob(net.minecraft.entity.Entity target) { return false; }

    @Override public void onLivingUpdate() {
        super.onLivingUpdate();
        if (worldObj.isRemote || !isEntityAlive()) return;
        if (BroodVictoryData.isDefeated(worldObj)) { setDead(); return; }
        if (ticksExisted == 1 || ticksExisted % 200 == 0) {
            int tier = BroodVisualEvolution.tier(EvolutionData.get(worldObj).getStage());
            if (tier != cachedTier) {
                cachedTier = tier;
                dataWatcher.updateObject(20, Integer.valueOf(tier));
            }
        }
        if (siegeMode) { updateWaveConstruction(); return; }
        if (!hasHome || blocksBuilt >= BroodBuilderRules.MAX_BLOCKS_PER_BUILDER ||
            ticksExisted % 20 != (getEntityId() & 15) ||
            !BroodConfig.nestsEnabled || !BroodConfig.allowTerrainDamage ||
            !worldObj.getGameRules().getGameRuleBooleanValue("mobGriefing") ||
            worldObj.getTotalWorldTime() < nextWorkTick) return;
        nextWorkTick = worldObj.getTotalWorldTime() + 60L;
        if (!nestIsValid()) { hasSite = false; return; }
        if (!hasSite && !chooseSite()) return;
        // The builder must actually reach its build site; no remote building.
        double dx = posX - (siteX + 0.5D), dz = posZ - (siteZ + 0.5D);
        if (dx * dx + dz * dz > 7.0D) {
            if (BroodAiBudget.tryPath(worldObj))
                getNavigator().tryMoveToXYZ(siteX + .5D, siteY, siteZ + .5D, 0.95D);
            // Stale sites are refreshed, but no additional synchronous path scans.
            if (rand.nextInt(4) == 0) hasSite = false;
            return;
        }
        if (canPlace(siteX, siteY, siteZ) &&
            worldObj.getEntitiesWithinAABB(EntityLivingBase.class,
                AxisAlignedBB.getBoundingBox(siteX, siteY, siteZ,
                    siteX + 1D, siteY + 1D, siteZ + 1D)).isEmpty() &&
            worldObj.setBlock(siteX, siteY, siteZ, EndlessBrood.taintedSoil, 0, 3)) {
            ++blocksBuilt;
            worldObj.playAuxSFX(2001, siteX, siteY, siteZ,
                Block.getIdFromBlock(EndlessBrood.taintedSoil));
        }
        hasSite = false;
    }

    /** Organic growth extends along a fixed staircase plan from the worker's ground
     * construction site, allowing attackers to WALK up into floating player bases.
     * No chunk loading, overwriting of blocks or direct attacks are involved.
     */
    private void updateWaveConstruction() {
        if (ticksExisted % 6 != (getEntityId() % 6 + 6) % 6 ||
            worldObj.getTotalWorldTime() < nextWorkTick) return;
        if (worldObj.getTotalWorldTime() >= siegeExpireTick ||
            blocksBuilt >= BroodSiegeBuilderRules.MAX_BLOCKS) { setDead(); return; }
        if (!BroodConfig.allowTerrainDamage ||
            !worldObj.getGameRules().getGameRuleBooleanValue("mobGriefing")) return;
        boolean nearbyPlayer = false;
        for (Object object : worldObj.playerEntities) {
            if (!(object instanceof EntityPlayer)) continue;
            EntityPlayer player = (EntityPlayer)object;
            if (player.isEntityAlive() &&
                player.getDistanceSq(siegeTargetX + 0.5D, player.posY, siegeTargetZ + 0.5D) < 96D * 96D) {
                nearbyPlayer = true; break;
            }
        }
        if (!nearbyPlayer) return;
        nextWorkTick = worldObj.getTotalWorldTime() + 6L;
        int steps = BroodSiegeBuilderRules.stepsToTarget(siegeGroundY, siegeTargetY);
        if (!BroodSiegeBuilderRules.canStart(siegeGroundY, siegeTargetY)) {
            // Flat ground: wave builders raise low organic cover instead of idling.
            if (siegeProgress >= 8) return;
            int x = siegeX + BroodSiegeBuilderRules.stairX(siegeProgress);
            int z = siegeZ + BroodSiegeBuilderRules.stairZ(siegeProgress);
            if (!worldObj.blockExists(x,siegeGroundY-1,z) ||
                !worldObj.getBlock(x,siegeGroundY-1,z).getMaterial().isSolid()) return;
            if (placeSiegeBlock(x,siegeGroundY,z)) siegeProgress++;
            return;
        }
        if (siegeProgress < steps) {
            int x = siegeX + BroodSiegeBuilderRules.stairX(siegeProgress);
            int z = siegeZ + BroodSiegeBuilderRules.stairZ(siegeProgress);
            int y = siegeGroundY + siegeProgress;
            // Each new stair block has a block one level below it; that support
            // touches the previous tread horizontally. Never leaves diagonal islands.
            if (siegeProgress > 0 &&
                (!worldObj.blockExists(x, y-1, z))) return;
            if (siegeProgress > 0 && worldObj.isAirBlock(x, y - 1, z)) {
                if (!placeSiegeBlock(x, y - 1, z)) return;
            }
            if (!placeSiegeBlock(x, y, z)) return;
            siegeProgress++;
            return;
        }
        // Continue horizontally from the last tread toward the player's platform.
        // The last riser is exactly one step below the base's floor level.
        if (siegeBridgeProgress >= BroodSiegeBuilderRules.MAX_BRIDGE) { setDead(); return; }
        int startX = siegeX + BroodSiegeBuilderRules.stairX(steps - 1);
        int startZ = siegeZ + BroodSiegeBuilderRules.stairZ(steps - 1);
        int x = startX, z = startZ;
        for (int i = 0; i <= siegeBridgeProgress; ++i) {
            int dx = siegeTargetX - x, dz = siegeTargetZ - z;
            if (dx == 0 && dz == 0) { setDead(); return; }
            if (Math.abs(dx) >= Math.abs(dz) && dx != 0) x += dx > 0 ? 1 : -1;
            else z += dz > 0 ? 1 : -1;
        }
        // Existing solid floor means the access path has met the floating base.
        if (worldObj.blockExists(x, siegeTargetY, z) &&
            !worldObj.isAirBlock(x, siegeTargetY, z)) {
            setDead(); return;
        }
        // Tie the first bridge tile into the previous stair tread with a side
        // support. No unsupported diagonal islands in the structure.
        if (siegeBridgeProgress == 0) {
            if (!worldObj.blockExists(x,siegeTargetY-1,z)) return;
            if (worldObj.isAirBlock(x,siegeTargetY-1,z) &&
                !placeSiegeBlock(x,siegeTargetY-1,z)) return;
        }
        if (!placeSiegeBlock(x, siegeTargetY, z)) return;
        ++siegeBridgeProgress;
    }

    private boolean placeSiegeBlock(int x, int y, int z) {
        if (y < 2 || y > 249 || !worldObj.blockExists(x, y, z)) return false;
        // Do not replace player bases, HBM machinery, water, shields or terrain.
        if (!worldObj.isAirBlock(x, y, z))
            return worldObj.getBlock(x, y, z) == EndlessBrood.taintedSoil;
        if (!BroodSiegeBuilderRules.canAdd(
            worldObj.getGameRules().getGameRuleBooleanValue("mobGriefing"),
            BroodConfig.allowTerrainDamage, BroodWardRules.protects(worldObj, x,y,z),
            true, true,
            worldObj.getEntitiesWithinAABB(EntityLivingBase.class,
                AxisAlignedBB.getBoundingBox(x,y,z,x+1D,y+1D,z+1D)).isEmpty(),
            blocksBuilt) ||
            BroodRadiationBridge.getRadiation(worldObj,x,y,z) >= BroodConfig.radiationFearThreshold)
            return false;
        if (!worldObj.setBlock(x,y,z,EndlessBrood.taintedSoil,0,3)) return false;
        ++blocksBuilt;
        return true;
    }

    private boolean nestIsValid() {
        if (Math.abs(posX - homeX) > 24D || Math.abs(posZ - homeZ) > 24D ||
            !worldObj.blockExists(homeX, homeY, homeZ)) return false;
        return worldObj.getBlock(homeX, homeY, homeZ) == EndlessBrood.nest &&
            !BroodWardRules.protects(worldObj, homeX, homeY, homeZ) &&
            (!BroodConfig.radiationStopsNests ||
             BroodRadiationBridge.getRadiation(worldObj, homeX, homeY, homeZ) <
                BroodConfig.radiationSoilCleanThreshold);
    }

    private boolean chooseSite() {
        for (int n = 0; n < 8; ++n) {
            // Irregular defensive ring 3..6 blocks out; never blocks the nest itself.
            double angle = rand.nextDouble() * Math.PI * 2D;
            int radius = 3 + rand.nextInt(4);
            int x = homeX + MathHelper.floor_double(Math.cos(angle) * radius);
            int z = homeZ + MathHelper.floor_double(Math.sin(angle) * radius);
            if (!worldObj.blockExists(x, homeY, z)) continue;
            int y = worldObj.getHeightValue(x, z);
            if (y < homeY - 3 || y > homeY + 3 || !canPlace(x,y,z)) continue;
            siteX = x; siteY = y; siteZ = z;
            hasSite = true;
            return true;
        }
        return false;
    }

    private boolean canPlace(int x, int y, int z) {
        if (y < 2 || y > 249 || !worldObj.blockExists(x, y, z) ||
            !worldObj.blockExists(x, y - 1, z)) return false;
        Block foundation = worldObj.getBlock(x, y - 1, z);
        // NEVER place atop HBM machinery, wards, houses, containers or modded bases.
        boolean allowedGround = foundation == Blocks.dirt || foundation == Blocks.grass ||
            foundation == Blocks.stone || foundation == Blocks.sand ||
            foundation == Blocks.gravel || foundation == EndlessBrood.taintedSoil;
        return BroodBuilderRules.mayBuild(
            worldObj.getGameRules().getGameRuleBooleanValue("mobGriefing"),
            BroodConfig.allowTerrainDamage, nestIsValid(), BroodWardRules.protects(worldObj, x,y,z),
            blocksBuilt, allowedGround, worldObj.isAirBlock(x,y,z)) &&
            BroodRadiationBridge.getRadiation(worldObj, x,y,z) < BroodConfig.radiationFearThreshold;
    }

    @Override public void writeEntityToNBT(NBTTagCompound tag) {
        super.writeEntityToNBT(tag);
        tag.setBoolean("broodBuilderHasHome", hasHome);
        tag.setInteger("broodBuilderHomeX", homeX);
        tag.setInteger("broodBuilderHomeY", homeY);
        tag.setInteger("broodBuilderHomeZ", homeZ);
        tag.setInteger("broodBuilderBlocksBuilt", blocksBuilt);
        tag.setBoolean("broodSiegeMode", siegeMode);
        if (siegeMode) {
            tag.setInteger("broodSiegeX", siegeX);
            tag.setInteger("broodSiegeZ", siegeZ);
            tag.setInteger("broodSiegeGroundY", siegeGroundY);
            tag.setInteger("broodSiegeTargetX", siegeTargetX);
            tag.setInteger("broodSiegeTargetZ", siegeTargetZ);
            tag.setInteger("broodSiegeTargetY", siegeTargetY);
            tag.setInteger("broodSiegeProgress", siegeProgress);
            tag.setInteger("broodSiegeBridgeProgress", siegeBridgeProgress);
            tag.setInteger("broodSiegeDirection", siegeDirection);
            tag.setLong("broodSiegeExpireTick", siegeExpireTick);
        }
    }
    @Override public void readEntityFromNBT(NBTTagCompound tag) {
        super.readEntityFromNBT(tag);
        hasHome = tag.getBoolean("broodBuilderHasHome");
        homeX = tag.getInteger("broodBuilderHomeX");
        homeY = tag.getInteger("broodBuilderHomeY");
        homeZ = tag.getInteger("broodBuilderHomeZ");
        siegeMode = tag.getBoolean("broodSiegeMode");
        blocksBuilt = Math.max(0, Math.min(siegeMode ? BroodSiegeBuilderRules.MAX_BLOCKS :
            BroodBuilderRules.MAX_BLOCKS_PER_BUILDER, tag.getInteger("broodBuilderBlocksBuilt")));
        if (siegeMode) {
            siegeX = tag.getInteger("broodSiegeX");
            siegeZ = tag.getInteger("broodSiegeZ");
            siegeGroundY = tag.getInteger("broodSiegeGroundY");
            siegeTargetX = tag.getInteger("broodSiegeTargetX");
            siegeTargetZ = tag.getInteger("broodSiegeTargetZ");
            siegeTargetY = tag.getInteger("broodSiegeTargetY");
            siegeProgress = Math.max(0, Math.min(BroodSiegeBuilderRules.MAX_HEIGHT,tag.getInteger("broodSiegeProgress")));
            siegeBridgeProgress = Math.max(0, Math.min(BroodSiegeBuilderRules.MAX_BRIDGE,tag.getInteger("broodSiegeBridgeProgress")));
            siegeDirection = tag.getInteger("broodSiegeDirection") & 3;
            siegeExpireTick = tag.getLong("broodSiegeExpireTick");
        }
        hasSite = false;
    }
}
