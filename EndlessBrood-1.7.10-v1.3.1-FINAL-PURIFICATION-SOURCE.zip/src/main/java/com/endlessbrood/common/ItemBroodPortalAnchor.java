package com.endlessbrood.common;

import net.minecraft.block.Block;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;

public final class ItemBroodPortalAnchor extends ItemBlock {
    public ItemBroodPortalAnchor(Block block) { super(block); setHasSubtypes(true); setMaxDamage(0); }
    @Override public int getMetadata(int damage) { return damage & 3; }
    @Override public String getUnlocalizedName(ItemStack stack) {
        return super.getUnlocalizedName() + "." + (stack.getItemDamage() & 3);
    }
}
