package com.endlessbrood.common;
import net.minecraft.entity.EntityLivingBase;
public class EntityBroodBuilder extends EntityLivingBase {
    public int getVisualTier() { return 0; }
}
