package test;
import com.endlessbrood.common.BroodOutbreakRules;
public class BroodOutbreakProgressSmoke {
    public static void main(String[] args) {
        long start = 11000000L;
        require(BroodOutbreakRules.effectiveHomeRadius(start, start, 3, 768, 40) == 768, "initial radius");
        require(BroodOutbreakRules.effectiveHomeRadius(start + 3 * 24000L, start, 3, 768, 40) == 768, "after grace");
        require(BroodOutbreakRules.effectiveHomeRadius(start + 23 * 24000L, start, 3, 768, 40) == 384, "halfway");
        require(BroodOutbreakRules.effectiveHomeRadius(start + 43 * 24000L, start, 3, 768, 40) == 0, "fully reached");
        require(!BroodOutbreakRules.graceExpired(start + 20, start, 3), "actual ticks, not daylight time");
        System.out.println("OK: invasion advance timing and distance");
    }
    private static void require(boolean b, String s) { if (!b) throw new AssertionError(s); }
}
