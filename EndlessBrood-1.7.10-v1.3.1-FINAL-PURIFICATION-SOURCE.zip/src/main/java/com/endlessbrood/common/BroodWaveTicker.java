package com.endlessbrood.common;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.MathHelper;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;

/** A wave is a finite, tracked siege, not ambient random monster spawning.
 * Uses loaded chunks only. Failure counters make blocked waves diagnosable.
 */
public final class BroodWaveTicker {
    private static final int WAVE_TICKS = 2400; // two real minutes at 20 TPS
    private static final int PULSE_TICKS = 80;  // 4 seconds between reinforcement groups

    @SubscribeEvent
    public void worldTick(TickEvent.WorldTickEvent event) {
        World world = event.world;
        if (!world.isRemote && BroodVictoryData.isDefeated(world)) return;
        if (event.phase != TickEvent.Phase.END || world.isRemote ||
            world.provider.dimensionId != 0 || !BroodConfig.wavesEnabled ||
            world.playerEntities.isEmpty() || world.getTotalWorldTime() % 20L != 0L) return;
        BroodWaveData data = BroodWaveData.get(world);
        data.playedTicks += 20L;
        long interval = BroodWaveRules.intervalTicks(BroodConfig.waveIntervalDays);
        if (data.waveTicksLeft <= 0) {
            if (!data.warned && data.playedTicks >= interval - 24000L) {
                announce(world, "§6[Endless Brood] §eСледующая волна через игровой день!");
                data.warned = true;
            }
            if (data.playedTicks >= interval) {
                data.playedTicks -= interval;
                beginWave(world, data, data.waveIndex + 1, false);
            }
        }
        if (data.waveTicksLeft > 0) {
            if (data.waveTicksLeft % PULSE_TICKS == 0) spawnPulse(world, data);
            data.waveTicksLeft -= 20;
            if (data.waveTicksLeft == 0) {
                announce(world, "§2[Endless Brood] §aВолна " + data.waveIndex + " закончилась. " +
                    "Появилось: " + data.spawned + " (элита: " + eliteSpawnedTotal(data) + "), Владыка ужаса: " + data.bossSpawned +
                    ". /broodwave status — подробности.");
                data.debugWave = false;
            }
        }
        data.markDirty();
    }

    /** Allows an operator to explicitly stage wave 5 in creative for visual tests.
     * Natural attacks continue to ignore creative/spectator players.
     */
    public static void beginWave(World world, BroodWaveData data, int index, boolean debug) {
        if (BroodVictoryData.isDefeated(world)) return;
        data.waveIndex = Math.max(1, index);
        data.waveTicksLeft = WAVE_TICKS;
        data.spawned = 0;
        BroodEliteWaveRules.Plan plan = BroodEliteWaveRules.plan(data.waveIndex,
            EvolutionData.get(world).getStage().min(java.math.BigInteger.valueOf(Long.MAX_VALUE)).longValue(),
            BroodConfig.effectiveWaveMobCount(BroodWaveRules.packSize(data.waveIndex, BroodConfig.waveMaxMobs)),
            BroodConfig.eliteWaveHeadcountPercent);
        data.plannedTotal = plan.total;
        data.spawnedRegular = 0;
        data.eliteQuotas = plan.elite;
        data.eliteSpawned = new int[BroodEliteWaveRules.CASTES];
        data.bossSpawned = false;
        data.warned = false;
        data.debugWave = debug;
        data.failedPlacement = 0;
        data.blockedByCap = 0;
        data.noTargets = 0;
        announce(world, "§4[Endless Brood] §cВОЛНА " + data.waveIndex +
            (debug ? " (испытание)" : "") + "! Противники идут к игрокам." +
            (BroodConfig.waveBosses && BroodWaveRules.hasSovereign(data.waveIndex) ? " §4С ними пришёл Владыка ужаса!" : ""));
        data.markDirty();
        // Spawn a visible first group right away, rather than waiting for a pulse.
        spawnPulse(world, data);
    }

    private static void announce(World world, String message) {
        for (Object o : world.playerEntities) if (o instanceof EntityPlayer)
            ((EntityPlayer)o).addChatMessage(new ChatComponentText(message));
    }

    private static void spawnPulse(World world, BroodWaveData data) {
        if (world.difficultySetting == EnumDifficulty.PEACEFUL ||
            !world.getGameRules().getGameRuleBooleanValue("doMobSpawning")) {
            data.noTargets++; // Explain peaceful or /gamerule blocks in status.
            return;
        }
        // Older saves may contain an unfinished wave without the 1.2.8 plan.
        if (data.plannedTotal <= 0) {
            BroodEliteWaveRules.Plan latePlan = BroodEliteWaveRules.plan(data.waveIndex,
                EvolutionData.get(world).getStage().min(java.math.BigInteger.valueOf(Long.MAX_VALUE)).longValue(),
                BroodConfig.effectiveWaveMobCount(BroodWaveRules.packSize(data.waveIndex, BroodConfig.waveMaxMobs)),
                BroodConfig.eliteWaveHeadcountPercent);
            data.plannedTotal = latePlan.total;
            data.eliteQuotas = latePlan.elite;
            data.spawnedRegular = data.spawned;
        }
        int totalGoal = data.plannedTotal;
        if (data.spawned >= totalGoal && (!BroodConfig.waveBosses || !BroodWaveRules.hasSovereign(data.waveIndex) || data.bossSpawned)) return;
        List<EntityPlayer> leaders = new ArrayList<EntityPlayer>();
        for (Object o : world.playerEntities) {
            if (!(o instanceof EntityPlayer)) continue;
            EntityPlayer p = (EntityPlayer)o;
            if (!p.isEntityAlive() || (!data.debugWave && p.capabilities.isCreativeMode)) continue;
            boolean grouped = false;
            for (EntityPlayer other : leaders) if (p.getDistanceSqToEntity(other) < 128D * 128D) {
                grouped = true; break;
            }
            if (!grouped && leaders.size() < BroodConfig.waveMaxGroups) leaders.add(p);
        }
        if (leaders.isEmpty()) {
            data.noTargets++;
            return;
        }
        // Wave goal is across the co-op group(s). Each pulse distributes reinforcements
        // instead of repeating an enormous all-at-once spawn at the player's exact spot.
        // More visible creatures per pulse, still capped by the per-area entity limit.
        int budget = Math.min(BroodConfig.maxWaveSpawnsPerPulse,
            BroodThreatTuning.reinforcementPulseSize(BroodConfig.swarmPressure));
        int spawnedThisPulse = 0;
        int group = 0;
        for (EntityPlayer player : leaders) {
            // Fair split between separate co-op bases; never spend the entire
            // pulse on the first player when two groups are under attack.
            int groupBudget = budget / leaders.size() +
                (group++ < budget % leaders.size() ? 1 : 0);
            if (!data.bossSpawned && BroodConfig.waveBosses && BroodWaveRules.hasSovereign(data.waveIndex)) {
                if (spawnNear(world, player, 2, data)) data.bossSpawned = true;
            }
            for (int i = 0; i < groupBudget && data.spawned < totalGoal && spawnedThisPulse < budget; ++i) {
                int caste = nextElite(data);
                int regularQuota = totalGoal - eliteQuotaTotal(data);
                // Space out expensive castes: every third creature is an elite when
                // a quota remains, or elites finish the wave after regulars are exhausted.
                boolean useElite = caste >= 0 && (data.spawned % 3 == 1 ||
                    data.spawnedRegular >= regularQuota);
                int mode = useElite ? 3 + caste :
                    shouldFly(world, data.waveIndex) && world.rand.nextInt(4) == 0 ? 1 : 0;
                if (spawnNear(world, player, mode, data)) {
                    spawnedThisPulse++;
                    data.spawned++;
                    if (useElite) data.eliteSpawned[caste]++;
                    else data.spawnedRegular++;
                } else break; // Re-attempt next pulse; never fake successful spawns.
            }
        }
    }

    private static int eliteSpawnedTotal(BroodWaveData data) {
        int count = 0;
        for (int v : data.eliteSpawned) count += v;
        return count;
    }
    private static int eliteQuotaTotal(BroodWaveData data) {
        int sum = 0;
        for (int v : data.eliteQuotas) sum += v;
        return sum;
    }

    private static int nextElite(BroodWaveData data) {
        // Choose the least-completed caste relative to its quota.
        int best = -1;
        double completion = Double.MAX_VALUE;
        for (int i = 0; i < BroodEliteWaveRules.CASTES; ++i) {
            if (data.eliteSpawned[i] >= data.eliteQuotas[i]) continue;
            double progress = (double)data.eliteSpawned[i] / (double)data.eliteQuotas[i];
            if (progress < completion) { best = i; completion = progress; }
        }
        return best;
    }

    private static boolean shouldFly(World world, int waveIndex) {
        BigInteger stage = EvolutionData.get(world).getStage();
        return stage.compareTo(BigInteger.valueOf(BroodConfig.flyerUnlockStage)) >= 0 || waveIndex >= 3;
    }

    /** Spawn in a navigable ring on already loaded terrain near the targeted player's Y.
     * A heightmap-only algorithm put underground waves on cave roofs or distant hills.
     */
    private static boolean spawnNear(World world, EntityPlayer player, int mode, BroodWaveData data) {
        AxisAlignedBB area = player.boundingBox.expand(64D, 32D, 64D);
        int ground = world.getEntitiesWithinAABB(EntityParasite.class, area).size();
        int air = world.getEntitiesWithinAABB(EntityBroodFlier.class, area).size();
        if (ground + air >= BroodConfig.effectiveWaveCap()) {
            data.blockedByCap++;
            return false;
        }
        for (int attempt = 0; attempt < (mode == 2 ? 24 : 14); ++attempt) {
            double angle = world.rand.nextDouble() * Math.PI * 2D;
            int radius = 16 + world.rand.nextInt(19); // 16..34 within common view distance
            int x = MathHelper.floor_double(player.posX + Math.cos(angle) * radius);
            int z = MathHelper.floor_double(player.posZ + Math.sin(angle) * radius);
            if (!world.blockExists(x, 64, z)) continue;
            int y = findFloorNearPlayer(world, x, z, MathHelper.floor_double(player.posY));
            if (y < 2 || y > 246) continue;
            if (BroodWardRules.protects(world, x, y, z) ||
                BroodConfig.radiationStopsNests && BroodRadiationBridge.getRadiation(world, x, y, z)
                    >= BroodConfig.radiationFearThreshold) continue;
            Entity entity;
            if (mode == 1 || mode == 6) {
                if (!world.blockExists(x, y + 4, z) || !world.isAirBlock(x, y + 3, z)) continue;
                EntityBroodFlier flyer = mode == 6 ? new EntityBroodSkyreaper(world) : new EntityBroodFlier(world);
                flyer.setPosition(x + 0.5D, y + 2.5D, z + 0.5D);
                flyer.setSiegeTarget(player, data.debugWave);
                entity = flyer;
            } else if (mode >= 3 && mode <= 7) {
                if (!world.isAirBlock(x, y + 2, z) || !world.isAirBlock(x, y + 3, z)) continue;
                EntityBroodElite elite;
                if (mode == 3) elite = new EntityBroodElite.Ravager(world);
                else if (mode == 4) elite = new EntityBroodElite.Sporecaller(world);
                else if (mode == 5) elite = new EntityBroodElite.Ironmaw(world);
                else elite = new EntityBroodElite.Overmind(world);
                elite.setPosition(x + 0.5D, y, z + 0.5D);
                elite.prepareForWave();
                elite.setSiegeTarget(player, data.debugWave);
                entity = elite;
            } else if (mode == 2) {
                if (!world.isAirBlock(x, y + 2, z) || !world.isAirBlock(x, y + 3, z)) continue;
                EntityBroodCommander boss = new EntityBroodCommander(world);
                boss.setPosition(x + 0.5D, y, z + 0.5D);
                boss.setWaveLevel(data.waveIndex);
                boss.setSiegeTarget(player, data.debugWave);
                entity = boss;
            } else {
                EntityParasite parasite = new EntityParasite(world);
                parasite.setPosition(x + 0.5D, y, z + 0.5D);
                if (data.waveIndex >= 2 && world.rand.nextInt(5) == 0)
                    parasite.configureSpawnMorph(2);
                parasite.setSiegeTarget(player, data.debugWave);
                entity = parasite;
            }
            if (!world.checkNoEntityCollision(entity.boundingBox) ||
                !world.getCollidingBoundingBoxes(entity, entity.boundingBox).isEmpty()) continue;
            if (world.spawnEntityInWorld(entity)) return true;
        }
        data.failedPlacement++;
        return false;
    }

    /** Tries elevations close to the player first, so cave bases can be raided.
     * Does not place a mob in walls, water or other opaque blocks.
     */
    private static int findFloorNearPlayer(World world, int x, int z, int playerY) {
        int high = Math.min(245, playerY + 6);
        int low = Math.max(3, playerY - 12);
        for (int y = high; y >= low; --y) {
            if (world.blockExists(x, y + 3, z) &&
                world.getBlock(x, y - 1, z).getMaterial().isSolid() &&
                world.isAirBlock(x, y, z) && world.isAirBlock(x, y + 1, z) &&
                world.isAirBlock(x, y + 2, z)) return y;
        }
        // Terrain fallback only if the surface is near the player elevation.
        int surface = world.getHeightValue(x, z);
        if (Math.abs(surface - playerY) <= 18 && surface > 2 && surface < 245 &&
            world.blockExists(x, surface + 3, z) &&
            world.getBlock(x, surface - 1, z).getMaterial().isSolid() &&
            world.isAirBlock(x, surface, z) && world.isAirBlock(x, surface + 1, z) &&
            world.isAirBlock(x, surface + 2, z)) return surface;
        return -1;
    }
}
