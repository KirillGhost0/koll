package com.endlessbrood.common;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;

/** Visible wandering scouts in ACTIVE chunks, complementing vanilla hostile
 * spawns and remote nests. Never scans / generates unloaded land. */
public final class BroodPatrolTicker {
    @SubscribeEvent
    public void onWorldTick(TickEvent.WorldTickEvent event) {
        World world = event.world;
        if (world.isRemote || event.phase != TickEvent.Phase.END ||
            world.provider.dimensionId != 0 ||
            world.difficultySetting == EnumDifficulty.PEACEFUL ||
            !world.getGameRules().getGameRuleBooleanValue("doMobSpawning") ||
            BroodConfig.patrolLocalCap < 1 || BroodConfig.spawnWeight == 0 ||
            !BroodSpawnRules.patrolDue(world.getTotalWorldTime(), BroodConfig.effectivePatrolTicks())) return;
        BroodOutbreakData outbreak = BroodOutbreakData.get(world);
        if (!outbreak.graceExpired(world.getTotalWorldTime())) return;
        BigInteger stage = EvolutionData.get(world).getStage();
        int amount = BroodPressureRules.more(BroodSpawnRules.patrolSize(stage),
            BroodConfig.swarmPressure, 8);
        // One player from each area; co-op players together are NOT double-targeted.
        List<EntityPlayer> active = new ArrayList<EntityPlayer>();
        for (Object obj : world.playerEntities) {
            if (!(obj instanceof EntityPlayer)) continue;
            EntityPlayer player = (EntityPlayer) obj;
            if (player.isDead || player.capabilities.isCreativeMode ||
                !outbreak.naturalSpawnsAllowed(world, player.posX, player.posZ)) continue;
            boolean grouped = false;
            for (EntityPlayer representative : active)
                if (representative.getDistanceSqToEntity(player) < 96.0D * 96.0D) {
                    grouped = true; break;
                }
            if (!grouped && active.size() < 2) active.add(player);
        }
        for (EntityPlayer player : active) {
            AxisAlignedBB nearby = player.boundingBox.expand(64, 24, 64);
            int count = BroodLoadedEntities.find(world, EntityParasite.class, nearby).size() +
                        BroodLoadedEntities.find(world, EntityBroodFlier.class, nearby).size();
            for (int i = count; i < BroodConfig.effectivePatrolCap() && i < count + amount; ++i)
                if (!spawnScout(world, player, outbreak, stage)) break;
        }
    }

    private boolean spawnScout(World world, EntityPlayer player,
                               BroodOutbreakData outbreak, BigInteger stage) {
        for (int attempt = 0; attempt < 24; ++attempt) {
            double angle = world.rand.nextDouble() * Math.PI * 2D;
            // Old 40..63 radius often fell outside the server's loaded chunks.
            int distance = 19 + world.rand.nextInt(19);
            int x = MathHelper.floor_double(player.posX + Math.cos(angle) * distance);
            int z = MathHelper.floor_double(player.posZ + Math.sin(angle) * distance);
            if (!outbreak.naturalSpawnsAllowed(world, x, z) || !world.blockExists(x, 64, z)) continue;
            int y = world.getHeightValue(x, z);
            if (y < 48 || y > 200 || !world.blockExists(x, y + 3, z) ||
                !world.isAirBlock(x, y, z) || !world.isAirBlock(x, y + 1, z) ||
                !world.getBlock(x, y - 1, z).getMaterial().isSolid() ||
                BroodWardRules.protects(world, x, y, z) ||
                BroodRadiationBridge.getRadiation(world, x, y, z) >= BroodConfig.radiationFearThreshold)
                continue;
            EntityParasite mob = new EntityParasite(world);
            mob.setPosition(x + 0.5D, y, z + 0.5D);
            if (stage.compareTo(BigInteger.valueOf(12L)) >= 0 && world.rand.nextInt(4) == 0)
                mob.configureSpawnMorph(2);
            if (world.checkNoEntityCollision(mob.boundingBox) &&
                world.getCollidingBoundingBoxes(mob, mob.boundingBox).isEmpty())
                return world.spawnEntityInWorld(mob);
        }
        return false;
    }
}
