package test;
import com.endlessbrood.common.BroodFootstepRules;
public final class BroodFootstepSmoke {
  public static void main(String[] args) {
    assert BroodFootstepRules.shouldStomp(12,true,0.03);
    assert !BroodFootstepRules.shouldStomp(12,false,0.03);
    assert !BroodFootstepRules.shouldStomp(12,true,0.0);
    assert !BroodFootstepRules.shouldStomp(11,true,0.03);
    assert BroodFootstepRules.volumeAt(0,24) == 1F;
    assert BroodFootstepRules.volumeAt(24*24,24)==0F;
    assert BroodFootstepRules.pulse(0F)==1F;
    assert BroodFootstepRules.pulse(8F)==0F;
    System.out.println("PASS: grounded gait trigger, distance fade, short shake pulse");
  }
}
