package test;

import java.math.BigInteger;
import com.endlessbrood.common.BroodSiegeRules;

public final class BroodSiegeSmoke {
    private static final BigInteger HUNDRED = BigInteger.valueOf(100L);
    private static void require(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        require(BroodSiegeRules.allowed(HUNDRED, 10, true, true), "late-stage invasion active");
        require(!BroodSiegeRules.allowed(HUNDRED, 10, true, false), "home remains safe early");
        require(!BroodSiegeRules.allowed(HUNDRED, 10, false, true), "no invasion during grace");
        require(!BroodSiegeRules.allowed(BigInteger.valueOf(9), 10, true, true), "unlock stage");
        require(BroodSiegeRules.packSize(7, HUNDRED, 0, 36) == 11, "late-game packed siege");
        require(BroodSiegeRules.packSize(7, HUNDRED, 33, 36) == 3, "cap keeps TPS safe");
        require(BroodSiegeRules.packSize(7, HUNDRED, 40, 36) == 0, "full cap blocks spawns");
        require(BroodSiegeRules.packSize(7, BigInteger.ONE, 0, 36) == 7, "normal siege pack");
        System.out.println("PASS: BRUTAL siege readiness, late-stage scaling and population cap");
    }
}
