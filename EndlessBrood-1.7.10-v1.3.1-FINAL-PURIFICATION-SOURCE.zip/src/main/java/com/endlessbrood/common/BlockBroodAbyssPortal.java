package com.endlessbrood.common;

import com.endlessbrood.EndlessBrood;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.world.World;

/** A 2x2 walk-through membrane in the middle of the four corner anchors. */
public final class BlockBroodAbyssPortal extends Block {
    public BlockBroodAbyssPortal() {
        super(Material.portal);
        setBlockName("endlessbrood.abyssPortal");
        setBlockTextureName("endlessbrood:abyss_portal");
        setBlockUnbreakable();
        setResistance(6000000F);
        setLightLevel(.5F);
        setCreativeTab(CreativeTabs.tabBlock);
    }
    @Override public boolean isOpaqueCube() { return false; }
    @Override public boolean renderAsNormalBlock() { return true; }
    @Override public int getRenderBlockPass() { return 1; }
    @Override public AxisAlignedBB getCollisionBoundingBoxFromPool(World w,int x,int y,int z) { return null; }
    @Override public void onEntityCollidedWithBlock(World w,int x,int y,int z,Entity entity) {
        if (!w.isRemote && entity instanceof EntityPlayerMP)
            BroodRealmTravel.travel((EntityPlayerMP)entity);
    }
    // Portal membrane is immutable by players and by parasite mining. Removed with an anchor instead.
    @Override public void onNeighborBlockChange(World world,int x,int y,int z,Block changed) {
        if(world.isRemote || world.provider.dimensionId!=0) return;
        // If any corner gets broken, BlockBroodPortalAnchor.breakBlock removes nearby membranes.
    }
}
