package com.endlessbrood.common;

import com.endlessbrood.EndlessBrood;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import net.minecraft.world.World;

/** Four differently marked anchors occupy the four corners of a horizontal 4x4 square. */
public final class BlockBroodPortalAnchor extends Block {
    private IIcon[] faces = new IIcon[4];
    public BlockBroodPortalAnchor() {
        super(Material.rock);
        setBlockName("endlessbrood.abyssAnchor");
        setHardness(6F);
        setResistance(120F);
        setCreativeTab(CreativeTabs.tabBlock);
    }
    @Override public void registerBlockIcons(IIconRegister icons) {
        for (int i = 0; i < 4; i++) faces[i] = icons.registerIcon("endlessbrood:abyss_anchor_" + i);
        blockIcon = faces[0];
    }
    @Override public IIcon getIcon(int side, int meta) { return faces[meta & 3]; }
    @Override public int damageDropped(int meta) { return meta & 3; }
    @Override @SuppressWarnings({"rawtypes", "unchecked"})
    public void getSubBlocks(Item item, CreativeTabs tab, List list) {
        for (int i=0;i<4;i++) list.add(new ItemStack(item, 1, i));
    }
    @Override public void onBlockAdded(World world, int x, int y, int z) {
        if (!world.isRemote && world.provider.dimensionId == 0)
            BroodPortalPattern.tryActivate(world, x, y, z);
    }
    @Override public void onBlockPlacedBy(World world, int x, int y, int z,
                                         net.minecraft.entity.EntityLivingBase placer, ItemStack stack) {
        if (!world.isRemote && world.provider.dimensionId == 0)
            BroodPortalPattern.tryActivate(world, x, y, z);
    }
    @Override public void breakBlock(World world, int x, int y, int z, Block oldBlock, int oldMeta) {
        if (!world.isRemote && world.provider.dimensionId == 0)
            BroodPortalPattern.removeNearbyPortal(world, x, y, z);
        super.breakBlock(world, x, y, z, oldBlock, oldMeta);
    }
}
