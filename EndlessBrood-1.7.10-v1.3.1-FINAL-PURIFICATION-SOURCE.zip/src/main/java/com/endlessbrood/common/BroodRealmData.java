package com.endlessbrood.common;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraft.world.WorldSavedData;

/** One fortress encounter per dimension save; prevents duplicate bosses after reload. */
public final class BroodRealmData extends WorldSavedData {
    private static final String KEY="endlessbrood_abyss_fortress";
    public boolean fortressAwakened;
    public BroodRealmData() { super(KEY); }
    public BroodRealmData(String n) { super(n); }
    public static BroodRealmData get(World w) {
        BroodRealmData r=(BroodRealmData)w.loadItemData(BroodRealmData.class,KEY);
        if(r==null) {r=new BroodRealmData(KEY);w.setItemData(KEY,r);}
        return r;
    }
    @Override public void readFromNBT(NBTTagCompound nbt) { fortressAwakened=nbt.getBoolean("Awakened"); }
    @Override public void writeToNBT(NBTTagCompound nbt) { nbt.setBoolean("Awakened",fortressAwakened); }
}
