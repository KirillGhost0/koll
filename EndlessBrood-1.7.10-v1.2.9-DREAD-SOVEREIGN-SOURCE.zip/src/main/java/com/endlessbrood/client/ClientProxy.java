package com.endlessbrood.client;

import com.endlessbrood.common.CommonProxy;
import com.endlessbrood.common.EntityParasite;
import com.endlessbrood.common.EntityBroodFlier;
import com.endlessbrood.common.EntityBroodCommander;
import com.endlessbrood.common.EntityBroodElite;
import com.endlessbrood.common.EntityBroodSkyreaper;
import cpw.mods.fml.client.registry.RenderingRegistry;

public class ClientProxy extends CommonProxy {
    @Override
    public void registerRenderers() {
        RenderingRegistry.registerEntityRenderingHandler(EntityParasite.class, new RenderParasite());
        RenderingRegistry.registerEntityRenderingHandler(EntityBroodFlier.class, new RenderBroodFlier());
        RenderingRegistry.registerEntityRenderingHandler(EntityBroodCommander.class, new RenderBroodCommander());
        RenderingRegistry.registerEntityRenderingHandler(EntityBroodElite.Ravager.class, new RenderBroodElite());
        RenderingRegistry.registerEntityRenderingHandler(EntityBroodElite.Sporecaller.class, new RenderBroodElite());
        RenderingRegistry.registerEntityRenderingHandler(EntityBroodElite.Ironmaw.class, new RenderBroodElite());
        RenderingRegistry.registerEntityRenderingHandler(EntityBroodSkyreaper.class, new RenderBroodSkyreaper());
        RenderingRegistry.registerEntityRenderingHandler(EntityBroodElite.Overmind.class, new RenderBroodElite());
    }
}
