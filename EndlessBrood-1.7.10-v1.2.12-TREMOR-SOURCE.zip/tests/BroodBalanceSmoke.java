package test;

import com.endlessbrood.common.BroodThreatTuning;
import com.endlessbrood.common.BroodLootRules;
import java.util.Random;

public final class BroodBalanceSmoke {
    private static void check(boolean ok, String label) {
        if (!ok) throw new AssertionError(label);
    }
    public static void main(String[] args) {
        // 1.2.6: 48 first wave and 96 fifth wave with pressure=3, multiplier=2.
        check(BroodThreatTuning.waveGoal(12, 3, 2, 80) == 38, "wave 1: 48 -> 38");
        check(BroodThreatTuning.waveGoal(24, 3, 2, 80) == 77, "wave 5: 96 -> 77");
        check(BroodThreatTuning.waveGoal(24, 3, 2, 100) == 96, "fully restored waves");
        check(BroodThreatTuning.waveGoal(1000, 4, 4, 80) == 102, "hard capped: 128 -> 102");
        check(BroodThreatTuning.waveGoal(24, 3, 2, 0) == 0, "zero percent lower bound");
        check(BroodLootRules.countKept(0, 20, new Random(1L)) == 0, "no negative drops");
        check(BroodLootRules.countKept(10, 0, new Random(1L)) == 0, "zero loot");
        check(BroodLootRules.countKept(10, 100, new Random(1L)) == 10, "old loot level");
        Random random = new Random(112358L);
        int kept = BroodLootRules.countKept(100000, 20, random);
        check(kept > 19300 && kept < 20700, "one-fifth average item drop rate");
        System.out.println("PASS: -20% wave total, 1/5 expected mob item drops, bounds");
    }
}
