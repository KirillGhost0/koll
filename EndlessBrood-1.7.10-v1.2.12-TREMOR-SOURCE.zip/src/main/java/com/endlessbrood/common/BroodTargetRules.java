package com.endlessbrood.common;

/** Pure arithmetic for inexpensive, deterministic brood target selection. */
public final class BroodTargetRules {
    private BroodTargetRules() { }

    /** Always sense very close prey, otherwise require direct line of sight. */
    public static boolean canDetect(double distanceSq, int range, int closeRange, boolean visible) {
        return range > 0 && distanceSq <= (double) range * range &&
            (distanceSq <= (double) closeRange * closeRange || visible);
    }

    /** Avoid oscillating between equally distant victims while allowing close threats to win. */
    public static boolean shouldSwitch(double candidateSq, double currentSq) {
        return candidateSq < currentSq * 0.7D;
    }
}
