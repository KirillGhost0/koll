package com.endlessbrood.common; public class EntityBroodFlier extends net.minecraft.entity.Entity { public int getVisualTier(){return 0;} public int getDivePhase(){return 0;} }
