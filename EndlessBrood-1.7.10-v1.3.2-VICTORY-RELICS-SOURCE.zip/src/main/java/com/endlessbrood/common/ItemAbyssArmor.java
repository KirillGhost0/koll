package com.endlessbrood.common;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;

/** Post-victory set: one seed of Abyssal essence per piece. */
public final class ItemAbyssArmor extends ItemArmor {
    public ItemAbyssArmor(ArmorMaterial mat, int slot, String name) {
        super(mat, 0, slot);
        setUnlocalizedName("endlessbrood." + name);
        setTextureName("endlessbrood:" + name);
        setCreativeTab(CreativeTabs.tabCombat);
    }
    @Override public String getArmorTexture(ItemStack stack, Entity entity, int slot, String type) {
        return "endlessbrood:textures/models/armor/abyss_layer_" + (slot == 2 ? "2" : "1") + ".png";
    }
}
