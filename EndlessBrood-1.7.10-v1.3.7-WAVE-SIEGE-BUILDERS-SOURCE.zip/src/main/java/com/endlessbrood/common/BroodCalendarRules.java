package com.endlessbrood.common;

/** World-calendar scheduling and bounded environmental pressure. Never loads chunks. */
public final class BroodCalendarRules {
    private BroodCalendarRules() { }
    /** Uses worldTime so sleeping and /time set advance the visible Minecraft day. */
    public static long day(long worldTime) { return Math.max(0L, worldTime) / 24000L; }
    public static int waveCycle(long worldTime, int intervalDays) {
        long cycle = day(worldTime) / Math.max(1, intervalDays);
        return (int)Math.min((long)Integer.MAX_VALUE, cycle);
    }
    /** If a mod is installed on a milestone day, the wave is eligible immediately. */
    public static int initialCompletedCycle(long worldTime, int intervalDays) {
        int period = Math.max(1, intervalDays);
        long day = day(worldTime);
        int cycle = waveCycle(worldTime, period);
        return day > 0L && day % period == 0L ? Math.max(0, cycle - 1) : cycle;
    }
    public static int countdownDays(long worldTime, int intervalDays) {
        long day = day(worldTime);
        int period = Math.max(1, intervalDays);
        return (int)(period - day % period);
    }
    /** Mycelium-like contagion becomes steadily more likely, never >1 action per block tick. */
    public static int soilDivisor(int base, long calendarDay) {
        int acceleration = calendarDay >= 60 ? 4 : calendarDay >= 30 ? 3 :
            calendarDay >= 20 ? 2 : calendarDay >= 10 ? 1 : 0;
        return Math.max(2, base - acceleration);
    }
    /** Late worlds have more scouting attempts, but retain a strict lower tick bound. */
    public static int patrolInterval(int base, long calendarDay) {
        int percent = calendarDay >= 60 ? 40 : calendarDay >= 30 ? 55 :
            calendarDay >= 20 ? 70 : calendarDay >= 10 ? 85 : 100;
        return Math.max(400, (int)Math.min(Integer.MAX_VALUE, (long)base * percent / 100L));
    }
    /** Small additive increase, capped so transformations never become guaranteed. */
    public static double infectionChance(double baseline, long calendarDay) {
        double extra = calendarDay >= 100 ? 0.25D : calendarDay >= 60 ? 0.20D :
            calendarDay >= 30 ? 0.14D : calendarDay >= 20 ? 0.08D :
            calendarDay >= 10 ? 0.03D : 0D;
        return Math.min(0.95D, Math.max(0D, baseline) + extra);
    }
    public static int soilInfectionDivisor(int baseline, long calendarDay) {
        return Math.max(20, baseline - (int)Math.min(90L, Math.max(0L, calendarDay) * 2L));
    }
    public static int extraScouts(long calendarDay) {
        return (int)Math.min(4L, Math.max(0L, calendarDay) / 12L);
    }
    public static boolean mixHerd(long calendarDay, int mixDay, int replaceDay) {
        return calendarDay >= mixDay && calendarDay < replaceDay;
    }
    public static boolean replaceHerd(long calendarDay, int replaceDay) {
        return calendarDay >= replaceDay;
    }
}
