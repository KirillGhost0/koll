package test;

import com.endlessbrood.common.BroodThreatTuning;

public final class BroodThreatTuningSmoke {
    public static void main(String[] args) {
        check(BroodThreatTuning.waveGoal(24, 3, 2) == 96, "fifth wave 96 mobs");
        check(BroodThreatTuning.waveGoal(12, 3, 2) == 48, "first wave 48 mobs");
        check(BroodThreatTuning.waveGoal(128, 4, 4) == 128, "wave cap");
        check(BroodThreatTuning.expandedLocalCap(28, 3, 70, 24, 96) == 80, "wave local cap");
        check(BroodThreatTuning.expandedLocalCap(12, 3, 36, 10, 56) == 34, "natural local cap");
        check(BroodThreatTuning.reinforcementPulseSize(3) == 14, "wave pulse size");
        check(Math.abs(BroodThreatTuning.boostedSpeed(.253D, 1.18D) - .29854D) < .00001D,
              "near sprint speed");
        check(BroodThreatTuning.playerInLongRange(150 * 150, 150), "150-block target");
        check(!BroodThreatTuning.playerInLongRange(151 * 151, 150), "151-block exclusion");
        System.out.println("PASS: Wavefix2 150-block player detection, more mobs and +18% speed");
    }
    private static void check(boolean actual, String name) {
        if (!actual) throw new AssertionError(name);
    }
}
