package com.endlessbrood.common;

import com.endlessbrood.EndlessBrood;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

/** Server-side full-set bonus. Bounded periodic check, not per-entity AI. */
public final class BroodVictoryEquipment {
    @SubscribeEvent public void playerTick(TickEvent.PlayerTickEvent event) {
        if(event.phase != TickEvent.Phase.END || event.player.worldObj.isRemote ||
           event.player.ticksExisted % 80 != 0) return;
        EntityPlayer player=event.player;
        if(!wearingFullSet(player)) return;
        player.addPotionEffect(new PotionEffect(Potion.nightVision.id, 360, 0, true));
        player.addPotionEffect(new PotionEffect(Potion.fireResistance.id, 160, 0, true));
    }
    private static boolean wearingFullSet(EntityPlayer player) {
        ItemStack boots =player.getCurrentArmor(0);
        ItemStack legs  =player.getCurrentArmor(1);
        ItemStack chest =player.getCurrentArmor(2);
        ItemStack helmet=player.getCurrentArmor(3);
        return boots!=null && boots.getItem()==EndlessBrood.abyssBoots &&
            legs!=null && legs.getItem()==EndlessBrood.abyssLegs &&
            chest!=null && chest.getItem()==EndlessBrood.abyssChest &&
            helmet!=null && helmet.getItem()==EndlessBrood.abyssHelmet;
    }
}
