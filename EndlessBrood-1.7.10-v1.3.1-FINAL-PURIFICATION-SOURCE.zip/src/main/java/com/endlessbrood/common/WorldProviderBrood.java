package com.endlessbrood.common;

import net.minecraft.world.WorldProvider;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.biome.WorldChunkManagerHell;
import net.minecraft.world.chunk.IChunkProvider;

/** A gloomy independent sky realm; its chunks are generated as floating infested islands. */
public final class WorldProviderBrood extends WorldProvider {
    @Override public void registerWorldChunkManager() {
        worldChunkMgr = new WorldChunkManagerHell(BiomeGenBase.sky, 0.1F);
        dimensionId = BroodRealmTravel.dimensionId;
        hasNoSky = false;
    }
    @Override public IChunkProvider createChunkGenerator() {
        return new ChunkProviderBrood(worldObj, worldObj.getSeed());
    }
    @Override public String getDimensionName() { return "Parasitic Abyss"; }
    @Override public boolean canRespawnHere() { return false; }
    @Override public boolean isSurfaceWorld() { return false; }
    @Override public float calculateCelestialAngle(long time, float partial) { return 0.80F; }
    @Override public boolean canDoLightning(net.minecraft.world.chunk.Chunk chunk) { return false; }
    @Override public boolean canDoRainSnowIce(net.minecraft.world.chunk.Chunk chunk) { return false; }
}
