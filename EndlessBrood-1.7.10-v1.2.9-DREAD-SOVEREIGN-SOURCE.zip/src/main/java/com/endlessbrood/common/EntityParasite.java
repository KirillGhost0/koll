package com.endlessbrood.common;

import java.math.BigInteger;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.MathHelper;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

/** Original parasite with mutations and deliberately limited, slow tunnelling AI. */
public class EntityParasite extends EntityMob {
    private int gene = ParasiteGenes.STANDARD;
    private boolean geneAssigned;
    private int genome;
    private int lastAppliedMorph = -1;
    // Position of the nest that spawned this parasite; only stored for nest-born mobs.
    private boolean hasBroodHome;
    private int broodHomeX;
    private int broodHomeY;
    private int broodHomeZ;
    private long nextDefenseAlarmTick;
    private int dreadStareTicks;
    private int horrorPoseTicks;
    private long nextDreadStareAt;
    private long nextSwarmFlankTick;



    public void setBroodHome(int x, int y, int z) {
        if (worldObj.isRemote) return;
        hasBroodHome = true;
        broodHomeX = x;
        broodHomeY = y;
        broodHomeZ = z;
    }

    public void clearBroodHome() { hasBroodHome = false; }
    public boolean hasBroodHome() { return hasBroodHome; }
    public int getBroodHomeX() { return broodHomeX; }
    public int getBroodHomeY() { return broodHomeY; }
    public int getBroodHomeZ() { return broodHomeZ; }

    /** Called when an already-spawned leader is attacked. Rate-limited locally. */
    @SuppressWarnings("unchecked")
    public void raiseLeaderDefenseAlarm(EntityLivingBase attacker) {
        if (worldObj.isRemote || !BroodConfig.leaderDefenseAlarm ||
            getMorph() != BroodColonyRules.QUEEN_MORPH ||
            attacker == null || attacker.isDead || attacker instanceof EntityParasite ||
            (attacker instanceof EntityPlayer &&
             ((EntityPlayer) attacker).capabilities.isCreativeMode)) return;
        long now = worldObj.getTotalWorldTime();
        if (now < nextDefenseAlarmTick) return;
        nextDefenseAlarmTick = now + 200L;
        int radius = BroodConfig.leaderDefenseRadius;
        List<EntityParasite> nearby = worldObj.getEntitiesWithinAABB(EntityParasite.class,
            boundingBox.expand(radius, 6.0D, radius));
        int assigned = 0;
        for (EntityParasite guard : nearby) {
            if (guard == this || guard.isDead || guard.getAttackTarget() != null ||
                getDistanceSqToEntity(guard) > (double) radius * radius) continue;
            guard.setAttackTarget(attacker);
            if (++assigned >= BroodConfig.leaderDefenseLimit) break;
        }
    }

    /** DataWatcher synchronizes appearance for multiplayer clients. */
    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataWatcher.addObject(20, Byte.valueOf((byte) 0)); // body type
        this.dataWatcher.addObject(21, Byte.valueOf((byte) 0)); // genetic adaptation
        this.dataWatcher.addObject(22, Byte.valueOf((byte) 0)); // stackable extra traits
        this.dataWatcher.addObject(23, Byte.valueOf((byte) 0)); // sync horror pose to clients
    }

    public int getMorph() {
        return this.dataWatcher.getWatchableObjectByte(20);
    }

    public int getGene() {
        return this.dataWatcher.getWatchableObjectByte(21);
    }

    public int getGenome() {
        return this.dataWatcher.getWatchableObjectByte(22) & 15;
    }

    /** 0 idle, 1 tracking, 2 stalking/ambush windup, 3 roar. Server authoritative. */
    public int getHorrorPose() { return this.dataWatcher.getWatchableObjectByte(23); }
    private void setHorrorPose(int pose) {
        if (getHorrorPose() != pose)
            this.dataWatcher.updateObject(23, Byte.valueOf((byte) pose));
    }

    private void setMorph(int morph) {
        this.dataWatcher.updateObject(20, Byte.valueOf((byte) morph));
        updateSizeForMorph();
    }

    /** Called by custom spawn eggs on the authoritative server before spawning. */
    public void configureSpawnMorph(int morph) {
        if (this.worldObj.isRemote) return;
        BigInteger stage = EvolutionData.get(this.worldObj).getStage();
        gene = ParasiteGenes.roll(stage, this.rand);
        genome = ParasiteGenome.roll(stage, this.rand);
        this.dataWatcher.updateObject(22, Byte.valueOf((byte) genome));
        this.dataWatcher.updateObject(21, Byte.valueOf((byte) gene));
        setMorph(morph >= 0 && morph <= BroodColonyRules.QUEEN_MORPH ? morph : 0);
        geneAssigned = true;
        updateAttributesFromEvolution();
    }

    private void updateSizeForMorph() {
        int kind = getMorph();
        if (lastAppliedMorph == kind) return;
        lastAppliedMorph = kind;
        // Modest hitboxes to avoid getting large models stuck in caves.
        if (kind == 5) setSize(1.45F, 2.1F);
        else if (kind == 4) setSize(1.9F, 2.5F);
        else if (kind == 2) setSize(1.0F, 1.5F);
        else if (kind == 1) setSize(0.7F, 0.75F);
        else setSize(0.85F, 1.2F);
    }
    // Wave lock holds the raid target even when another animal is closer.
    private EntityPlayer waveTarget;
    private long waveTargetExpiry;
    private boolean waveDebugCreative;

    public void setSiegeTarget(EntityPlayer player, boolean allowCreativeForTest) {
        if (worldObj.isRemote || player == null) return;
        waveTarget = player;
        waveTargetExpiry = worldObj.getTotalWorldTime() + 7200L; // 6 real minutes
        waveDebugCreative = allowCreativeForTest;
        clearBroodHome();
        setAttackTarget(player);
    }

    private boolean hasValidWaveTarget() {
        return waveTarget != null && waveTarget.isEntityAlive() && !waveTarget.isDead &&
            waveTarget.worldObj == worldObj &&
            (waveDebugCreative || !waveTarget.capabilities.isCreativeMode) &&
            worldObj.getTotalWorldTime() < waveTargetExpiry &&
            getDistanceSqToEntity(waveTarget) < 192D * 192D;
    }

    /** Pack signal, without taking control away from a valid siege lock. */
    public boolean acceptSwarmTarget(EntityLivingBase victim) {
        if (worldObj.isRemote || !BroodConfig.swarmTacticsEnabled || victim == null ||
            !victim.isEntityAlive() || victim.worldObj != worldObj ||
            victim instanceof EntityParasite || victim instanceof EntityBroodFlier ||
            victim instanceof EntityPlayer && ((EntityPlayer)victim).capabilities.isCreativeMode ||
            ticksExisted < radiationAvoidUntilTick || hasValidWaveTarget()) return false;
        double max = victim instanceof EntityPlayer ?
            (double) BroodConfig.distantPlayerDetectionRange : 36D;
        double distance = getDistanceSqToEntity(victim);
        if (distance > max * max) return false;
        EntityLivingBase current = getAttackTarget();
        if (current != null && current.isEntityAlive() &&
            !BroodSwarmRules.shouldAcceptSharedTarget(distance, getDistanceSqToEntity(current))) return false;
        setAttackTarget(victim);
        return true;
    }

    private void flankPrey(EntityLivingBase victim) {
        if (!BroodConfig.swarmTacticsEnabled || victim == null || !victim.isEntityAlive() ||
            getMorph() == 2 || getMorph() == 4 || getMorph() == 5 ||
            worldObj.getTotalWorldTime() < nextSwarmFlankTick || !onGround) return;
        // All waves flank. Regular hunts unlock after the first evolved colonies.
        if (!hasValidWaveTarget() && EvolutionData.get(worldObj).getStage().compareTo(
                BigInteger.valueOf(BroodConfig.swarmFlankUnlockStage)) < 0) return;
        double distance = getDistanceSqToEntity(victim);
        if (!BroodSwarmRules.shouldFlank(distance, getEntityId(), canEntityBeSeen(victim))) return;
        nextSwarmFlankTick = worldObj.getTotalWorldTime() + BroodConfig.swarmFlankTicks +
            (getEntityId() & 7);
        double[] position = BroodSwarmRules.flankPoint(victim.posX, victim.posZ,
            victim.rotationYaw, getEntityId(), BroodConfig.swarmGroundFlankRadius);
        int cx = MathHelper.floor_double(position[0]);
        int cz = MathHelper.floor_double(position[1]);
        // Never request paths to a chunk that was unloaded; retain vanilla melee AI
        // if the chosen side is blocked, unwalkable or outside the loaded area.
        if (!worldObj.blockExists(cx, MathHelper.floor_double(victim.posY), cz)) return;
        getNavigator().tryMoveToXYZ(position[0], victim.posY, position[1], 1.16D);
    }

    private int radiationAvoidUntilTick;
    private int digX;
    private int digY;
    private int digZ;
    private int digProgress;
    private boolean digging;

    public EntityParasite(World world) {
        super(world);
        this.setSize(0.85F, 1.2F);
        this.tasks.addTask(0, new EntityAISwimming(this));
        this.tasks.addTask(2, new EntityAIAttackOnCollide(this, 1.19D, true));
        // Optional bounded navigation toward a registered village on late-stage nights.
        this.tasks.addTask(3, new EntityAIBroodNestGuard(this));
        this.tasks.addTask(4, new EntityAIBroodVillageRaid(this));
        this.tasks.addTask(5, new EntityAIWander(this, 0.8D));
        this.tasks.addTask(6, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
        this.tasks.addTask(7, new EntityAILookIdle(this));
        // Retaliation stays immediate. Ordinary hunting is one bounded, staggered
        // server-side scan across ALL living prey, so target priorities cannot
        // make a nearby cow invisible just because a player is farther away.
        this.targetTasks.addTask(1, new EntityAIHurtByTarget(this, true));
    }

    @Override
    protected boolean canDespawn() {
        return !BroodConfig.parasitesPersistent && super.canDespawn();
    }

    @Override
    protected boolean isAIEnabled() {
        return true;
    }

    @Override
    protected String getLivingSound() {
        if (!BroodConfig.horrorSoundsEnabled) return "mob.spider.say";
        int morph = getMorph();
        return morph == 1 ? "endlessbrood:chitter" :
            morph == 4 || morph == 5 ? "endlessbrood:groan" : "endlessbrood:hiss";
    }

    @Override
    protected String getHurtSound() {
        return BroodConfig.horrorSoundsEnabled ? "endlessbrood:hiss" : "mob.spider.say";
    }

    @Override
    protected String getDeathSound() {
        return BroodConfig.horrorSoundsEnabled ? "endlessbrood:death" : "mob.spider.death";
    }

    @Override
    public int getTalkInterval() { return 260; }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(20.0D);
        this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.23D * BroodConfig.broodMovementSpeedMultiplier);
        this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(3.0D);
        this.getEntityAttribute(SharedMonsterAttributes.followRange)
            .setBaseValue(BroodConfig.distantPlayerDetectionRange);
    }

    @Override
    public boolean getCanSpawnHere() {
        if (!super.getCanSpawnHere()) return false;
        BroodOutbreakData outbreak = BroodOutbreakData.get(worldObj);
        if (!outbreak.naturalSpawnsAllowed(worldObj, posX, posZ)) return false;
        boolean ward = BroodConfig.wardsBlockNaturalSpawns && BroodWardRules.protects(worldObj,
            MathHelper.floor_double(posX), MathHelper.floor_double(posY),
            MathHelper.floor_double(posZ));
        if (BroodConfig.wardsBlockNaturalSpawns && ward) return false;
        return this.worldObj.getEntitiesWithinAABB(EntityParasite.class,
            this.boundingBox.expand(24.0D, 12.0D, 24.0D)).size() < BroodConfig.effectiveLocalPopulationLimit();
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        updateSizeForMorph(); // Also runs client-side after DataWatcher updates.
        if (this.worldObj.isRemote) return;
        if (!geneAssigned) {
            BigInteger stage = EvolutionData.get(this.worldObj).getStage();
            gene = ParasiteGenes.roll(stage, this.rand);
            genome = ParasiteGenome.roll(stage, this.rand);
            this.dataWatcher.updateObject(21, Byte.valueOf((byte) gene));
            this.dataWatcher.updateObject(22, Byte.valueOf((byte) genome));
            // Both early-game stalkers and scuttlers have unique 3D meshes.
            // More heavily mutated bodies unlock as the world evolves.
            int morph = rand.nextInt(100) < 42 ? 1 : 0;
            if (stage.compareTo(BigInteger.valueOf(3)) >= 0 && rand.nextInt(8) == 0) morph = 2;
            if (stage.compareTo(BigInteger.valueOf(10)) >= 0 && rand.nextInt(6) == 0) morph = 3;
            setMorph(morph);
            geneAssigned = true;
            updateAttributesFromEvolution();
        }
        // Actual HBM chunk radiation (optional integration): flee, take damage,
        // and skip hunting while attempting escape. Does not load other chunks.
        if (BroodConfig.radiationFear && (this.ticksExisted + this.getEntityId()) %
            BroodConfig.radiationPulseTicks == 0 && BroodRadiationBehavior.pulse(this)) {
            radiationAvoidUntilTick = this.ticksExisted + BroodConfig.radiationPulseTicks + 5;
        }
        boolean fleeingRadiation = this.ticksExisted < radiationAvoidUntilTick;
        if (!hasValidWaveTarget()) waveTarget = null;
        if (!fleeingRadiation && waveTarget != null) {
            if (getAttackTarget() != waveTarget) setAttackTarget(waveTarget);
            // A* may fail on its first pass when the wave arrives; keep retrying.
            // Do not run an expensive path request every tick.
            double targetDistance = getDistanceSqToEntity(waveTarget);
            // Throttle long-range route searches; a 150-block full A* every second
            // across dozens of entities would overwhelm servers running NTM.
            int retry = targetDistance > 64D * 64D ? 100 : 35;
            if ((ticksExisted + getEntityId()) % retry == 0 &&
                (getNavigator().noPath() || targetDistance > 25D * 25D)) {
                getNavigator().tryMoveToEntityLiving(waveTarget, 1.24D);
            }
        }
        if (fleeingRadiation && this.getAttackTarget() != null) this.setAttackTarget(null);
        if (!fleeingRadiation && BroodConfig.scuttlerPounce && getMorph() == 1 &&
            (this.ticksExisted + this.getEntityId()) % 120 == 0) pounceAtPrey();
        if (!fleeingRadiation && getMorph() == BroodColonyRules.QUEEN_MORPH &&
            (this.ticksExisted + this.getEntityId()) % BroodConfig.leaderRallyTicks == 0) {
            rallyNearbyBrood();
        }
        if (!fleeingRadiation && BroodConfig.colossusRoar && getMorph() == 4 &&
            (this.ticksExisted + this.getEntityId()) % 200 == 0) colossusRoar();
        if (this.ticksExisted % 100 == 0 && (genome & ParasiteGenome.REGENERATION) != 0 &&
            this.getHealth() > 0.0F && this.getHealth() < this.getMaxHealth()) {
            this.heal((float) Math.min(2.0D, this.getMaxHealth() * 0.015D));
        }
        // A search every 20 ticks by default (staggered using entity ID) makes
        // prey 5 blocks away visible to the AI within ~1 second, without an
        // expensive per-tick scan when playing together with HBM NTM.
        if (!fleeingRadiation && (this.ticksExisted + this.getEntityId()) %
            Math.max(5, BroodConfig.aggressionScanTicks) == 0) {
            acquireNearbyPrey();
        }
        if (!fleeingRadiation && (this.ticksExisted + this.getEntityId()) % 160 == 0 && getAttackTarget() == null) {
            shareColonyTarget();
        }
        if ((this.ticksExisted + this.getEntityId()) % 200 == 1) {
            updateAttributesFromEvolution();
        }
        if (!fleeingRadiation && this.ticksExisted % 10 == 0) {
            tryDigTowardVictim();
        }
        // Share current prey with a small nearby pack, staggering checks across mobs.
        // Coordination cannot create extra mobs or damage protected HBM blocks.
        if (!fleeingRadiation && BroodConfig.swarmTacticsEnabled &&
            (ticksExisted + getEntityId()) % BroodConfig.swarmSignalTicks == 0 &&
            getAttackTarget() != null && getAttackTarget().isEntityAlive()) {
            BroodSwarmCoordinator.alert(this, getAttackTarget());
        }
        if (!fleeingRadiation && (ticksExisted + getEntityId()) % 20 == 0)
            flankPrey(getAttackTarget());
        // Short server-authoritative feint; no global scans or forced chunk loads.
        updateDreadStalking(fleeingRadiation);
    }

    /** Stalkers briefly freeze and stare before a rush. One small vector impulse,
     *  never an unlimited speed boost. Siege targets keep their existing pursuit.
     *  A watcher byte drives the multiplayer-visible animation only.
     */
    private void updateDreadStalking(boolean fleeingRadiation) {
        if (horrorPoseTicks > 0) --horrorPoseTicks;
        EntityLivingBase prey = getAttackTarget();
        if (fleeingRadiation || prey == null || !prey.isEntityAlive()) {
            dreadStareTicks = 0;
            setHorrorPose(0);
            return;
        }
        if (dreadStareTicks > 0) {
            --dreadStareTicks;
            this.getNavigator().clearPathEntity();
            this.motionX *= 0.30D;
            this.motionZ *= 0.30D;
            this.getLookHelper().setLookPositionWithEntity(prey, 45.0F, 40.0F);
            setHorrorPose(2);
            if (dreadStareTicks == 0 && prey.isEntityAlive()) {
                double dx = prey.posX - posX, dz = prey.posZ - posZ;
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > 0.01D && this.onGround && this.canEntityBeSeen(prey)) {
                    this.motionX += 0.28D * dx / d;
                    this.motionZ += 0.28D * dz / d;
                    this.motionY = Math.max(motionY, 0.17D);
                    this.velocityChanged = true;
                }
                horrorPoseTicks = 12;
            }
            return;
        }
        if (horrorPoseTicks > 0) {
            setHorrorPose(2);
            return;
        }
        setHorrorPose(1);
        // Only one type, only an ordinary hunt, and at most ~once per 16 seconds.
        if (!BroodConfig.horrorAmbushEnabled || getMorph() != 0 ||
            hasValidWaveTarget() || !(prey instanceof EntityPlayer) ||
            !this.onGround || worldObj.getTotalWorldTime() < nextDreadStareAt ||
            this.ticksExisted < 60) return;
        double distance = getDistanceSqToEntity(prey);
        if (distance < 36D || distance > 225D || !canEntityBeSeen(prey)) return;
        nextDreadStareAt = worldObj.getTotalWorldTime() +
            BroodConfig.horrorAmbushCooldownTicks + rand.nextInt(100);
        dreadStareTicks = 12;
        setHorrorPose(2);
        if (BroodConfig.horrorSoundsEnabled)
            worldObj.playSoundAtEntity(this, "endlessbrood:growl", 0.85F, 0.83F);
    }

    /** Decide what to hunt using one proximity-based search for all living mobs.
     *  Only loaded, nearby entities are examined; this does not load chunks.
     *  Other Endless Brood parasites and creative-mode players are never prey.
     */
    @SuppressWarnings("unchecked")
    private void acquireNearbyPrey() {
        if (this.worldObj.isRemote) return;
        if (hasValidWaveTarget()) {
            if (getAttackTarget() != waveTarget) setAttackTarget(waveTarget);
            return;
        }
        int mobRadius = Math.max(8, BroodConfig.aggressionRange);
        int playerRadius = Math.max(mobRadius, BroodConfig.distantPlayerDetectionRange);
        int near = Math.min(mobRadius, Math.max(3, BroodConfig.aggressionCloseRadius));
        double maxSq = (double) playerRadius * playerRadius;
        EntityLivingBase current = this.getAttackTarget();
        if (!isPrey(current) || this.getDistanceSqToEntity(current) > maxSq * 2.25D) {
            if (current != null) this.setAttackTarget(null);
            current = null;
        }

        // Once the parasite is already fighting in melee, do not flicker
        // between targets each time a second victim walks past.
        if (current != null && this.getDistanceSqToEntity(current) <= 16.0D) return;

        EntityLivingBase chosen = current;
        double chosenDistance = current == null ? Double.MAX_VALUE :
            this.getDistanceSqToEntity(current);
        List<EntityLivingBase> candidates = this.worldObj.getEntitiesWithinAABB(
            EntityLivingBase.class, this.boundingBox.expand(mobRadius, 6.0D, mobRadius));
        for (EntityLivingBase candidate : candidates) {
            if (!isPrey(candidate)) continue;
            double distance = this.getDistanceSqToEntity(candidate);
            if (distance > (double) mobRadius * mobRadius) continue;
            // Prey within a few blocks is heard/smelled even behind walls.
            if (distance > (double) near * near &&
                !BroodTargetRules.canDetect(distance, mobRadius, near,
                    this.canEntityBeSeen(candidate))) continue;
            if (chosen == null || BroodTargetRules.shouldSwitch(distance, chosenDistance)) {
                chosen = candidate;
                chosenDistance = distance;
            }
        }
        // Large-radius entity AABB scans scale terribly with HBM machines and
        // big parasite populations. Players are indexed cheaply in playerEntities;
        // scan them separately at up to 150 blocks, without loading any chunks.
        for (Object obj : worldObj.playerEntities) {
            if (!(obj instanceof EntityPlayer)) continue;
            EntityPlayer player = (EntityPlayer) obj;
            if (!isPrey(player)) continue;
            double distance = getDistanceSqToEntity(player);
            if (!BroodThreatTuning.playerInLongRange(distance, playerRadius)) continue;
            // Distant pursuit tracks the player, including behind nearby cover.
            if (chosen == null || BroodTargetRules.shouldSwitch(distance, chosenDistance)) {
                chosen = player;
                chosenDistance = distance;
            }
        }
        if (chosen != current) this.setAttackTarget(chosen);
    }

    private boolean isPrey(EntityLivingBase entity) {
        if (entity == null || entity == this || entity instanceof EntityParasite || entity instanceof EntityBroodFlier ||
            entity.isDead || !entity.isEntityAlive() || entity.worldObj != this.worldObj)
            return false;
        if (entity instanceof EntityPlayer &&
            ((EntityPlayer) entity).capabilities.isCreativeMode) return false;
        return true;
    }

    protected void updateAttributesFromEvolution() {
        double power = EvolutionMath.logOnePlus(EvolutionData.get(this.worldObj).getStage());
        int kind = getMorph();
        double health = (20.0D + 5.0D * power) *
            (gene == ParasiteGenes.BRUTE ? 1.35D : 1.0D) *
            (kind == 4 ? 4.0D : kind == 5 ? 2.6D : kind == 2 ? 1.7D : kind == 1 ? 0.65D : 1.0D) *
            ((genome & ParasiteGenome.PLATES) != 0 ? 1.22D : 1.0D);
        double attack = (3.0D + 1.5D * power) *
            (gene == ParasiteGenes.BRUTE ? 1.25D : 1.0D) *
            (kind == 4 ? 2.3D : kind == 5 ? 1.65D : kind == 2 ? 1.4D : 1.0D);
        double speed = BroodThreatTuning.boostedSpeed((0.23D + 0.005D * power +
            (gene == ParasiteGenes.HUNTER ? 0.055D : 0.0D) +
            (kind == 1 ? 0.065D : kind == 2 ? -0.05D : kind == 4 ? -0.08D : kind == 5 ? -0.055D : 0.0D) +
            ((genome & ParasiteGenome.SWIFT) != 0 ? 0.035D : 0.0D)),
            BroodConfig.broodMovementSpeedMultiplier);
        double oldMax = this.getMaxHealth();
        this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(health);
        this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(attack);
        this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(speed);
        // Also refresh mobs that were saved before long-range detection was added.
        this.getEntityAttribute(SharedMonsterAttributes.followRange)
            .setBaseValue(BroodConfig.distantPlayerDetectionRange);
        if (this.getHealth() > 0.0F && health > oldMax) {
            this.heal((float) Math.min(health - oldMax, 100.0D));
        } else if (this.getHealth() > health) {
            this.setHealth((float) health);
        }
    }

    /** Distinct Scuttler combat role: a short, capped leap, no teleportation or block damage. */
    private void pounceAtPrey() {
        EntityLivingBase target = this.getAttackTarget();
        if (target == null || target.isDead || !this.onGround || !this.canEntityBeSeen(target)) return;
        double distance = this.getDistanceSqToEntity(target);
        if (distance < 9.0D || distance > 64.0D) return;
        double x = target.posX - this.posX;
        double z = target.posZ - this.posZ;
        double norm = Math.sqrt(x * x + z * z);
        if (norm < 0.01D) return;
        this.motionX += x / norm * 0.34D;
        this.motionY = 0.31D;
        this.motionZ += z / norm * 0.34D;
        this.velocityChanged = true;
    }

    /** Colossus shockwave is status-only, never destroys blocks or creates explosions. */
    @SuppressWarnings("unchecked")
    private void colossusRoar() {
        List<EntityLivingBase> victims = this.worldObj.getEntitiesWithinAABB(EntityLivingBase.class,
            this.boundingBox.expand(8.0D, 4.0D, 8.0D));
        boolean threatened = false;
        for (EntityLivingBase victim : victims) {
            if (victim != this && !(victim instanceof EntityParasite) &&
                !victim.isDead && this.getDistanceSqToEntity(victim) <= 64.0D) {
                victim.addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, 65, 0));
                victim.addPotionEffect(new PotionEffect(Potion.weakness.id, 65, 0));
                threatened = true;
            }
        }
        if (threatened) this.worldObj.playSoundEffect(this.posX, this.posY, this.posZ,
            BroodConfig.horrorSoundsEnabled ? "endlessbrood:roar" : "mob.enderdragon.growl", 1.2F, 0.72F);
    }

    /** Matriarch: short-lived, capped buffs for a handful of nearby followers.
     *  Buffs do not bypass wards, damage caps or block protection.
     */
    @SuppressWarnings("unchecked")
    private void rallyNearbyBrood() {
        int r = BroodConfig.leaderRallyRadius;
        List<EntityParasite> nearby = this.worldObj.getEntitiesWithinAABB(EntityParasite.class,
            this.boundingBox.expand(r, 5.0D, r));
        EntityLivingBase sharedTarget = this.getAttackTarget();
        int influenced = 0;
        int healed = 0;
        for (EntityParasite member : nearby) {
            if (member == this || member.isDead ||
                this.getDistanceSqToEntity(member) > r * r) continue;
            member.addPotionEffect(new PotionEffect(Potion.moveSpeed.id,
                BroodConfig.leaderRallyTicks + 30, 0));
            // First six closest peers get an attack boost; never unlimited stacks.
            if (influenced++ < 6) member.addPotionEffect(new PotionEffect(
                Potion.damageBoost.id, BroodConfig.leaderRallyTicks + 30, 0));
            if (BroodConfig.queenHeals && healed < 4 &&
                member.getHealth() > 0.0F && member.getHealth() < member.getMaxHealth()) {
                member.heal(1.0F); // small, predictable local healing, not immortality
                healed++;
            }
            if (sharedTarget != null && !sharedTarget.isDead &&
                member.getAttackTarget() == null &&
                member.getDistanceSqToEntity(sharedTarget) <= 256.0D) {
                member.setAttackTarget(sharedTarget);
            }
        }
    }

    /** Nearby brood members coordinate without an expensive world-wide hive scan. */
    @SuppressWarnings("unchecked")
    private void shareColonyTarget() {
        if (EvolutionData.get(this.worldObj).getStage().compareTo(BigInteger.valueOf(12)) < 0) return;
        List<EntityParasite> peers = this.worldObj.getEntitiesWithinAABB(EntityParasite.class,
            this.boundingBox.expand(16.0D, 5.0D, 16.0D));
        for (EntityParasite peer : peers) {
            EntityLivingBase victim = peer.getAttackTarget();
            if (victim != null && !victim.isDead && victim.getHealth() > 0.0F &&
                this.getDistanceSqToEntity(victim) <= 576.0D) {
                this.setAttackTarget(victim);
                return;
            }
        }
    }

    @Override
    public boolean attackEntityAsMob(Entity victim) {
        boolean success = super.attackEntityAsMob(victim);
        if (success && !this.worldObj.isRemote &&
            (genome & ParasiteGenome.SPORES) != 0 && victim instanceof EntityLivingBase) {
            ((EntityLivingBase) victim).addPotionEffect(new PotionEffect(Potion.weakness.id, 70, 0));
        }
        return success;
    }

    @Override
    protected void dropFewItems(boolean recentlyHit, int lootingLevel) {
        super.dropFewItems(recentlyHit, lootingLevel);
        if (recentlyHit && com.endlessbrood.EndlessBrood.chitin != null) {
            int amount = (getMorph() == 4 ? 4 : getMorph() == 5 ? 3 : 1) + this.rand.nextInt(2 + Math.max(0, lootingLevel));
            BroodLootDrops.roll(this, com.endlessbrood.EndlessBrood.chitin, amount);
            if (this.rand.nextInt(3) == 0)
                BroodLootDrops.roll(this, com.endlessbrood.EndlessBrood.sinew, 1);
            if (this.rand.nextInt(5) == 0)
                BroodLootDrops.roll(this, com.endlessbrood.EndlessBrood.boneShard, 1);
            if (this.rand.nextInt(8) == 0 || getMorph() == 5)
                BroodLootDrops.roll(this, com.endlessbrood.EndlessBrood.sporeSac, 1);
            if (getMorph() >= 4 && this.rand.nextInt(getMorph() == 5 ? 2 : 4) == 0)
                BroodLootDrops.roll(this, com.endlessbrood.EndlessBrood.broodCore, 1);
        }
    }

    private void clearDigging() {
        digging = false;
        digProgress = 0;
    }

    private void tryDigTowardVictim() {
        EntityLivingBase target = this.getAttackTarget();
        if (target == null || target.isDead || this.canEntityBeSeen(target) ||
            this.getDistanceSqToEntity(target) > 64.0D ||
            !BroodConfig.allowTerrainDamage ||
            !this.worldObj.getGameRules().getGameRuleBooleanValue("mobGriefing")) {
            clearDigging();
            return;
        }
        double dx = target.posX - this.posX;
        double dz = target.posZ - this.posZ;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        if (horizontal < 0.1D || Math.abs(target.posY - this.posY) > 3.0D) {
            clearDigging();
            return;
        }
        int x = MathHelper.floor_double(this.posX + dx / horizontal * 0.85D);
        int y = MathHelper.floor_double(this.boundingBox.minY + 0.2D);
        int z = MathHelper.floor_double(this.posZ + dz / horizontal * 0.85D);
        BigInteger stage = EvolutionData.get(this.worldObj).getStage();
        if (!BroodBlockRules.canBreak(this.worldObj, x, y, z, stage, gene)) {
            y += 1;
            if (!BroodBlockRules.canBreak(this.worldObj, x, y, z, stage, gene)) {
                clearDigging();
                return;
            }
        }
        if (!digging || digX != x || digY != y || digZ != z) {
            digX = x;
            digY = y;
            digZ = z;
            digProgress = 0;
            digging = true;
        }
        digProgress += 10;
        if (digProgress < BroodBlockRules.digDuration(this.worldObj, x, y, z)) return;
        // Revalidate right before actually removing a block; no expensive area scans.
        if (BroodBlockRules.canBreak(this.worldObj, x, y, z, stage, gene) &&
            !BroodWardRules.protects(this.worldObj, x, y, z)) {
            this.worldObj.func_147480_a(x, y, z, BroodConfig.dropDestroyedBlocks);
        }
        clearDigging();
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound tag) {
        super.writeEntityToNBT(tag);
        tag.setInteger("EndlessBroodGene", gene);
        tag.setInteger("EndlessBroodGenome", genome);
        tag.setInteger("EndlessBroodMorph", getMorph());
        tag.setBoolean("EndlessBroodHasHome", hasBroodHome);
        if (hasBroodHome) {
            tag.setInteger("EndlessBroodHomeX", broodHomeX);
            tag.setInteger("EndlessBroodHomeY", broodHomeY);
            tag.setInteger("EndlessBroodHomeZ", broodHomeZ);
        }
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound tag) {
        super.readEntityFromNBT(tag);
        hasBroodHome = tag.getBoolean("EndlessBroodHasHome");
        if (hasBroodHome) {
            broodHomeX = tag.getInteger("EndlessBroodHomeX");
            broodHomeY = tag.getInteger("EndlessBroodHomeY");
            broodHomeZ = tag.getInteger("EndlessBroodHomeZ");
        }
        if (tag.hasKey("EndlessBroodGene")) {
            gene = tag.getInteger("EndlessBroodGene");
            if (gene < ParasiteGenes.STANDARD || gene > ParasiteGenes.CORROSIVE) {
                gene = ParasiteGenes.STANDARD;
            }
            geneAssigned = true;
            this.dataWatcher.updateObject(21, Byte.valueOf((byte) gene));
        }
        if (tag.hasKey("EndlessBroodGenome")) {
            genome = tag.getInteger("EndlessBroodGenome") & ParasiteGenome.ALL;
            this.dataWatcher.updateObject(22, Byte.valueOf((byte) genome));
        }
        if (tag.hasKey("EndlessBroodMorph")) {
            int morph = tag.getInteger("EndlessBroodMorph");
            setMorph(morph >= 0 && morph <= BroodColonyRules.QUEEN_MORPH ? morph : 0);
        }
    }
}
