package com.endlessbrood.common;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;

/** Visible wandering scouts in ACTIVE chunks, complementing vanilla hostile
 * spawns and remote nests. Never scans / generates unloaded land. */
public final class BroodPatrolTicker {
    @SubscribeEvent
    public void onWorldTick(TickEvent.WorldTickEvent event) {
        World world = event.world;
        if (!world.isRemote && BroodVictoryData.isDefeated(world)) return;
        if (world.isRemote || event.phase != TickEvent.Phase.END ||
            world.provider.dimensionId != 0 ||
            world.difficultySetting == EnumDifficulty.PEACEFUL ||
            !world.getGameRules().getGameRuleBooleanValue("doMobSpawning") ||
            BroodConfig.patrolLocalCap < 1 || BroodConfig.spawnWeight == 0) return;
        BroodOutbreakData outbreak = BroodOutbreakData.get(world);
        boolean regularDue = BroodSpawnRules.patrolDue(world.getTotalWorldTime(),
            BroodCalendarRules.patrolInterval(BroodConfig.effectivePatrolTicks(),
                BroodCalendarRules.day(world.getWorldTime())));
        boolean earlyDue = BroodSpawnRules.patrolDue(world.getTotalWorldTime(),
            BroodConfig.earlyScoutIntervalTicks) &&
            outbreak.elapsedTicks(world.getTotalWorldTime()) >= 24000L * BroodConfig.earlyScoutStartDay;
        if (!regularDue && !earlyDue) return;
        BigInteger stage = EvolutionData.get(world).getStage();
        int amount = BroodPressureRules.more(BroodSpawnRules.patrolSize(stage) +
            BroodCalendarRules.extraScouts(BroodCalendarRules.day(world.getWorldTime())),
            BroodConfig.swarmPressure, 8);
        // One player from each area; co-op players together are NOT double-targeted.
        List<EntityPlayer> active = new ArrayList<EntityPlayer>();
        for (Object obj : world.playerEntities) {
            if (!(obj instanceof EntityPlayer)) continue;
            EntityPlayer player = (EntityPlayer) obj;
            if (player.isDead || player.capabilities.isCreativeMode) continue;
            boolean normallyAllowed = outbreak.naturalSpawnsAllowed(world, player.posX, player.posZ);
            if (!((normallyAllowed && regularDue) || (!normallyAllowed && earlyDue))) continue;
            boolean grouped = false;
            for (EntityPlayer representative : active)
                if (representative.getDistanceSqToEntity(player) < 96.0D * 96.0D) {
                    grouped = true; break;
                }
            if (!grouped && active.size() < 2) active.add(player);
        }
        for (EntityPlayer player : active) {
            AxisAlignedBB nearby = player.boundingBox.expand(64, 24, 64);
            int count = BroodLoadedEntities.find(world, EntityParasite.class, nearby).size() +
                        BroodLoadedEntities.find(world, EntityBroodFlier.class, nearby).size();
            boolean early = !outbreak.naturalSpawnsAllowed(world, player.posX, player.posZ);
            int cap = early ? BroodConfig.earlyScoutLocalCap : BroodConfig.effectivePatrolCap();
            int desired = early ? Math.min(2, amount) : amount;
            for (int n = 0; n < desired && count + n < cap; ++n)
                if (!spawnScout(world, player, outbreak, stage, early)) break;
        }
    }

    private boolean spawnScout(World world, EntityPlayer player,
                               BroodOutbreakData outbreak, BigInteger stage, boolean early) {
        for (int attempt = 0; attempt < 24; ++attempt) {
            double angle = world.rand.nextDouble() * Math.PI * 2D;
            // Old 40..63 radius often fell outside the server's loaded chunks.
            int distance = early ? 28 + world.rand.nextInt(17) :
                19 + world.rand.nextInt(19);
            int x = MathHelper.floor_double(player.posX + Math.cos(angle) * distance);
            int z = MathHelper.floor_double(player.posZ + Math.sin(angle) * distance);
            if ((!early && !outbreak.naturalSpawnsAllowed(world, x, z)) ||
                !world.blockExists(x, 64, z)) continue;
            int y = world.getHeightValue(x, z);
            if (y < 48 || y > 200 || !world.blockExists(x, y + 3, z) ||
                !world.isAirBlock(x, y, z) || !world.isAirBlock(x, y + 1, z) ||
                !world.getBlock(x, y - 1, z).getMaterial().isSolid() ||
                BroodWardRules.protects(world, x, y, z) ||
                BroodRadiationBridge.getRadiation(world, x, y, z) >= BroodConfig.radiationFearThreshold)
                continue;
            EntityParasite mob = new EntityParasite(world);
            mob.setPosition(x + 0.5D, y, z + 0.5D);
            if (stage.compareTo(BigInteger.valueOf(12L)) >= 0 && world.rand.nextInt(4) == 0)
                mob.configureSpawnMorph(2);
            if (world.checkNoEntityCollision(mob.boundingBox) &&
                world.getCollidingBoundingBoxes(mob, mob.boundingBox).isEmpty())
            {
                if (world.spawnEntityInWorld(mob)) {
                    mob.setAttackTarget(player);
                    return true;
                }
            }
        }
        return false;
    }
}
