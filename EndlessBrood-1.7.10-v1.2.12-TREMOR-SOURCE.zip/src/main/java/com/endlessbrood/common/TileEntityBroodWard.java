package com.endlessbrood.common;

import net.minecraft.tileentity.TileEntity;
/** Passive marker tile entity for cheap ward search in loaded chunk maps. */
public final class TileEntityBroodWard extends TileEntity {
    @Override public boolean canUpdate() { return false; }
}
