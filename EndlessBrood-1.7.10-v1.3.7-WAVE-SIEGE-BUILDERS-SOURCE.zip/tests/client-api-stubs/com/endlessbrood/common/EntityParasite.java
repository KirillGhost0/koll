package com.endlessbrood.common;
import net.minecraft.entity.EntityLivingBase;
public class EntityParasite extends EntityLivingBase {
    public int getVisualTier(){return 0;}
    public int getMorph(){return 0;}
    public int getGenome(){return 0;}
    public int getGene(){return 0;}
    public int getHorrorPose(){return 0;}
}
