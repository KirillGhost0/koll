package com.endlessbrood.common;

/** Bounded, pure difficulty math; tested without any Forge classes. */
public final class BroodThreatTuning {
    private BroodThreatTuning() { }

    public static int waveGoal(int base, int pressure, int multiplier) {
        long scaled = Math.max(0L, base);
        scaled += scaled * Math.max(0, pressure - 1) / 2L;
        return (int) Math.min(128L, scaled * Math.max(1, multiplier));
    }

    /** Apply the late-game balance factor only to the total planned wave spawns.
     *  Earlier mob, radius and simultaneous-cap settings are intentionally untouched.
     *  Round to nearest integer because mob counts are indivisible.
     */
    public static int waveGoal(int base, int pressure, int multiplier, int percent) {
        int oldGoal = waveGoal(base, pressure, multiplier);
        int boundedPercent = Math.max(0, Math.min(100, percent));
        return (int) ((oldGoal * (long) boundedPercent + 50L) / 100L);
    }

    public static int expandedLocalCap(int base, int pressure, int pressureCeiling,
                                        int bonus, int absoluteCeiling) {
        return Math.min(absoluteCeiling,
            BroodPressureRules.populationCap(base, pressure, pressureCeiling) + Math.max(0, bonus));
    }

    public static int reinforcementPulseSize(int pressure) {
        return 8 + Math.min(6, Math.max(0, pressure) * 2);
    }

    public static double boostedSpeed(double base, double multiplier) {
        return Math.min(0.43D, Math.max(0.0D, base) * Math.max(1.0D, multiplier));
    }

    public static boolean playerInLongRange(double distanceSq, int playerRange) {
        return distanceSq >= 0D && distanceSq <= (double) playerRange * playerRange;
    }
}
