# v1.2.3 BRUTAL — experimental
- Fix vanilla idle despawning for ground and flying parasites (configurable).
- Reduce patrol spawn radius to loaded neighborhoods (19–37 blocks).
- Late outbreak can seed old chunks 32+ blocks from players.
- Add bounded 30-second siege pressure once stage 10 unlocks and safe-zone decays.
- At stage 100+, siege groups can contain 11 attackers each pulse (cap still 36).
- Siege and invasion creatures actively target survival players, including flying mobs.
- Wave spawns adapt to small loaded-area distances (24–42 blocks).
- Preserve 15-day wave schedule, HBM block protections and radiation avoidance.
- CLI smoke tests pass. Full Forge Gradle compilation / actual in-game testing pending.
