package com.endlessbrood.common;
public class BroodConfig {
 public static boolean radiationFear=true;
 public static float radiationFearThreshold=1F, radiationDamageThreshold=5F, radiationDamageAmount=2F;
}
