#!/usr/bin/env python3
from pathlib import Path
root = Path('src/main/java/com/endlessbrood/common')
c = (root / 'BroodConfig.java').read_text()
t = (root / 'EvolutionTicker.java').read_text()
e = (root / 'EvolutionCommand.java').read_text()
assert 'config.getInt("pointsPerStage", "evolution", 100,' in c
assert 'config.getInt("combatPointsPerDay", "evolution", 180,' in c
assert 'config.getInt("passiveGrowthMultiplier", "evolution", 2,' in c
assert 'if (combatPointsPerDay == 90)' in c and 'dailyLimitMigrated136' in c
assert 'addPoints(BroodConfig.growthPoints * BroodConfig.passiveGrowthMultiplier)' in t
assert 'projected max per day' in e
assert (24000 // 600) * 1 * 2 == 80
assert 180 + 80 == 260
print('PASS: updated config migration, stage 100, passive 80, combat 180, projected max 260')
