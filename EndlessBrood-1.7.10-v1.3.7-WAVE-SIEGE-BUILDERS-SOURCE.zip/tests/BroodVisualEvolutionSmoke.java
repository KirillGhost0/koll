package test;
import java.math.BigInteger;
import com.endlessbrood.common.BroodVisualEvolution;

/** Every tenth stage has a new synchronized visual tier, including huge stages. */
public class BroodVisualEvolutionSmoke {
    public static void main(String[] args) {
        for (int stage=0;stage<=600;stage++) {
            int tier=BroodVisualEvolution.tier(BigInteger.valueOf(stage));
            if (tier!=stage/10) throw new AssertionError("visual tier at stage "+stage);
            float scale=BroodVisualEvolution.scale(tier);
            if(scale<1.0F || scale>1.1201F) throw new AssertionError("size out of limit");
        }
        for(int tier=1;tier<=50;tier++) {
            if (BroodVisualEvolution.skin(tier) == BroodVisualEvolution.skin(tier-1) &&
                BroodVisualEvolution.spines(tier) == BroodVisualEvolution.spines(tier-1) &&
                BroodVisualEvolution.scale(tier) == BroodVisualEvolution.scale(tier-1))
                throw new AssertionError("no visible mutation at tier "+tier);
        }
        BigInteger superLarge=BigInteger.TEN.pow(5000);
        int a=BroodVisualEvolution.tier(superLarge);
        int b=BroodVisualEvolution.tier(superLarge.add(BigInteger.TEN));
        if(a==b || BroodVisualEvolution.skin(a)==BroodVisualEvolution.skin(b))
            throw new AssertionError("very large stages stop mutating");
        System.out.println("PASS: per-ten-stage visible mutations, collision size limits, enormous stages");
    }
}
