package com.hbm.handler.radiation;
import net.minecraft.world.World;
public class ChunkRadiationManager {
 public static Handler proxy=new Handler();
 public static class Handler { public float getRadiation(World w,int x,int y,int z){return x<16?10F:0F;} }
}
