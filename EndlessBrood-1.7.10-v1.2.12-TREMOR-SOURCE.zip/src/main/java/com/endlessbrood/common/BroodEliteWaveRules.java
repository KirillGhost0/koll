package com.endlessbrood.common;

/** Deterministic per-wave budgets. Pure Java so composition and scaling are testable. */
public final class BroodEliteWaveRules {
    private BroodEliteWaveRules() { }
    /** Ravager, Sporecaller, Ironmaw, Skyreaper, Overmind. */
    public static final int CASTES = 5;
    public static final int[] STAGE_UNLOCKS = {12, 25, 45, 30, 65};
    public static final int[] WAVE_UNLOCKS  = { 2,  3,  4,  3,  5};
    /** Approximate combat-load equivalent to baseline parasites (not per-tick CPU cost). */
    public static final double[] THREAT_WEIGHT = {2.6D, 2.3D, 3.5D, 3.0D, 4.5D};

    public static final class Plan {
        public final int total;
        public final int regular;
        public final int[] elite;
        public final double threatEquivalent;
        Plan(int total, int[] elite) {
            this.total = total;
            this.elite = elite;
            int e = 0;
            for (int n : elite) e += n;
            this.regular = total - e;
            double strength = regular;
            for (int i = 0; i < CASTES; ++i) strength += elite[i] * THREAT_WEIGHT[i];
            threatEquivalent = strength;
        }
    }

    /**
     * Five new high-cost castes REPLACE ordinary mobs, never add to the cap.
     * At default settings, 1.2.7's 77 wave-5 creatures become 45 including
     * 16 elite creatures, rather than 77 plus elites. 60 creature absolute cap.
     */
    public static Plan plan(int wave, long stage, int oldHeadcount, int headcountPercent) {
        int w = Math.max(1, wave);
        int rate = Math.max(35, Math.min(100, headcountPercent));
        // Early waves have fewer available specialists. Do not nerf their total
        // offensive strength merely for a headline mob-count reduction.
        if (w == 1) rate = Math.max(rate, 95);
        else if (w == 2) rate = Math.max(rate, 83);
        else if (w == 3) rate = Math.max(rate, 72);
        else if (w == 4) rate = Math.max(rate, 65);
        int total = Math.max(12, Math.min(60,
            (int)((Math.max(0, oldHeadcount) * (long)rate + 50L) / 100L)));
        // Every fifth wave has a ~Wither-class Sovereign. Reduce normal headcount
        // BEFORE selecting elite quotas, instead of stacking an extra boss on top.
        total = Math.min(total, BroodWaveRules.siegeHeadcountCeiling(w));
        int[] quota = new int[CASTES];
        int tier = Math.min(w, 8);
        // Target balanced mix per wave before eligibility; only the five castes above exist.
        int[][] table = {
            {0,0,0,0,0},  // wave 1: basic introduction
            {2,0,0,0,0},  // wave 2: first melee specialist
            {3,2,0,2,0},  // wave 3: air and poison enter combat
            {4,3,2,2,0},  // wave 4: armored shock troops
            {4,4,3,3,2},  // wave 5: full caste roster
            {5,4,3,4,2},  // wave 6
            {5,5,4,4,3},  // wave 7
            {5,5,4,5,4}   // wave 8+: capped elite presence
        };
        for (int i=0;i<CASTES;++i) {
            if (w >= WAVE_UNLOCKS[i] && stage >= STAGE_UNLOCKS[i]) quota[i]=table[tier-1][i];
        }
        if (BroodWaveRules.hasSovereign(w)) {
            // Boss waves contain fewer low-end elites; specialist skills still matter.
            int[][] sovereign = {
                {3,3,2,2,1}, // wave 5: 11 elites + 21 regular + one boss
                {4,4,3,3,1}, // wave 10: 15 elites + 19 regular + one boss
                {4,4,3,3,2}, // wave 15: 16 elites + 20 regular + one boss
                {4,4,4,3,2}  // wave 20+: 17 elites + 21 regular + one boss
            };
            int rank = Math.min(4, w / 5) - 1;
            for (int i = 0; i < CASTES; ++i)
                quota[i] = (w >= WAVE_UNLOCKS[i] && stage >= STAGE_UNLOCKS[i]) ? sovereign[rank][i] : 0;
        }
        // A wave always has >=50% regular mobs. Elite mix scales down safely
        // when users reduce headcountPercent to 35 in the config.
        int maxElite = Math.min(total / 2, 23);
        int sum = 0;
        for (int n: quota) sum += n;
        // At low evolution stages, elite castes may still be locked. Compensate
        // with regular mob slots instead of making the siege trivial.
        int unlockedPotential = 0;
        if (BroodWaveRules.hasSovereign(w)) {
            // Locked specialist slots become ordinary ones, but the total remains
            // the boss-wave budget. A world with slow NTM evolution is not flooded.
            unlockedPotential = sum;
        } else {
            for (int n : table[tier-1]) unlockedPotential += n;
            total = Math.min(BroodWaveRules.siegeHeadcountCeiling(w),
                total + Math.max(0, unlockedPotential - sum));
        }
        while (sum > maxElite) {
            // Scale counts proportionally without starving the cheap early elites.
            int k = 0;
            for (int i=1;i<CASTES;++i) if (quota[i]>quota[k]) k=i;
            if (quota[k] == 0) break;
            quota[k]--;
            sum--;
        }
        return new Plan(total, quota);
    }
}
