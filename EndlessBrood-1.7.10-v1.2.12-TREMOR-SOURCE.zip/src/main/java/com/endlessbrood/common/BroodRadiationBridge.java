package com.endlessbrood.common;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.world.World;

/** Optional integration with HBM NTM 1.7.10's actual chunk radiation manager.
 * Resolves reflectively once, so Endless Brood also works without HBM.
 * HBM implementation: ChunkRadiationManager.proxy.getRadiation(world,x,y,z).
 */
public final class BroodRadiationBridge {
    private static boolean resolved;
    private static Field managerProxy;
    private static Method sampleRadiation;
    private static boolean broken;

    private BroodRadiationBridge() { }

    private static synchronized void resolve() {
        if (resolved) return;
        resolved = true;
        try {
            Class<?> manager = Class.forName("com.hbm.handler.radiation.ChunkRadiationManager");
            managerProxy = manager.getField("proxy");
            Object proxy = managerProxy.get(null);
            if (proxy != null) sampleRadiation = proxy.getClass().getMethod(
                "getRadiation", World.class, Integer.TYPE, Integer.TYPE, Integer.TYPE);
        } catch (Exception e) {
            broken = true;
        } catch (LinkageError e) {
            broken = true;
        }
    }

    public static float getRadiation(World world, int x, int y, int z) {
        if (!BroodConfig.radiationFear || world == null || world.isRemote || broken) return 0F;
        if (!resolved) resolve();
        if (broken || sampleRadiation == null) return 0F;
        // Never request HBM radiation from a chunk we haven't loaded.
        if (!world.blockExists(x, y, z)) return 0F;
        try {
            Object proxy = managerProxy.get(null);
            Object rad = sampleRadiation.invoke(proxy, world, x, y, z);
            float value = rad instanceof Number ? ((Number) rad).floatValue() : 0F;
            return Float.isNaN(value) || value < 0F ? 0F : value;
        } catch (Exception e) {
            broken = true;
            return 0F;
        } catch (LinkageError e) {
            broken = true;
            return 0F;
        }
    }
}
