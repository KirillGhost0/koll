package net.minecraft.entity.boss;
public interface IBossDisplayData {}
