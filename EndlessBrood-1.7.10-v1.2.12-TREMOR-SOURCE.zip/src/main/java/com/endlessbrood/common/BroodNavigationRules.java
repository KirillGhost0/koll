package com.endlessbrood.common;

/** Pure small-step movement math, independent of Minecraft and Forge. */
public final class BroodNavigationRules {
    public static final double CLOSE_CHASE_DISTANCE = 24.0D;
    private BroodNavigationRules() { }

    public static boolean requiresWayPoint(double distanceSquared) {
        return distanceSquared > CLOSE_CHASE_DISTANCE * CLOSE_CHASE_DISTANCE;
    }

    /** Destinations stay at most step blocks away from the mob, even at 150+ range. */
    public static double[] shortWaypoint(double x, double z, double targetX,
                                         double targetZ, double step) {
        double dx = targetX - x, dz = targetZ - z;
        double dist = Math.sqrt(dx * dx + dz * dz);
        if (dist < 1.0E-6D || step <= 0.0D) return new double[] { x, z };
        double k = Math.min(1.0D, Math.min(step, 14.0D) / dist);
        return new double[] { x + dx * k, z + dz * k };
    }
}
