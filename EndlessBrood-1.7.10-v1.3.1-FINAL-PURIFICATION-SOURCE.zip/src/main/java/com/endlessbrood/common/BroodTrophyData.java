package com.endlessbrood.common;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraft.world.WorldSavedData;

/** Server-persistent counter: four successive sovereign kills give four different seals. */
public final class BroodTrophyData extends WorldSavedData {
    private static final String ID = "endlessbrood_sovereign_trophies";
    private int kills;
    public BroodTrophyData() { super(ID); }
    public BroodTrophyData(String name) { super(name); }
    public static BroodTrophyData get(World world) {
        BroodTrophyData d = (BroodTrophyData)world.loadItemData(BroodTrophyData.class, ID);
        if (d == null) { d = new BroodTrophyData(ID); world.setItemData(ID, d); }
        return d;
    }
    public int nextFragment() {
        int fragment = BroodRealmRules.fragmentFromKill(kills);
        if (kills < Integer.MAX_VALUE) ++kills;
        markDirty();
        return fragment;
    }
    @Override public void readFromNBT(NBTTagCompound nbt) { kills = Math.max(0, nbt.getInteger("Kills")); }
    @Override public void writeToNBT(NBTTagCompound nbt) { nbt.setInteger("Kills", kills); }
}
