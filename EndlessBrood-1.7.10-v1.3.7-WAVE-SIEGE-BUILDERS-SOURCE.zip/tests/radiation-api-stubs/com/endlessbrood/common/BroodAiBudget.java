package com.endlessbrood.common;
import net.minecraft.world.World;
/** Stub for radiation bridge smoke tests; real budget is tested separately. */
public final class BroodAiBudget {
    public static boolean tryPath(World w) { return true; }
}
