## Endless Brood 1.2.9 — DREAD SOVEREIGN
- Former commander is a full 3-block-tall unique boss with dedicated texture, boss health HUD, HP phases.
- Exactly one boss at waves divisible by five; no boss at other normal waves.
- Reduced fighter headcount during boss waves to maintain threat without entity-count spikes.
- Boss health begins at 320 HP on fifth wave; grows by 40 each 5-wave step, damage 16 +2 (bounded).
- Body collisions are server-authentic (2.65x3.0), boss persistent in saved worlds.
- Non-griefing stomp/debuff/rally, ordinary radiation/HBM protection respected.
- Pure Java arithmetic smoke tests and new renderer mock tests; Forge game launch still required.
